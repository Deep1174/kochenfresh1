<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Manage Coupon</h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
  
 
  
      <div class="container-fluid">
    <!-- error message section -->
         <?php if($this->session->flashdata('fail')!=''){ ?>
          <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
        <?php } ?>  
        <?php if($this->session->flashdata('success')!=''){ ?>
          <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
        <?php } ?>  
   <!--  error message section--> 
        <div class="row">
          <div class="form-content">
            <div class="form-row">
              <div class="form-content-inner">
         <form action="<?=base_url()?>Cupon/save_data" method="post">
         <input type="hidden" name="cupon_id" value="" id="cupon_id" >

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <label for="cuponname"> Coupon Name <span class="star">*</span> </label>
                    <input type="text" class="form-control" id="cupon_name" placeholder="Enter Cupon Name" name="cupon_name" data-validation="required" data-validation-error-msg="Please Enter Cupon Name">
                    </div>
                </div>

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">
                    <label for="DiscountPrice"> Discount Price Type<span class="star">*</span> </label>
                    <select class="form-control" id="discount_price_type" name="discount_price_type" data-validation="required" data-validation-error-msg="Please Enter Discount Type">
                      <option value="">-Select One-</option>
                      <option value="lumpsum">Lumpsum</option>
                      <option value="percentage">Percentage</option>
                    </select>
                    </div>
                </div>

                <div class="clearfix"></div>

                 <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <label for="cuponname"> Discount Amount <span class="star">*</span> </label>
                    <input type="text" class="form-control id" id="discount_amount" placeholder="Enter Discount Amount" name="discount_amount" data-validation="required" data-validation-error-msg="Please Enter Discount Amount" oninput="onlynumeric(this.id)">
                    </div>
                </div>

                 <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">
                    <label for="cuponname"> Purchase Price </label>
                    <input type="text" class="form-control id" id="purchase_price" placeholder="Enter Purchase Price" name="purchase_price"  data-validation-error-msg="Please Enter Purchase Price" oninput="onlynumeric(this.id)">
                    </div>
                </div>

                <div class="clearfix"></div>

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <label for="validfrom">Valid From<span class="star">*</span> </label>
                    <input type="text" class="form-control" id="from" placeholder="Enter Valid From" name="valid_from" data-validation="required" data-validation-error-msg="Please Enter Valid From"></div>
                </div>

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">
                    <label for=" Valid To"> Valid To<span class="star">*</span> </label>
                    <input type="text" class="form-control" id="to" placeholder="Enter Valid To" name="valid_to" data-validation="required" data-validation-error-msg="Please Enter  Valid To">
                    </div>
                </div>
                
                <div class="clearfix"></div>

               <div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <label> <input type="radio" class="" id="new_user" name="user" data-validation="required" data-validation-error-msg="Please Enter User Type" value="New User">New User</label>

                    </div>
					<div class="form-group ">
                     <label><input type="radio" class="" id="all_user" name="user" data-validation="required" data-validation-error-msg="Please Enter  User Type" value="All User">All User</label> 
                 
                    </div>
                  </div> 
                   

              


                <div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <label for="description">Description <span class="star">*</span> </label>
                    <input type="text" class="form-control" id="description" placeholder="Enter Description" name="description" data-validation="required" data-validation-error-msg="Please Enter Description">
                     </div>
                </div>

                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  
          <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>
         </form>
         <!-- Cupon list-->


         <?php  if(!empty($all_cupon)){
              
           ?>
                <div class="small-table-content">
                  <div class="col-md-12">
                    <div class="form-group">
                      <table class="table table-bordered  table-striped">
                        <thead class="thead-inverse">
                          <tr>
                            <th>Coupon Name</th>
                            <th>Discount Amount</th>
                            <th>Purchase Price </th>
                            <th>Valid From</th>
                            <th>Valid To</th>
                            <th>User</th>
                            <th>Description</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
            <?php foreach($all_cupon as $k=>$val){ ?>


                          <tr>
                            <td><?= $val['cupon_name']?></td>
                           

                            <td>
                              <?php 
                              if($val['discount_price_type']=='lumpsum') 
                              { 
                                echo "<i class='fa fa-inr' aria-hidden='true'></i>".$val['discount_amount'];
                              }
                              if($val['discount_price_type']=='percentage') 
                              {
                                echo $val['discount_amount']."<i class='fa fa-percent' aria-hidden='true'></i>";
                              }
                            ?>

                            </td>
                            <td><?= $val['purchase_price']?></td>
                            <td><?=date('d-m-Y', strtotime(str_replace('/', '-', $val['valid_from'])))?></td>
                            <td><?= date('d-m-Y', strtotime(str_replace('/', '-', $val['valid_to'])))?></td>
                             <td><?= $val['user']?></td>
                            <td><?= $val['description']?></td>

                            <td><a onclick="edit_cupon(<?= $val['cupon_id']?>,'<?= $val['cupon_name']?>','<?= $val['discount_price_type']?>','<?= $val['discount_amount']?>','<?= $val['purchase_price']?>','<?=date('d-m-Y', strtotime(str_replace('/', '-', $val['valid_from'])))?>','<?= date('d-m-Y', strtotime(str_replace('/', '-', $val['valid_to'])))?>','<?php echo $val['user'];?>','<?= $val['description']?>')" href="javascript:void(0);" class="edit" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i> </a>  
                            <a href="<?=base_url()?>Cupon/delete/<?= $val['cupon_id']?>" class="delete" title="Delete" onclick="return confirm('Are you sure you want to delete ?')"><i class="fa fa-trash-o" aria-hidden="true"></i> </a></td>
                          </tr>
            <?php } ?>

                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="clearfix"></div>
                </div>
         <?php } ?>
         <?php echo $link;?>
        <!-- cupon list -->
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script>
  function edit_cupon(id,name,price,amount,purchase,from,to,user,description)
  {
    $('#head').html(" Edit Coupon");
    $('#cupon_name').val(name);
    $('#cupon_id').val(id);
    $('#discount_price_type').val(price);
    $('#discount_amount').val(amount);
    $('#purchase_price').val(purchase);
    $('#from').val(from);
    $('#to').val(to);
    //alert(user);
    //$('#user').val(user);
    if(user=='New User')
    {
      $('#new_user').attr("checked", "checked"); 
    }
     if(user=='All User')
    {
      $('#all_user').attr("checked", "checked");
    }
    
    $('#description').val(description);
    
  }
   function cancel()
  {
    $('#head').html(" Manage Coupon");
    $('#cupon_name').val('');
    $('#cupon_id').val('');
    $('#discount_price_type').val('');
    $('#discount_amount').val('');
    $('#purchase_price').val('');
    $('#from').val('');
    $('#to').val('');
    $('#user').val('');
    $('#description').val('');
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    lang: 'es'
  });
</script>
<script>
      $(function () { //alert("ol");
            $('.id').on('input', function (e){ //alert("olsw");
                 this.value = this.value.replace(/[^0-9\.]/g,'');
            });
   
   
});
</script>

<script>
  function cancel()
  {
    window.location.href = "<?php echo base_url().'Cupon' ?>";
  }
</script>

