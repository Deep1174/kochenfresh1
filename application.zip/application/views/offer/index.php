
<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Manage Banner</h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <!--<div class="breadcrumb-section">
                    <ul class="breadcrumb">
                          <li class="breadcrumb-item"><a href="#"> <i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
                          <li class="breadcrumb-item"><a href="#"> Dashboard</a></li>
                          <li class="breadcrumb-item active">Attendence</li>
                        </ul>
                </div>-->
  
  <div class="form_section">
   <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--  error message section-->  
      <div class="container-fluid">
        <div class="row">
          <div class="form-content">
            <div class="form-row">
              <div class="form-content-inner">
         <form action="<?=base_url()?>Offer/save" method="post" enctype="multipart/form-data">
         <input type="hidden" name="offer_id" value="" id="offer_id" >
               <!--  <div class="col-md-6 col-sm-6">
                  <div class="form-group">
                    <label for="offer title"> Offer Title <span class="star">*</span> </label>
                    <input type="text" class="form-control" id="offer_title" placeholder="Enter  Offer Title" name="title" data-validation="required" data-validation-error-msg="Please Enter  Offer Title ">
                   
                    
          </div>
                </div> -->

               <!--  <div class="col-md-6 col-sm-6"  >
                <div class="form-group">
                  <label for="descrip"> Description <span class="star">*</span></label>
                  <input type="text" name="description" id="description" placeholder="Enter Description" name="title" class="form-control" data-validation="required " data-validation-error-msg-required="Please Description">
                  </div>                
              </div> -->
            
              
                
                <div class="col-md-6 col-sm-6"  >
                <div class="form-group">
                  <label for="image"> Banner Image [jpeg,jpg,png]<span class="star">*</span></label>
                  <input type="file" name="offer_image" id="image" class="form-control" required >
                  </div>                
              </div>
                  
                <div class="col-md-6 col-sm-6"  >
                <div class="form-group" >  
                  <img src="" id="offerlogo" height="100" width="100" style="display:none;">
                 <div id="img_name"></div>
                </div>                
              </div>

              

                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  
          <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>
         </form>
         <!-- offer list-->
         <?php  if(!empty($all_offer)){
              
           ?>
                <div class="small-table-content">
                  <div class="col-md-12">
                    <div class="form-group">
                      <table class="table table-bordered  table-striped">
                        <thead class="thead-inverse">
                          <tr>
                            <th>Sl No. </th>
                       <!--<th>Offer Title</th>
                            <th>Description</th>---->
                            <th>Banner Image</th>
                            <th>Status</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
            <?php foreach($all_offer as $k=>$val){ ?>
                          <tr>
                            <td><?= $k+$page+1?></td>
                       
                            
                            <td><img src="<?php echo base_url() . 'uploads/offer_banner/' . $val['offer_image']; ?>" height="70" width="80" ></td>
                            <td><?php if($val['status'] == '1'){echo "Active";}else{echo "Inactive";}?></td>
                            <td>
                            <a href="<?=base_url()?>Offer/Status/<?php echo $val['offer_id']?>/<?php echo $val['status'];?>" class="delete" <?php if($val['status']==1){ ?> title="Inactivate" onclick="return confirm('Are you sure you want to inactivate it ?')" <?php } else { ?> title="Activate" onclick="return confirm('Are you sure you want to activate it ?')" <?php } ?> ><?php if($val['status'] == 1){ ?> <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                      <?php } else { ?><i class="fa fa-thumbs-down" aria-hidden="true"></i> <?php }?> </a>
                            <a onclick="edit_offer(<?= $val['offer_id']?>,'<?= $val['title']?>','<?= $val['offer_image']?>','<?= $val['offer_description']?>')" href="javascript:void(0);" class="edit" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i> </a>

                              
                            </td>
                          
                          </tr>
            <?php } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="clearfix"></div>
                </div>
         <?php } ?>
         <?php echo $link;?>
        <!-- offer list -->
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script>
  function edit_offer(id,name,logo,desc)
  {
    $('#head').html(" Edit Manage Offer");
    $('#offer_title').val(name);
    $('#offer_id').val(id);
    $('#description').val(desc);

    var logo_path='<?php echo base_url().'uploads/offer_banner/';?>'+logo;
    $('#offerlogo').show();
    $('#offerlogo').attr('src',logo_path);
    $('#img_name').html(logo);
  }
   function cancel()
  {
    $('#head').html("Manage Offer");
    $('#offer_title').val('');
    $('#offer_id').val('');
    $('#description').val('');
    $('#image').val('');
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

