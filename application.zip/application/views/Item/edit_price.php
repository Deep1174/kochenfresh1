<!--right side content section start here-->
<?php $url_id =  $this->uri->segment(3); ?>
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Manage Price</h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
  
 
  
      <div class="container-fluid">
    <!-- error message section -->
         <?php if($this->session->flashdata('fail')!=''){ ?>
          <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
        <?php } ?>  
        <?php if($this->session->flashdata('success')!=''){ ?>
          <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
        <?php } ?>  
   <!--  error message section--> 
        <div class="row">
          <div class="form-content">
            <div class="form-row">
              <div class="form-content-inner head-text">
         <form action="<?=base_url()?>Item/save_price_data" method="post">
         <input type="hidden" name="id" value="" id="id" >
         <input type="hidden" name="item_id" value="<?= $url_id; ?>">
            <div class="col-md-12">   <h3 style="font-weight: 600; font-size: 30px; color:#1ab394;">
              <?php
                     $id         = $this->uri->segment(3);
                $cat_id = getNameTable('kf_item','cat_id','item_id', $id);
                echo  getNameTable('kf_category','cat_name','cat_id', $cat_id); 
                ?> - <span class="item_subprice"  style="color: #333; font-size: 25px;"> <?php
                     $id   = $this->uri->segment(3);
               echo  getNameTable('kf_item','item_name','item_id', $id);
                ?>
                </span>
                </h3></div>
                <div class="clearfix"></div>
 <!--                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <h3>
                     <?php
                     $id   = $this->uri->segment(3);
               echo  getNameTable('kf_item','item_name','item_id', $id);
                ?>
                    </h3>
                   
                    </div>
                </div> -->

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">
            
                    </div>
                </div>

                <div class="clearfix"></div>

                 <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <label for="cuponname"> Quantity <span class="star">*</span> </label>
                   
                    <input type="text" class="form-control id" id="quantity" placeholder="Enter Discount Amount" name="unit_value" data-validation="required" data-validation-error-msg="Please Enter Discount Amount" oninput="onlynumeric(this.id)">
                    </div>
                </div>

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">
                  <label for="cuponname"> Unit Type <span class="star">*</span> </label>
                   <select class="form-control" id="quantity_type" name="unit_name" data-validation="required">
                    <option value="">Select one</option>
                    <?php
                        $UnitType = $this->db->select('*')->where('status', '1')->get('kf_unit_master')->result_array(); 
                        foreach ($UnitType as $UnitDetails) {
                    ?>
                    <option value="<?= $UnitDetails['unit_name'] ?>"><?= $UnitDetails['unit_name'] ?></option>

                    <?php } ?>
                    </select>
                    </div>
                </div>

                <div class="clearfix"></div>

                <div class="col-md-12 col-sm-12">
                  <div class="form-group form-left">
                    <label for="validfrom">Item Price<span class="star">*</span> </label>
                    <input type="text" class="form-control id" id="price" placeholder="Enter Item Price" name="price" data-validation="required" ></div>
                </div>

                <div class="clearfix"></div>

                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  
          <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>
         </form>
         <!-- Cupon list-->


         <?php  if(!empty($result)){
              
           ?>
                <div class="small-table-content">
                  <div class="col-md-12">
                    <div class="form-group">
                      <table class="table table-bordered  table-striped">
                        <thead class="thead-inverse">
                          <tr>
                <th>
                  <div class="headname">Sl No. </div>
                </th>
                <th width="20%"><div class="headname">Item Name </div></th>
                <th><div class="headname">Category Name</div>
                </th>
                <th width="10%"><div class="headname">Quantity</div></th>
                <th width="10%"><div class="headname">Price</div></th>
                <th>Action</th>
              </tr>
                        </thead>
                        <tbody>
            <?php foreach($result as $k=>$value){ ?>


                           <tr>
                <th scope="row"><?php echo $k+1;?></th>
                <td>
                <?php 
                       $item_id   = $value['item_id']; 
                echo   $item_name = getNameTable('kf_item','item_name','item_id', $item_id);
                ?>
                </td>
                <td>
                <?php
                $cat_id = getNameTable('kf_item','cat_id','item_id', $item_id);
                echo $cat_name =  getNameTable('kf_category','cat_name','cat_id', $cat_id); 
                ?>
                </td>
                <td>
                <?php 
                     $quantity = $value['unit_value'];
                     $quantity_type     = getNameTable('kf_unit_master','unit_name','unit_id', $value['unit_id']);
                     echo $quantity.' '.$quantity_type;
                ?>  
                </td>
                <td><?php echo $price =   $value['price']; ?>
                </td>
                <td>
                <a onclick="edit_price('<?= $value['id']?>','<?= $quantity ?>','<?= $quantity_type ?>','<?= $price ?>')" href="javascript:void(0);" class="edit" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i> </a>
                <a href="<?=base_url()?>Item/delete_price/<?= $value['id']?>/<?= $id?>" class="delete" title="Delete" onclick="return confirm('Are you sure you want to delete ?')"><i class="fa fa-trash-o" aria-hidden="true"></i> </a>
                </td>
              </tr>
            <?php } ?>

                        </tbody>
                      </table>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                </div>
         <?php } ?>
    
        <!-- cupon list -->
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script>
  function edit_price(id,quantity,quantity_type,price)
  {
    $('#head').html(" Edit Price");
    $('#id').val(id);
    $('#quantity').val(quantity);
    $('#quantity_type').val(quantity_type);
    $('#price').val(price);
 
  }
   function cancel()
  {
    $('#head').html(" Manage price");
    $('#id').val('');
    $('#quantity').val('');
    $('#quantity_type').val('');
    $('#price').val('');  
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    lang: 'es'
  });
</script>
<script>
      $(function () { //alert("ol");
            $('.id').on('input', function (e){ //alert("olsw");
                 this.value = this.value.replace(/[^0-9\.]/g,'');
            });
   
   
});
</script>

<script>
  function cancel()
  {
    window.location.href = "<?php echo base_url().'Item/edit_price/'.$url_id ?>";
  }
</script>

