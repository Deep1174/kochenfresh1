
          <div class="page-content">
              <div class="page-head">
                    <div class="page-main-head">
                          <h1> View User List</h1>
                        </div>
                        
                        <div class="clearfix"></div>
                </div>
              
                  <div class="form_section">
                    <form action="<?=base_url()?>Users" method="get" name="search-form">
                        
                        <div class="container-fluid">
                               <div class="row">
                                  <div class="form-content">
                                      
                                      <div class="form-row category-form">
                                            <h2>Search</h2> 
                                            
                                            <div class="form-content-inner">
                                                            
                                                   <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-left">
                                                                    
                                                                        <label for="name">First Name </label>
                                                                   <input type="text" class="form-control" name="name" id="name" placeholder="Enter FirstName" value="<?=$this->input->get('name')?>">
                                                                </div>
                                                         </div>

                                                         <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-right">
                                                                    
                                                                        <label for="lastname">Last Name </label>
                                                                   <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Enter Lastname" value="<?=$this->input->get('lastname')?>">
                                                                </div>
                                                         </div>

                                                           <div class="clearfix"></div>
                                                         
                                                   <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-left">
                                                                    
                                                                        <label for="employeecode">Email </label>
                                                                   <input type="text" class="form-control" id="employeecode" name="email" placeholder="Enter Employee Code" value="<?=$this->input->get('email')?>">
                                                                </div>
                                                       </div>            
                                                  
													<!-- <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-left">
                                                                    
                                                                        <label for="employeecode">Phone Number </label>
                                                                   <input type="text" class="form-control" id="employeecode" name="emp_code" placeholder="Enter Employee Code" value="<?=$this->input->get('emp_code')?>">
                                                                </div>
                                                       </div>  -->
                                                        <div class="col-md-6 col-sm-6">
                                                        <?php $status =  $this->input->get('status'); ?>
                                                              <div class="form-group form-right">
                                                                    
                                                                        <label for="department">status </label>
                                                                   <select class="form-control" id="status" name="status">
                                                                        <option value="">Select Status</option>
																		<option value="1" <?php if($status=='1') { ?> selected <?php } ?> >Active</option>
																		<option value="0" <?php if($status=='0') { ?> selected <?php } ?> >InActive</option>
                                                                      
                                                                     </select>
                                                                </div>
                                                         </div>

           
                                                    <div class="clearfix"></div>
                                                               
                                                  <div class="col-md-6 col-sm-6">
                                                                <input name="" type="submit" value="Search" class="yellow btn-radius15 ">
                                                              
                                                             </div>
                                                             <div class="col-md-6 col-sm-6">
                                                               <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
                                                        
                                                      
                                                             </div>
                                                             
                                                        <div class="clearfix"></div>
                                                            
                                            </div>     
                                        </div>
                                        
                                    </div>
                                 </div>
                          </div>
                     </form>
           
           
            </div>
            
                <div class="search-result">
                      <div class="container-fluid">
                          <div class="row">
                                
                                
                           
                              <div class="col-md-12">
                                 <div class="table-responsive">
                                
                                  <div class="search-result-table">
                                  <?php  if(!empty($all_Users['result'])){
              
           ?>
                                      <table class="table table-bordered table-striped">
                                      <thead class="thead-inverse">
                                        <tr>
                                          <th>
                                          <div class="headname">Sl No. </div>
                                          
                                          </th>
										                      <th><div class="headname">Registration Date</div></th>
                                          <th><div class="headname">Customer Name </div></th>
                                          <th><div class="headname">Email</div>
										                      <th><div class="headname">Phone</div>
                                          <th>Status</th>
                                          <th>Action</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                      <?php foreach($all_Users['result'] as $k=>$val){?>
                                        <tr>
                                          <th scope="row"><?= $k+$page+1?></th>
										                      <td><?php echo date("d-m-Y h:i A", strtotime($val['registration_date'])); ?></td>
                                          <td><?= $val['name']?> <?= $val['lastname']?></td>
                                          <td><?= $val['email']?></td>
                                          <td><?= $val['phone']?></td>
                                          <td><?php if($val['status'] == 1)
										  {
											  echo"Active";
										  }	
											else{
												echo"Inactive";
											}	
										  ?></td>
                                          <td>
                                          <!-- <a  href="<?=base_url()?>Users/edit/<?= $val['user_id']?>" class="edit" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i> </a>-->
                                          <a href="<?=base_url()?>Users/delete/<?= $val['user_id']?>?status=<?=$val['status']?>" <?php if($val['status']==1){ ?> title="active" class="view"  onclick="return confirm('Are you sure you want to inactive ?')" <?php } else { ?> class="delete"  title="inactive" onclick="return confirm('Are you sure you want to active ?')" <?php } ?>  ><?php if($val['status']==1){ ?> <i class="fa fa-thumbs-up" aria-hidden="true"></i>
											<?php } else{ ?><i class="fa fa-thumbs-down" aria-hidden="true"></i> <?php }?> </a>
                                           
                                          
                                          <!--view popup-->
                                           <a href="javascript:void(0);" class="view button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" onclick="view_details(<?= $val['user_id'] ?>)" ><i class="fa fa-eye" aria-hidden="true">
                                          </i></a>
                                          


                                          
                                          </td>
                                        </tr><?php } ?>
                                        
                                       
                                      </tbody>
                               </table><?php } ?>
        
                                    </div>
                                
                                
                                </div>
                                
                                </div>
                                
                                <div class="col-md-12">
                                  <div class="pagination-data text-center">
                                         <ul class="pagination">
										
                                              <?php echo $link;?>
											 
                                            </ul>
                                    </div>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
           
                                    
    </div>

    <!-- pop up-->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-sm">
              <div class="modal-content"  id="details_view" >
 

  </div>
</div>
</div>

 <script>
 function view_details(user_id)
  {
    var url = '<?php echo base_url();?>Users/details_by_id';
  //
  $.ajax({
        method:"get",
        url:url,
        
        data: {'user_id': user_id},
        success: function (data, textStatus, jqXHR){

            $('#details_view').html(data);          
          }

      });
  $('.view_buttn').attr('data-target',"#myModal");
  }

 </script>

 <!-- End pop up-->

<script>
function reset_page()
{
	
	window.location.href='<?= base_url()?>Users';
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

  
    
        
        
    
     
    