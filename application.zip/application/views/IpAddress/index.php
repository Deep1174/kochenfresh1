<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1> Manage IP Address </h1>
    </div>
    <div class="clearfix"></div>
  </div>

<?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?> 

  <div class="form_section">
    <form action="" method="get">
    <div class="container-fluid">
      <div class="row">
        <div class="form-content">
          <div class="form-row category-form">
            <h2>Search</h2> 
              <div class="form-content-inner">
                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <label for="name"> Search </label>
                    <input type="text" class="form-control" name="search" placeholder="Search by mac address" value="<?=$this->input->get('search')?>">
                  </div>
                </div>
                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <label>Status </label>
                    <select name="status" class="form-control">
                      <option value="">Select Status</option>
                      <option value="1" <?php if($this->input->get('status') == '1'){echo"selected";} ?>>Active</option>
                      <option value="0" <?php if($this->input->get('status') == '0'){echo"selected";} ?>>Inactive</option>
                    </select>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                    <input name="" type="submit" value="Search" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
                </div>
              <div class="clearfix"></div>
            </div>     
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>

  <div class="search-result">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="table-responsive">
            <div class="search-result-table" id="div-tab">
            <?php if(!empty($result) && count($result)>0){ ?>
                <table class="table table-bordered table-striped">
                  <thead class="thead-inverse">
                    <tr >
                      <th><div class="headname">Sl No. </div></th>
                      <th><div class="headname">MAC Address</div></th>
                      <th><div class="headname">Current Status</div></th>
                      <th>Action</th>
                    </tr>
                  </thead>
                <tbody>
                <?php
                  foreach($result as $val){
                    //echo "<pre>";print_r($val);
                ?>
                  <tr>
                    <th scope="row"><?php echo $page+1;?></th>
                    <td><?php echo isset($val['ip_Address'])?$val['ip_Address']:'';?></td>
                    <td><?php if($val['status'] == '1'){echo "Active";}else{echo "Inactive";}?></td>
                    <td>
                      <a href="<?=base_url()?>IpAddress/Status/<?php echo $val['id']?>/<?php echo $val['status'];?>" class="delete" <?php if($val['status']==1){ ?> title="Inactivate" onclick="return confirm('Are you sure you want to inactivate it ?')" <?php } else { ?> title="Activate" onclick="return confirm('Are you sure you want to activate it ?')" <?php } ?> ><?php if($val['status'] == 1){ ?> <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                      <?php } else { ?><i class="fa fa-thumbs-down" aria-hidden="true"></i> <?php }?> </a>
                    </td>
                  </tr>
                <?php 
                  $page++;
                  }
                ?>
                </tbody>
              </table>
            <?php } else {
                echo "<center> <h1> No Data Found </h1></center>";
            } ?>
            </div>
          </div>
        </div>
        <div class="col-md-12">
          <div class="pagination-data text-center">
            <ul class="pagination">
              <?php echo isset($link)?$link:'';?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>                
</div>

<!-- pop up-->
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content"  id="details_view"></div>
  </div>
</div>

<!-- End pop up-->
<script>
function reset_page() {
 window.location.href='<?php echo base_url();?>IpAddress';
}
</script>
