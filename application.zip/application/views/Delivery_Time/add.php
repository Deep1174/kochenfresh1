<!--right side content section start here-->
<?php $status = $this->db->select('status')->get('kf_delivery')->result_array(); ?>
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head">Store Close / Open</h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
  
      <div class="container-fluid">
    <!-- error message section -->
         <?php if($this->session->flashdata('fail')!=''){ ?>
          <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
        <?php } ?>  
        <?php if($this->session->flashdata('success')!=''){ ?>
          <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
        <?php } ?>  
   <!--  error message section--> 
        <div class="row">
          <div  <?php if($status[0]['status']=='0') { ?> class="form-content div_Open" <?php } else { ?> class="form-content div_Close" <?php } ?>>
          
            <div class="form-row">

         

              <div class="form-content-inner delivery-time text-center">
         <form action="<?=base_url()?>DeliveryTime/save_data" method="post" >
         <input type="hidden" name="delivery_id" value="" id="delivery_id" >
       

        <!--  Store Close section--> 


               <?php if($status[0]['status']=='0') { ?> 
                  <p> <i class="fa fa-window-close-o" aria-hidden="true"></i> </p>
                  <h4>The Store is closed now</h4>
                  <h5>Please  click below button for open the store.</h5>
                 
               <div class="text-center">   <a href="<?php echo base_url('DeliveryTime/Status');?>" <?php if($status[0]['status']=='0') { ?> class="btn OFF-store"  onclick="return confirm('Are you sure? You want to open the store')"  <?php } ?> > Open Store </a> </div>
              
                <div class="col-md-12 col-sm-12">
                  <div class="form-group form-left">

                  <label class="text-left"><strong>Reason For Close:</strong> </label>  
                  <textarea class="form-control" name="note"><?php echo $details[0]['note']; ?></textarea>
                    </div>
                </div>
                 <div class="text-center"> 
                <?php } ?>

                <!--  Store Close End Section--> 

                 <!--  Store Open section--> 


                <div class="col-md-12 col-sm-12 open-now">
                  <div class="form-group form-left">
			        <?php if($status[0]['status']=='1') { ?>  	

             	<p class="text-center"> <i class="fa fa-check" aria-hidden="true"></i> </p>
                <h4>The Store is opened now</h4>
                 <h5>Please  click below button for close the store.</h5>
                  	
            <div class="text-center">  <a href="<?php echo base_url('DeliveryTime/Status');?>" class="btn OFF-store on-store" <?php if($status[0]['status']=='1') { ?> class="OFF"  onclick="return confirm('Are you sure? You want to close the store')"  <?php } ?> > Close Store </a> 
               </div>
                 
              <?php } ?>
                 
                    </div>
                </div>

                 <!--  Store Open end section--> 
                  
          <div class="clearfix"></div>
        
             <?php if($status[0]['status']=='0') { ?> 
               
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Edit" id="sub" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                    <a href="<?php echo base_url().'DeliveryTime'; ?>" class="darkgrey btn-radius15 " title="Cancel">Cancel </a>
                </div>               
                <div class="clearfix"></div> <?php } ?>
         </form>
      
         
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    lang: 'es'
  });
</script>

<script>
  $(function () { //alert("ol");
    $('.delivery').on('input', function (e){ //alert("olsw");
      this.value = this.value.replace(/[^0-9\.]/g,'');
    });
  });
</script>



