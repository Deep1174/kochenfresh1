<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Manage Delivery Time </h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
  
 <?php
 // echo "<pre>";
 // print_r($details);
//  Array
// (
//     [0] => Array
//         (
//             [delivery_id] => 1
//             [time] => 02:00:00
//             [day] => 2
//             [add_date] => 2018-01-18
//             [status] => 1
//         )

//)
 ?>
  
      <div class="container-fluid">
    <!-- error message section -->
         <?php if($this->session->flashdata('fail')!=''){ ?>
          <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
        <?php } ?>  
        <?php if($this->session->flashdata('success')!=''){ ?>
          <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
        <?php } ?>  
   <!--  error message section--> 
        <div class="row">
          <div class="form-content">
            <div class="form-row">
              <div class="form-content-inner">
         <form action="<?=base_url()?>DeliveryTime/save_data" method="post" >
         <input type="hidden" name="delivery_id" value="" id="delivery_id" >

         <div class="col-md-12 col-sm-12">
                  <div class="form-group">
                   <label> <input type="radio" class="" <?php if($details[0]['time']!='00:00:00') { ?> checked <?php } ?> id="set_time_button" value="set_time" name="radioBtn" data-validation="required" data-validation-error-msg="Please Enter Set Time" >Set Time </label>
                  
                     <label><input type="radio" class="" <?php if($details[0]['day']!='') { ?> checked <?php } ?> id="res_delivery_button" value="respond"  name="radioBtn" data-validation="required" data-validation-error-msg="Please Enter  Postponed Delivery" >Postponed Delivery(day)</label> 
                 
                    </div>
          </div> 

            <div id="settime">
               <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                   <!--  <label for="settime">Set Time <span class="star">*</span></label> -->
                   
                    <input type="text"  class="form-control" name="set_time" id="set_time" data-validation="required" placeholder="Enter Set Time" value="<?php echo $details[0]['time']; ?>">
                    
                 <!--  <div id="SetTime"></div> -->
                </div>
              </div>
            </div>

              <div class="clearfix"></div>

              <div id="postpone">
                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                   <!--  <label for="cuponname"> Postponed Delivery(day) <span class="star">*</span> </label> -->
                    <input type="text" class="form-control delivery" id="postpone_delivery" data-validation="required" placeholder="Enter Postponed Delivery day" name="postpone_delivery"  value="<?php echo $details[0]['day']; ?>" oninput="onlynumeric(this.id)" maxlength ="2">
                  Note:    <textarea class="form-control" name="note"><?php echo $details[0]['note']; ?></textarea>
                    </div>
                </div>
              </div>

               <div class="clearfix"></div>

                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" id="sub" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                    <a href="<?php echo base_url().'DeliveryTime'; ?>" class="darkgrey btn-radius15 " title="Cancel">Cancel </a>
                </div>
                <div class="clearfix"></div>
         </form>
         <!-- Delivery list-->
         
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    lang: 'es'
  });
</script>
<script>
  $(function () { //alert("ol");
    $('.delivery').on('input', function (e){ //alert("olsw");
      this.value = this.value.replace(/[^0-9\.]/g,'');
    });
  });
</script>

<script>
  $(document).ready(function (){
   $('input[name=radioBtn]').map(function(){
    var value = $(this).val();
    var name = $(this).attr('name');
   
    var prpo = $(this).prop('checked');
   /* alert(prpo);
    alert(value); */
   if(prpo == true && value== "set_time" )
   {
	 //  alert(1);
      $("#settime").show();
      $("#postpone").hide();
   }
   if(prpo == true && value== "respond"){
    $("#postpone").show();
    $("#settime").hide();
   }

   
  });      
    
  });
  $('input[name=radioBtn]').on('change', function(){
       
       var value =  $(this).prop('checked');

        var n = $(this).val();
        console.log(n);
        if(n == 'set_time'){
          $("#settime").show();
          $("#postpone").hide();
        } else if(n == 'respond'){
          $("#postpone").show();
          $("#settime").hide();
        }
     });
  
</script>
<script type="text/javascript">
  $(document).ready(function() {
     $('#set_time').datetimepicker({
          format: 'HH:mm'
         });
      });
</script>
<?php
 //  if((document.getElementById("set_time_button").checked) = true)
   // {
   //    alert(1);
   //    $("#settime").hide();
   // }

   //  if((document.getElementById("res_delivery_button").checked) = true)
   // {
   //   $("#settime").hide();
   // }
?>