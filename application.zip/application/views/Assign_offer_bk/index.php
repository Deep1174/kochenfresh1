<div class="page-content">
<div class="page-head">
<div class="page-main-head">
<h1> View Assign Offer</h1>
</div>

<div class="clearfix"></div>
</div>

<div class="form_section">
<form action="<?=base_url()?>AssignOffer/save" method="POST">
  <div class="container-fluid">
   <div class="row">
    <div class="form-content">
      <div class="form-row category-form">
        <h2>Search</h2>
          <div class="form-content-inner">
          
            <div class="col-md-6 col-sm-12">
              <div class="form-group ">
                <label for="offer"> Select Offer </label>
                  <select id="offer_id" name="offer_id" class="form-control" data-validation="required" data-validation-error-msg="Please Select Offer " >
                  <option value="">Select Offer</option>
                  <?php if(!empty($offer)){
                    foreach($offer as $val){
                  ?>
                  <option value="<?php echo $val['offer_id'];?>" <?php if($val['offer_id']==$this->input->get('offer_id')){ echo"selected";}?>><?php echo isset($val['title'])?$val['title']:'';?></option>
                  <?php } } ?>
                  </select>
              </div>
            </div>

            <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <label for="category"> Category <span class="star">*</span> </label>
                    <select name="cat" id="cat" class="form-control" data-validation="required" data-validation-error-msg="Please Select Category" onchange="get_item(this)" >
          <option value=''>Select Category</option>
          <?php foreach($category as $value){?>
          <option value='<?=$value['cat_id'] ?>'><?=$value['cat_name'] ?></option>
          <?php } ?>
          </select>
                      
          </div>
                </div>
            <div class="clearfix"></div>
                   
              <div class="clearfix"></div>
              
             
            <div class="clearfix"></div>

            <div id="item">
            </div>

          </div>     
        </div>
      </div>
    </div>
  </div>
</form>
</div>

             
</div>

<!-- <script>
function reset_page() {
  window.location.href='<?= base_url()?>AssignOffer/index';
}
</script>  -->

<script src="<?=base_url()?>js/jquery-1.9.1.min.js"></script>
<script>
function get_item(obj)
{
  var cat_id = $(obj).val();
         var url = "<?= base_url() ?>AssignOffer/get_item";
         $.ajax({
              method:"POST",
              url:url,
             
              data: {'cat_id':cat_id},
        
              success: function (data, textStatus, jqXHR){

                $('#item').html(data);

         
			  }
		 });
		 
     
}
</script>