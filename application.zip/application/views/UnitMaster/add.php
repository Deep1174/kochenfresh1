<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Manage Unit</h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
   <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--  error message section-->  
      <div class="container-fluid">
        <div class="row">
          <div class="form-content">
            <div class="form-row">
              <div class="form-content-inner">
         <form action="<?=base_url()?>UnitMaster/save_data" method="post">
                <div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <label for="designationname"> Unit Name <span class="star">*</span> </label>
                    <input type="text" class="form-control" id="unit_name" placeholder="Enter Unit Name" name="unit_name" data-validation="required" data-validation-error-msg="Please Enter Unit Name ">
                    <input type="hidden" name="unit_id" value="" id="unit_id" >
          </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  
          <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>
         </form>
         <!-- designation list-->
         <?php  if(!empty($all_unit)){
              
           ?>
                <div class="small-table-content">
                  <div class="col-md-12">
                    <div class="form-group">
                      <table class="table table-bordered  table-striped">
                        <thead class="thead-inverse">
                          <tr>
                            <th>Unit Name</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
            <?php foreach($all_unit as $k=>$val){ ?>
                          <tr>
                            <td><?= $val['unit_name']?></td>
                            <td><a onclick="edit_company(<?= $val['unit_id']?>,'<?= $val['unit_name']?>')" href="javascript:void(0);" class="edit" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i> </a>  
                            <a href="<?=base_url()?>UnitMaster/delete/<?= $val['unit_id']?>" class="delete" title="Delete" onclick="return confirm('Are you sure you want to delete ?')"><i class="fa fa-trash-o" aria-hidden="true"></i> </a></td>
                          </tr>
            <?php } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="clearfix"></div>
                </div>
         <?php } ?>
         <?php echo $link;?>
        <!-- designation list -->
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script>
  function edit_company(id,name)
  {
    $('#head').html(" Edit  Unit");
    $('#unit_name').val(name);
    $('#unit_id').val(id);
  }
   function cancel()
  {
    $('#head').html(" Manage Unit");
    $('#unit_name').val('');
    $('#unit_id').val('');
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>
  <script>
    function cancel()
    {
      window.location.href = "<?php echo base_url().'UnitMaster' ?>";
    }
  </script>

