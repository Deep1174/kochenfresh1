<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Set Message </h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
  
      <div class="container-fluid">
    <!-- error message section -->
         <?php if($this->session->flashdata('fail')!=''){ ?>
          <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
        <?php } ?>  
        <?php if($this->session->flashdata('success')!=''){ ?>
          <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
        <?php } ?>  
   <!--  error message section--> 
        <div class="row">
          <div class="form-content">
            <div class="form-row">
              <div class="form-content-inner">
         <form action="<?=base_url()?>OrderMessage/save_data" method="post" >
         <input type="hidden" name="message_id" value="" id="message_id" >


                <div class="col-md-12 col-sm-12">
                  <div class="form-group form-left">

                 Message: <span class="star">*</span> <textarea class="form-control" name="message" data-validation="required"><?php echo $details[0]['massage']; ?></textarea>
                    </div>
                </div>

                  
                  <div class="clearfix"></div>
              
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" id="sub" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                    <a href="<?php echo base_url().'OrderMessage'; ?>" class="darkgrey btn-radius15 " title="Cancel">Cancel </a>
                </div>               
                <div class="clearfix"></div>
         </form>
      
         
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    lang: 'es'
  });
</script>



<?php
// echo "<pre>";
// print_r($details);
?>
