 <!--right side content section start here-->
      		<div class="page-content">
            	<div class="page-head">
                		<div class="page-main-head">
                        	<h1> Dashboard</h1>
                        </div>
                       
                        <div class="clearfix"></div>
                </div>
                  <div class="page-content-inner">
                		<div class="content-left">
                        	<div class="dashboard-content">
                        	
                            	<div class="container-fluid">
                                	<div class="row">
                                    	<div class="col-md-3 col-sm-3">
                                        	<a href="<?php base_url()?>Cupon">
                                        	<div class="circle"><i class="fa fa-user-plus" aria-hidden="true"></i> </div>
                                            <div class="circle-name">Add Cupons </div>
                                            </a>
                                        </div>
                                        
                                        <div class="col-md-3 col-sm-3">
                                      	  <a href="<?php base_url() ?>Users">
                                        	<div class="circle"><i class="fa fa-users" aria-hidden="true"></i></div>
                                            <div class="circle-name">View Customer  </div>
                                            </a>
                                        </div>
                                        
                                        <div class="col-md-3 col-sm-3">
                                        	<a href="<?php base_url() ?>Item/lists">
                                            <div class="circle"> <i class="fa fa-file-o" aria-hidden="true"></i>
</div>
                                            <div class="circle-name">View Items   </div>
                                            </a>
                                        </div>
                                        
                                        <div class="col-md-3 col-sm-3">
                                        	<a href="<?php base_url() ?>Orders"><div class="circle"><i class="fa fa-file-text" aria-hidden="true"></i></div>
                                            <div class="circle-name">View Orders </div>
                                            </a>
                                        </div>
                                        
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            
