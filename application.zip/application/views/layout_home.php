
<?php $this->load->view('layouts/header');?>
  
  <?php $this->load->view('layouts/left-menu');?>
   <?php  $this->load->view($content); ?>
  <?php $this->load->view('layouts/footer');?>
     