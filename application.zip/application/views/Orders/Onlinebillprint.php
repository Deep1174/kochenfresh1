<?php date_default_timezone_set("Asia/Calcutta");
    $order_id  = $_GET['id'];
    $sql       = " SELECT * FROM  kf_order orders left join kf_user user on user.user_id=orders.user_id left join  kf_order_items order_item on order_item.order_id=orders.order_id left join kf_item item on  order_item.item_id=item.item_id left join kf_item_price_unit price on price.id=order_item.unit_price_id left join kf_unit_master unit on unit.unit_id=price.unit_id where orders.order_id=".$order_id;
    $result        = $this->db->query($sql)->result_array();
    $curdateserver = date('d-m-Y h:i a')


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Elements Food</title>
        <link rel="shortcut icon" href="<?php echo base_url() ?>favicon.ico"></link>
        <style type="text/css">
            body {
                margin-left: 0px;
                margin-top: 0px;
                margin-right: 0px;
                margin-bottom: 0px;
                font-family:Verdana, Geneva, sans-serif;
                font-size:12px;
            }
            @media print {
                body {
                    margin-left: 0px;
                    margin-top: 0px;
                    margin-right: 0px;
                    margin-bottom: 0px;
                    font-family:Verdana, Geneva, sans-serif;
                    font-size:20px !important;
                }
                @media print {
                    a[href]:after {
                        content: none !important;
                    }

                } 
            </style>
            <style type="text/css" media="print">
                @page {
                    size: auto;   /* auto is the initial value */
                    margin: 0;  /* this affects the margin in the printer settings */
                }
            </style>
        </head>
       
        <body>
            <div style="width:284px; margin:0 auto; height:432px;">
               
                <div style="background:#fff; padding:5px; border:0px solid #4c916e; text-align:center;">
                  
                    <a href="<?php echo base_url(''); ?>Orders?from_date=<?= $_GET['from_date']?>&to_date=<?= $_GET['to_date']?>&name=<?= $_GET['name']?>&lname=<?= $_GET['lname']?>&status=<?= $_GET['status']?>&order_id=<?= $_GET['order_id']?>" onclick="" style="border:1px solid #3b454d; padding:6px 12px; display:inline-block; background:#3b454d; color:#fff; text-decoration:none;">Back</a>
                    <a href="#" style="border:1px solid #e32124; padding:6px 12px; display:inline-block; background:#e32124; color:#fff; text-decoration:none;" onClick="printdiv('div_print');">Print Bill</a>
                </div>
                <input type="hidden" class="printbillcount" value="<?= $fetch_number; ?>"/>
                <input type="hidden" class="billid" value="<?= $_GET['id']; ?>"/>
                <div class="print" style="text-align:right; padding-top:10px;">
                </div>

                <div class="print-div" id="div_print">
                    <div class="table-print" style="border-bottom:1px dashed #626161; padding-bottom:10px; margin-bottom:5px;">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#CCCCCC" style="border-collapse:collapse;" id="pdf_content"></table>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#CCCCCC" style="border-collapse:collapse;" id="pdf_content">
                            <tr>
                                <td style="padding:5px; text-align:center; font-weight:normal; font-size:18px; font-family:Verdana, Geneva, sans-serif;">
                                    <span style="font-size:13px;">Kochen Fresh </span>                           

                                </td>
                            </tr>

                            <tr>
                                <td style="padding:5px; text-align:center; font-weight:normal; font-size:18px; font-family:Verdana, Geneva, sans-serif;">
                                    <span style="font-size:13px;">[A Unit Of Aspire Services]</span>                           

                                </td>
                            </tr>


                            <tr>
                              <td style="padding:5px; text-align:center; font-weight:normal; font-size:13px; font-family:Verdana, Geneva, sans-serif;">GSTIN: 19APDPM3290A1Z4</td>
                            </tr>
                            <tr>
                                <td style="padding:5px; text-align:center; font-weight:normal; font-size:13px; font-family:Verdana, Geneva, sans-serif;">Buyer's Copy
                                   
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;">Order Number: <?php echo $result[0]['order_code']; ?></td>
                            </tr>


                           
                            <tr>
                                <td style="padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px; font-weight:normal;">Order Date: <?php echo date('d-m-Y h:i A',strtotime($result[0]['order_date'])); ?></td>
                            </tr>
                          <!-- <tr>
                             <?php $cutomer_details = $this->db->select('*')->where('user_id', $result[0]['user_id'])->get('kf_user')->result_array(); ?>
                                <td style="padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px; font-weight:normal;">Customer Details:<br> <?php echo $cutomer_details[0]['name'].' '.$cutomer_details[0]['lastname']; ?><br><?php echo  $result[0]['phone']; ?><br><?php echo $result[0]['pin_code']; ?><br><?php echo $result[0]['address']; ?></td>
                            </tr>-->
                             <tr>
                                <td style="padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px; font-weight:normal;">Shipping Details:<br> <?php echo $result[0]['shipping_first_name'].' '.$result[0]['shipping_last_name']; ?><br><?php echo  $result[0]['shipping_phone_number']; ?><br><?php echo $result[0]['shipping_zipcode']; ?><br><?php echo $result[0]['shipping_address']; ?></td>
                            </tr>
                           

                

                                <tr>
                                    <td style="padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;">Note :  <?php if($result[0]['note']!=''){echo $result[0]['note'];}else {echo 'N/A'; }  ?></td>
                                </tr>

                            <tr>
                                <td style="padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="16%"  style="font-weight:normal; text-align:left;">ITEM</td>
                                            <td width="24%" style="font-weight:normal; text-align:center;">QTY</td>
                                            <td width="29%" style="font-weight:normal; text-align:center;">RATE/UNIT </td>
                                            <td width="31%" style="font-weight:normal; text-align:right;">AMT(Rs.)</td>
                                        </tr>
                                        <?php 
                                      $item =   $this->db->select('*')->where('order_id', $order_id)->get('kf_order_items')->result_array(); 

                                         $this->db->last_query();
                                         $tot_price = 0;
                                         foreach ($item as $key => $item_details) {
                                             # code...
                                         
                                         ?>
                                      
                                            <tr>
                                              
                                                <td style="font-weight:normal; text-align:left; padding:5px 5px 5px 0; font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php 
                                                $item_name =$this->db->select('item_name')->where('item_id', $item_details['item_id'])->get('kf_item')->result_array();
                                                echo $item_name[0]['item_name'];
                                                ?></td>
                                                <td style="font-weight:normal; text-align:center; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $item_details['unit_type']; ?></td>
                                                <td style="font-weight:normal; text-align:center; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $item_details['unit_price']; ?></td>
                                                <td style="font-weight:normal; text-align:right; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo $item_details['price']; ?></td>
                                            </tr>
                                            <?php $tot_price = $item_details['price'] + $tot_price; ?>
                                          <?php } ?> 
                                            
                                          
                                        <tr>
                                            <td colspan="3" style="font-weight:normal; text-align:right; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;">Total </td>
                                            <td style="font-weight:normal; text-align:right; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;"> <?php echo number_format($tot_price, 2, '.', ''); ?></td>
                                        </tr>
                                                   
                                      
                                        <tr>
                                            <td colspan="3" style="font-weight:normal; text-align:right; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;">Discount</td>
                                            <td style="font-weight:normal; text-align:right; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php echo number_format($result[0]['discount_amount'], 2, '.', ''); ?></td>
                                        </tr>
                                         
                                        
                                      
                                        <tr>
                                            <td colspan="3" style=" border-bottom:1px dashed #626161;font-weight:normal; text-align:right; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;">Grand Total</td>
                                            <td style=" border-bottom:1px dashed #626161;font-weight:normal; text-align:right; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;"><?php  $grand_amount = $tot_price - $result[0]['discount_amount'];  ?>
                                            <?php echo number_format($grand_amount, 2, '.', ''); ?>
                                             </td>
                                        </tr>

                                    </table></td>
                            </tr>
                            <?php 
                                $randval         = 5;
                                $discountvalue   = $grand_amount * $randval/100+10;
                                $marketvalue     = number_format($discountvalue, 2, '.', '');
                                
                             ?>
                              <tr>
                                <td colspan="4" style="font-weight:normal; text-align:left; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:11px;">Total Saving: Rs <?= $marketvalue ?> from local market</td>


                            </tr> 
                            <tr>
                                 <td colspan="3" style=" border-bottom:1px dashed #626161;font-weight:normal; text-align:right; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:12px;"></td>


                            </tr> 
                           
                           <tr>
                                <td colspan="4" style="font-weight:normal; text-align:center; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:11px;"><table width="100%" border="0" cellspacing="2" cellpadding="2">
                                  <tr>
                                    <td>GST</td>
                                    <td>(%)</td>
                                    <td>BASE AMT(Rs.)</td>
                                    <td>TAX AMT(Rs.)</td>
                                  </tr>
                                  <?php
								  $basePrice=round(($total_price-(($total_price/105)*5)),2);
								  ?>
                                  <tr>
                                    <td>CGST</td>
                                    <td>2.5</td>
                                    <td><?php echo $basePrice; ?></td>
                                    <td><?php $totCGST=(($basePrice*2.5)/100); echo round($totCGST, 2); ?></td>
                                  </tr>
                                  <tr>
                                    <td>SGST</td>
                                    <td>2.5</td>
                                    <td><?php echo $basePrice; ?></td>
                                    <td><?php $totSGST=(($basePrice*2.5)/100); echo round($totSGST, 2); ?></td>
                                  </tr>
                                </table></td>
                          </tr>
                           <tr>
                             <td colspan="4" style="font-weight:normal; text-align:center; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:11px;">GST is included in the Selling price.</td>
                           </tr>
                           <tr>
                             <td colspan="4" style="font-weight:normal; text-align:center; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:11px;">Taxes shown separately are mandated by GST Regulations.</td>
                           </tr>
                           <tr>
                                <td colspan="4" style="font-weight:normal; text-align:center; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:11px;">This is being a computer generated bill,does not require any signature</td>


                            </tr>
                             
                            
                            <tr>
                                <td colspan="4" style="font-weight:normal; text-align:center; padding:5px; font-family:Verdana, Geneva, sans-serif; font-size:11px;">Print date & time : <?= $curdateserver; ?></td>
                            </tr>
                        </table>

                    </div>

                    <div class="print" style="text-align:right; padding-top:10px;">
                    </div>
                    <!--          <div class="print-div" id="div_print1">-->


                    </div>
                </div>
            </div>
            </div>
        </body>
    </html>
    <!-- pdf genarate-->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script language="javascript">
                        function printdiv(printpage)
                        {
                            var returnurl = '<?= base_url() ?>Orders?from_date=<?= $_GET['from_date']?>&to_date=<?= $_GET['to_date']?>&name=<?= $_GET['name']?>&lname=<?= $_GET['lname']?>&status=<?= $_GET['status']?>&order_id=<?= $_GET['order_id']?>';
                            var url = '<?= base_url() ?>Onlinebillprint/printbill';
                            var billcount = $('.printbillcount').val();
                            var billid = $('.billid').val();
                            // alert(checkfield);
                            $.ajax({
                                url: url,
                                type: 'POST',
                                data: {billcount: billcount, billid: billid},
                                success: function (responseText) {
                                    if (responseText == 1) {

                                    }
                                }
                            });
                            var headstr = "<html><head><title></title></head><body>";
                            var footstr = "</body>";
                            var newstr = document.all.item(printpage).innerHTML;
                            var oldstr = document.body.innerHTML;
                            document.body.innerHTML = headstr + newstr + footstr;
                            window.print(); 
                            document.location.href = returnurl;
                           document.body.innerHTML = oldstr;
                            return false;
                        }
    </script>
    <!-- pdf genarate-->