<!doctype html>
<html>
<head>
  <!-- Meta -->
  <meta charset="utf-8">
  <META name="robots" content="index,follow">
  <META name="author" content="">
  <META name="copyright" content="Copyright 2017">
  <META name="description" content="">
  <META name="keywords" content="">
  <meta name="revisit-after" content="7 days" />

  <title> Kochen Fresh </title>
  <!-- Mobile Meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1" user-scalable="no">
  <!-- Favicons -->
  <link rel="shortcut icon" href="<?= base_url()?>images/favicon.ico">
  <link rel="apple-touch-icon" href="<?=base_url()?>img/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="<?=base_url()?>img/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="<?=base_url()?>img/apple-touch-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="144x144" href="<?=base_url()?>img/apple-touch-icon-144x144.png">
  <!-- CSS -->
  <link rel="stylesheet" href="<?=base_url()?>css/datepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>css/bootstrap-datetimepicker.min.css">
  <link rel="stylesheet" type="text/css" href="<?=base_url()?>css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href="<?=base_url()?>css/bootstrap.min.css"/>
  <link href="<?=base_url()?>css/font-awesome.min.css" rel="stylesheet">
  <link href="<?=base_url()?>css/style.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" type="text/css" href="<?=base_url()?>css/jquery.accordion.css">
  <link rel="stylesheet" href="<?php echo base_url();?>css/calender/jquery-ui.css" />
  </head>

<body>
		
<!--////////////////////////header start here////////////////////////-->
<header>
	<div class="container-fluid">
  	<div class="row">
	 	  <div class="col-md-6 col-sm-6">
      		<div class="logo"><img src="<?=base_url()?>images/logo.png"  alt="logo"></div>
            <div class="menu-icon"> <a href="#menu-toggle"  id="menu-toggle"><i class="fa fa-bars" aria-hidden="true"></i></a> </div>
            <div class="clearfix"></div>
      </div>
   	  <div class="col-md-6 col-sm-6">
      	<ul class="setting_message">
          <li class="setting-menus">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
              <div class="profile_img">
                <img src="<?=base_url()?>images/user-name-icon.png" width="34" height="34">
              </div>
              <?php        
                $user_id = $this->session->userdata('kf_user_id');
                $login_details = $this->db->select('*')->where('id', $user_id)->get('kf_admin_user')->result_array();
                $name = $login_details[0]['name'];
              ?>
              <div class="user_name"><?php echo $name; ?><i class="fa fa-angle-down lnr"></i></div>   
             	</a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo base_url();?>ChangePassword"> <i class="fa fa-key" aria-hidden="true"></i> Change password</a></li>
                <li><a href="<?php echo base_url(); ?>Logout"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
              </ul>
              </li>
              <li class="">
                <?php  //$ep_company_id = $this->session->userdata('ep_company_id'); ?>
                <div class="user_name comp_name"><?php //echo get_comp($ep_company_id); ?></div>
              </li>
          </ul>
        <div class="clearfix"></div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</header>
<!--////////////////////////header end here////////////////////////-->