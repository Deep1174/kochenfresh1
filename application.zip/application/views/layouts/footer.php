 </div>
        
        
     <!--/////////////////////////////////////footer start here/////////////////////////-->
     
     <footer>
     <p>&copy; <?php echo date('Y');?> All rights reserved. </p>
     </footer>
     
     <!---////////////// mod of payment pop up ////////--->
         
     <!---////////////// mod of payment pop up ////////---> 
     
     <!---////////////// mod of payment pop up ////////--->
         
     <!---////////////// mod of payment pop up ////////--->  
                                           
     <!--/////////////////////////////////////footer end here/////////////////////////-->
        <!--////////////////////////////////// js////////////////////////////-->     
 <!--<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>-->
<script src="<?=base_url()?>js/jquery-1.9.1.min.js"></script>
<script src="<?php echo base_url(); ?>css/calender/jquery-ui.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/bootstrap.min.js"></script>
<script src="<?=base_url()?>js/bootstrap-filestyle.min.js"></script>
 <script src="<?php echo base_url(); ?>js/moment.min.js"></script>
<script src="<?php echo base_url(); ?>js/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo base_url(); ?>js/moment.min.js"></script>

   <!-- <script type="text/javascript">
            // When the document is ready
            $(document).ready(function () {
                
    //             $('.datepicker').datepicker({
    //                 format: "dd/mm/yyyy",
					
    //             }); 
				
				
                
    //             $('#applicationdate').datepicker({
    //                 format: "mm/dd/yyyy"
    //             }); 
				
				
    //             $('#leavingndate').datepicker({
    //                 format: "mm/dd/yyyy"
    //             });   
    //          $('#currenttc').datepicker({
    //                 format: "mm/dd/yyyy"
    //             }); 
				// $('#Currentlvdate').datepicker({
    //                 format: "mm/dd/yyyy"
    //             }); 
				// $('#attendence-current-from').datepicker({
    //                 format: "mm/dd/yyyy"
    //             }); 
				// $('#attendence-current-to').datepicker({
    //                 format: "mm/dd/yyyy"
    //             }); 
    //         });

    //         $('.starting_date').datepicker({
    //         minDate: 0,
    //         dateFormat: 'dd/mm/yy',
    //         onSelect: function (dateStr) {

    //             var date = $(this).datepicker('getDate');
    //             if (date) {
    //                 date.setDate(date.getDate() + 1);
    //             }
    //             $('.ending_date').datepicker('option', 'minDate', date);
    //         }
    //         });

    //         $('.ending_date').datepicker({
    //         minDate: 0,
    //         dateFormat: 'dd/mm/yy',
    //         onSelect: function (selectedDate) {
    //             var date = $(this).datepicker('getDate');
    //             if (date) {
    //                 date.setDate(date.getDate());
    //             }
    //             $('.starting_date').datepicker('option', 'maxDate', date || 0);
    //         }
    //     });
			
			$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
        </script>
        
        
       



<!--left side accordian-->
 <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> -->
 <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script> 
<script>
    $.validate({
        lang: 'en'
    });
</script>
    <script type="text/javascript" src="<?=base_url()?>js/jquery.accordion.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
        $('#only-one [data-accordion]').accordion();

        $('#multiple [data-accordion]').accordion({
          singleOpen: false
        });

        $('#single[data-accordion]').accordion({
          transitionEasing: 'cubic-bezier(0.455, 0.030, 0.515, 0.955)',
          transitionSpeed: 200
        });
      });
    </script>
     <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("body").toggleClass("toggled");
    });
    </script>
	<script>
 $('#leave_value').keypress(function(event){

       if(event.which != 8 && isNaN(String.fromCharCode(event.which))){
           event.preventDefault(); //stop character from entering input
       }

   });
   
</script>

<script type="text/javascript">

$(document).ready(function(){
$("#from").datepicker({
            minDate: "dateToday",
            changeMonth: true,
            changeYear: true,
            yearRange: '0:+50',
            dateFormat: 'dd-mm-yy',
            // onClose: function (selectedDate, instance) {
            //     if (selectedDate != '') { //added this to fix the issue
            //         $("#to").datepicker("option", "minDate", selectedDate);
            //         var date = $.datepicker.parseDate(instance.settings.dateFormat, selectedDate, instance.settings);
            //         //date.setMonth(date.getMonth() + 1); // 1 month interval
            //         console.log(selectedDate, date);
            //         $("#to").datepicker("option", "minDate", selectedDate);
            //        // $("#to").datepicker("option", "maxDate", date);
            //     }
            // }
            onSelect: function (selectedDate) {

                var date = $(this).datepicker('getDate');
               // alert(date);
                if (date) {
                  $('#to').removeAttr('disabled');
                    date.setDate(date.getDate());

                    url = "<?php echo base_url() ?>AssignTask/no_of_days_count";
                    from_date=$('#from').val();
                    to_date=$('#to').val();
                    //alert(from_date);
                   // alert(to_date);
                   // if(to_date!='')
                   {
                         $.ajax({
                        method: "POST",
                        url: url,
                        dataType: "json",
                        data: {'from_date': from_date,'to_date':to_date},
                        beforeSend: function (jqXHR, settings) {
                         // alert(url);

                        },
                        success: function (data, textStatus, jqXHR) {
                          if(to_date!='')
                          {
                            $('#duration').val(data['no_of_days']);
                          }
                          
                        }

                      });
                  }
                   

                }
                else
                {
                  $('#to').attr('disabled','disabled');
                }
                $('#to').datepicker('option', 'minDate', date);
            }
        });
        $("#to").datepicker({
            minDate: "dateToday",
            changeMonth: true,
            changeYear: true,
            yearRange: '0:+50',
            dateFormat: 'dd-mm-yy',
            // onClose: function (selectedDate) {
            //     $("#from").datepicker("option", "maxDate", selectedDate);
            // }
            onSelect: function (selectedDate) {

                var date = $(this).datepicker('getDate');
                if (date) {
                    date.setDate(date.getDate());
                    url = "<?php echo base_url();?>AssignTask/no_of_days_count";
                    from_date=$('#from').val();
                    to_date=$('#to').val();
                    //emp_id=$('#hidden_employee_id').val();

                   

                   $.ajax({
                    method: "POST",
                    url: url,
                    dataType: "json",
                    data: {'from_date': from_date,'to_date':to_date},
                    beforeSend: function (jqXHR, settings) {
                   //   alert(url);
                   //    alert(from_date);
                   // alert(to_date);

                    },
                    success: function (data, textStatus, jqXHR) {
                     // alert(data);
                      $('#duration').val(data['no_of_days']);
                    }

                  });
                }
                $('#from').datepicker('option', 'maxDate', date || 0);
            }
        });
});


</script> 




</body>
</html>
<!-- approval section-->
<div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog popup_box view_purchase_popup"> 
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title req_modal_heading">Delevery Mark Status</h4>
        </div>
        <div class="modal-body">
          <div class="data_content approval_popup">
           <form action="<?php echo base_url();?>Orders/change_mark" method="post" name="approval-form">
             <div class="col-lg-8 col-centered">
              <div class="form-group">
               <label class="col-sm-2">Status<span>*</span></label>
               <div class="col-md-10">
                <select class="form-control" name="status" id="status">               
                 <option value="1">Out For Delevery</option>
				  <option value="3">Deleverd</option>
                 <option value="4">Return</option>
				 <option value="0">Pending</option>
                </select>
               </div>
               <div class="clearfix"></div>
              </div>
              
              <div class="form-group">
                <label class="col-sm-2">&nbsp;</label>
               <div class="col-md-10">
                 
                 <input type="hidden" name="order_id" value="" id="order_id">
                 <input  class="form-control" type="submit" value="Submit" class="aproval_submit">
               </div>
               <div class="clearfix"></div>
              </div>
             </div>
            </form> 
           </div>  
        </div>
		<div class="clearfix"></div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default close_button" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
<!-- end approval section-->