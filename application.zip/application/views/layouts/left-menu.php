 <div class="page-container">
      
      <!--left menu section start here-->
    		  <div id="left-panel">
                <nav class="navbar navbar-default">
              <!-- Brand and toggle get grouped for better mobile display -->
  			  <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
      
    		</div>
               <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <section id="only-one" data-accordion-group>
<?php
$controller_name = $this->router->fetch_class();
$cmethod_name = $this->router->fetch_method();
?>
              
        			<ul class="page-sidebar-menu">
               
                 		 <li><a <?php if ($controller_name == "Dashboard") { ?> class="active" <?php } ?> href="<?php echo base_url(); ?>Dashboard" title="Dashboard" ><i class="fa fa-tachometer" aria-hidden="true"></i>Dashboard</a></li>

                      <li>
            <a <?php if ($controller_name == "GlobalSetting") { ?> class="active" <?php } ?> href="<?php echo base_url();?>GlobalSetting" title="Global Setting" data-control><i class="fa fa-cogs" aria-hidden="true"></i>Global Setting</a>
           </li> 

  		    
                      <li  ><a <?php if ($controller_name == "CODPinMaster") { ?> class="active" <?php } ?> href="<?php echo base_url();?>CODPinMaster" title="Manage Delivery PIN" data-control> <i class="fa fa-map-pin" aria-hidden="true"></i>Manage Delivery PIN</a>
                      </li> 

                      <li><a <?php if ($controller_name == "Cupon") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Cupon" title="Manage Coupon" data-control> <i class="fa fa-ticket" aria-hidden="true"></i>Manage Coupon</a>
                      </li>

                      <li><a <?php if ($controller_name == "Banner") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Banner" title="Manage Banner" data-control> <i class="fa fa-list" aria-hidden="true"></i> Manage Banner</a>
                      </li>

                       <li><a <?php if ($controller_name == "FAQ") { ?> class="active" <?php } ?> href="<?php echo base_url();?>FAQ" title="Manage FAQ" data-control> <i class="fa fa-comments-o" aria-hidden="true"></i> Manage FAQ</a>
                      </li>
  			       
                      <li  ><a <?php if ($controller_name == "UnitMaster") { ?> class="active" <?php } ?> href="<?php echo base_url();?>UnitMaster" title="Manage Unit" data-control> <i class="fa fa-yelp" aria-hidden="true"></i>Manage Unit</a>
                      </li>

                     <li ><a <?php if ($controller_name == "Category") { ?> class="active" <?php } ?> href="<?php echo base_url(); ?>Category" title="Manage Category "><i class="fa fa-bars" aria-hidden="true"></i> Manage Category </a>
                            </li>
                     		<!-- <li><a <?php // if ($controller_name == "SubCategory") { ?> class="active" <?php //} ?> href="<?php // echo base_url();?>SubCategory" title="Manage Sub Category"> <i class="fa fa-list" aria-hidden="true"></i> Manage sub Category </a>
                            </li> -->
                       
  			  <li data-accordion <?php if($controller_name == "Item" || $controller_name == "Item/lists" || $controller_name == "SetItemPrice"){?> class="open" <?php } ?> ><a href="javascript:void(0);" title="Manage Item" data-control><i class="fa fa-cubes" aria-hidden="true"></i>Manage Item</a>
              <ul  class="submenu" data-content>
                  <li><a <?php if ($controller_name == "Item" && $cmethod_name == "index") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Item" title="Add Item"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Item </a></li>
                  <li><a <?php if ($controller_name == "Item" && $cmethod_name == "lists") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Item/lists" title="View Item"><i class="fa fa-eye" aria-hidden="true"></i> View Item</a></li>
  			         <!--  <li><a <?php if ($controller_name == "SetItemPrice" ) { ?> class="active" <?php } ?> href="<?php echo base_url();?>SetItemPrice" title="View Item"><i class="fa fa-inr" aria-hidden="true"></i> Set Item Price</a></li> -->
              </ul>
          </li>

  			<li><a <?php if ($controller_name == "Users") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Users" title="Manage Customer" data-control> <i class="fa fa-user" aria-hidden="true"></i>Manage Customer</a>
                      </li>

                    <li><a <?php if ($controller_name == "SetPrice") { ?> class="active" <?php } ?> href="<?php echo base_url();?>SetPrice" title="Manage Set Minimum Price" data-control> <i class="fa fa-money" aria-hidden="true"></i>Set Minimum Price</a>
                      </li>

                      <li><a <?php if ($controller_name == "OrderMessage") { ?> class="active" <?php } ?> href="<?php echo base_url();?>OrderMessage" title="Manage Set Order Message" data-control><i class="fa fa-envelope" aria-hidden="true"></i>Set Order Message</a>
                      </li>  

           <li>
            <a <?php if ($controller_name == "DeliveryTime") { ?> class="active" <?php } ?> href="<?php echo base_url();?>DeliveryTime" title="Manage Store Close / Open" data-control><i class="fa fa-truck" aria-hidden="true"></i>Store Close / Open</a>
          </li>  
          
          <li><a <?php if ($controller_name == "ContactUs") { ?> class="active" <?php } ?> href="<?php echo base_url();?>ContactUs" title="Manage Contact Us" data-control><i class="fa fa-users" aria-hidden="true"></i>Manage Contact Us</a>
          </li>
           <li><a <?php if ($controller_name == "Feedback") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Feedback" title="Manage Feedback" data-control><i class="fa fa-comments-o" aria-hidden="true"></i>Manage Feedback</a>
          </li>
    		  <li><a <?php if ($controller_name == "Orders") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Orders" title="Manage Order List" data-control><i class="fa fa-server" aria-hidden="true"></i>Order List</a>
          </li>

          <li><a <?php if ($controller_name == "Placeorder") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Placeorder" title="Manage Order List" data-control><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Place Order </a>
          </li>




           <li><a <?php if ($controller_name == "SalesReport") { ?> class="active" <?php } ?> href="<?php echo base_url();?>SalesReport" title="Sales Report" data-control><i class="fa fa-copy" aria-hidden="true"></i>Sales Report</a>
          </li>

          <!--  <li><a <?php if ($controller_name == "PendingDelivery") { ?> class="active" <?php } ?> href="<?php echo base_url();?>PendingDelivery" title="PendingDelivery" data-control><i class="fa fa-clock-o" aria-hidden="true"></i>Pending Delivery</a>
          </li> -->

          <li><a <?php if ($controller_name == "Pending_orders") { ?> class="active" <?php } ?> href="<?php echo base_url();?>Pending_orders" title="Pending Orders" data-control><i class="fa fa-clock-o" aria-hidden="true"></i>Pending Orders</a>
          </li>
                        
        </ul>
      </section>
    </div>
  </nav>
</div>