<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1> View Contact Us</h1>
    </div>
    <div class="clearfix"></div>
  </div>

<?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?> 

  <div class="form_section">
    <form action="<?=base_url()?>ContactUs" method="get" name="search-form">
    <div class="container-fluid">
      <div class="row">
        <div class="form-content">
          <div class="form-row category-form">
            <h2>Search</h2> 
              <div class="form-content-inner">
                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <label for="name"> Search </label>
                    <input type="text" class="form-control" name="search" placeholder="Search by name / email / phone no" value="<?=$this->input->get('search')?>">
                  </div>
                </div>
                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">
                    <label>Status </label>
                    <select name="status" class="form-control">
                      <option value="">Select Status</option>
                      <option value="0" <?php if($this->input->get('status') == '0'){echo"selected";} ?>>Unread</option>
                      <option value="1" <?php if($this->input->get('status') == '1'){echo"selected";} ?>>Read</option>
                    </select>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                    <input name="" type="submit" value="Search" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
                </div>
              <div class="clearfix"></div>
            </div>     
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>

  <div class="search-result">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="table-responsive">
            <div class="search-result-table" id="div-tab">
            <?php if(!empty($result) && count($result)>0){ ?>
                <table class="table table-bordered table-striped" id="tab">
                  <thead class="thead-inverse">
                    <tr>
                      <th><div class="headname">Sl No. </div></th>
                      <th><div class="headname">Name</div></th>
                      <th><div class="headname">Email</div></th>
                      <th><div class="headname">Phone No.</div></th>
                      <th><div class="headname">Status</div></th>
                      <th>Action</th>
                    </tr>
                  </thead>
                <tbody>
                <?php
                  foreach($result as $val){
                    //echo "<pre>";print_r($val);
                ?>
                  <tr>
                    <th scope="row"><?php echo $page+1;?></th>
                    <td><?php echo isset($val['name'])?$val['name']:'';?></td>
                    <td><?php echo isset($val['email'])?$val['email']:'';?></td>
                    <td><?php echo isset($val['phn_no'])?$val['phn_no']:'';?></td>
                    <td id="msg<?=$val['id']?>">
                      <?php if($val['status'] == 1)
                      {
                        echo'Read';
                      }	else {
                        echo'Unread';
                      }
                      ?>
                    </td>
                    <td>
                      <a href="<?php echo base_url()?>ContactUs/delete/<?php echo isset($val['id'])?$val['id']:'';?>" class="delete" title="Delete" onclick="return confirm('Are you sure you want to delete it ?')"><i class="fa fa-trash-o" aria-hidden="true"></i>
                    <!--view popup-->
                      <a href="javascript:void(0);" class="view button" title="View Message" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" onclick="view_details(<?php echo $val['id'];?>)"><i class="fa fa-eye" aria-hidden="true">
                    </i></a>
                    </td>
                  </tr>
                <?php 
                  $page++;
                  }
                ?>
                </tbody>
              </table>
            <?php } else {
                echo "<center> <h1> No Data Found </h1></center>";
            } ?>
            </div>
          </div>
        </div>
        <div class="col-md-12">
          <div class="pagination-data text-center">
            <ul class="pagination">
              <?php echo $link;?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>                
</div>

<!-- pop up-->
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content"  id="details_view"></div>
  </div>
</div>

<script>
function view_details(id)
  {
    var url = '<?php echo base_url();?>ContactUs/details_by_id';

    $.ajax({
      method:"GET",
      url:url,
      data: {'id': id},
      success: function (data){
        $('#details_view').html(data);      
 $('#msg'+id).text('Read');		
      }
  });
  $('.view_buttn').attr('data-target',"#myModal");
  
 
}
</script>
<!-- End pop up-->
<script>
function reset_page() {
 window.location.href='<?php echo base_url();?>ContactUs';
}
</script>
