
          <div class="page-content">
              <div class="page-head">
                    <div class="page-main-head">
                          <h1> View Wish List</h1>
                        </div>
                        
                        <div class="clearfix"></div>
                </div>
              
                  <div class="form_section">
                    <form  method="get" name="search-form">
                        
                        <div class="container-fluid">
                               <div class="row">
                                  <div class="form-content">
                                      
                                      <div class="form-row category-form">
                                            <h2>Search</h2> 
                                            
                                            <div class="form-content-inner">
                                                            
                                                   <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-left">
                                                                    
                                                                        <label for="name">User Name </label>
                                                                   <input type="text" class="form-control" name="name" id="name" placeholder="Enter User Name" value="<?=$this->input->get('name')?>">
                                                                </div>
                                                         </div>
                                                         
                                                   <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-right">
                                                                    
                                                                        <label for="itemname">Item Name </label>
                                                                   <input type="text" class="form-control" id="item" name="item" placeholder="Enter Item Name" value="<?=$this->input->get('item')?>">
                                                                   
                                                                   
                                                                </div>
                                                       </div>            
                                                    <div class="clearfix"></div>
													
                                              
                                                  <div class="col-md-6 col-sm-6">
                                                                <input name="" type="submit" value="Search" class="yellow btn-radius15 ">
                                                              
                                                             </div>
                                                             <div class="col-md-6 col-sm-6">
                                                               <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
                                                        
                                                      
                                                             </div>
                                                             
                                                        <div class="clearfix"></div>
                                                            
                                            </div>     
                                        </div>
                                        
                                    </div>
                                 </div>
                          </div>
                     </form>
           
           
            </div>
            
                <div class="search-result">
                      <div class="container-fluid">
                          <div class="row">
                                
                                
                           
                              <div class="col-md-12">
                                 <div class="table-responsive">
                                
                                  <div class="search-result-table">
                                  <?php  if(!empty($all_wish['result'])){
              
           ?>
                                      <table class="table table-bordered table-striped">
                                      <thead class="thead-inverse">
                                        <tr>
                                          <th>
                                          <div class="headname">Sl No. </div>
                                          </th>
                      										<th><div class="headname">User Name </div></th>
                                          <th><div class="headname">Item Name</div></th>
                                          <th><div class="headname">Quantity</div></th>
                                          <th><div class="headname">Unit</div></th>
									                        
                                        </tr>
                                      </thead>
                                      <tbody>
                                      <?php foreach($all_wish['result'] as $k=>$val){?>
                                        <tr>
                                          <th scope="row"><?= $k+$page+1?></th>
										 
                                          
                                          <td><?php $val['user_id']?><?=$val['name']?></td>
                                          <td><?php $val['item_id']?><?=$val['item_name']?></td>
                                          <td><?= $val['quantity']?></td>
                                          <td><?php $val['unit_id']?><?=$val['unit_name']?></td>
                                          </tr><?php } ?>
                                        
                                       
                                      </tbody>
                               </table><?php } ?>
        
                                    </div>
                                
                                
                                </div>
                                
                                </div>
                                
                                <div class="col-md-12">
                                  <div class="pagination-data text-center">
                                         <ul class="pagination">
										
                                              <?php echo $link;?>
											 
                                            </ul>
                                    </div>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
           
                                    
    </div>

    

<script>
function reset_page()
{
	
	window.location.href='<?= base_url()?>WishList';
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

  
    
        
        
    
     
    