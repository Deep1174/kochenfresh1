<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Manage Sub Category</h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
   <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--  error message section-->  
      <div class="container-fluid">
        <div class="row">
          <div class="form-content">
            <div class="form-row">
			
              <div class="form-content-inner">
         <form action="<?=base_url()?>SubCategory/save" method="post">
					<div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <label for="designationname">  Category Name <span class="star">*</span> </label>
                    <select class="form-control" id="cat_id" name="cat_id" data-validation="required" data-validation-error-msg="Please select Category">
                    <option>select Category</option>
					<?php if(!empty($category_list)){
							foreach($category_list as $val){
					?>
					<option value="<?=$val['cat_id'] ?>"><?=$val['cat_name'] ?></option>
					<?php } } ?>
					</select>
                </div>
				</div>
                <div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <label for="designationname"> Sub Category Name <span class="star">*</span> </label>
                    <input type="text" class="form-control" id="sub_cat_name" placeholder="Enter Category Name" name="sub_cat_name" data-validation="required" data-validation-error-msg="Please Enter Sub Category Name ">
                    <input type="hidden" name="sub_cat_id" value="" id="sub_cat_id" >
                </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  
          <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>
         </form>
         <!-- designation list-->
         <?php  if(!empty($sub_cat_list_list)){
              
           ?>
                <div class="small-table-content">
                  <div class="col-md-12">
                    <div class="form-group">
                      <table class="table table-bordered  table-striped">
                        <thead class="thead-inverse">
                          <tr>
                            <th>Sub Category Name</th>
							<th> Category</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
						<?php foreach($sub_cat_list_list as $k=>$val){ 
						  $cat_name= getwhere1('kf_category','cat_id',$val['cat_id']);
						
						?>
                          <tr>
                            <td><?= $val['sub_cat_name']?></td>
							<td><?= isset($val['cat_name'])?$val['cat_name']:'N/A'?></td>
                            <td><a onclick="edit_company(<?= $val['cat_id']?>,'<?= $val['sub_cat_name']?>','<?= $val['parent_id']?>')" href="javascript:void(0);" class="edit" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i> </a>  
                            <a href="<?=base_url()?>SubCategory/delete/<?= $val['cat_id']?>" class="delete" title="Delete" onclick="return confirm('Are you sure you want to delete ?')"><i class="fa fa-trash-o" aria-hidden="true"></i> </a></td>
                          </tr>
						<?php } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="clearfix"></div>
                </div>
         <?php } ?>
         <?php echo $link;?>
        <!-- designation list -->
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script>
  function edit_company(id,name,cat_id)
  {
    $('#head').html(" Edit Sub Category");
    $('#sub_cat_name').val(name);
    $('#cat_id').val(cat_id);
	$('#sub_cat_id').val(id);
  }
   function cancel()
  {
    $('#head').html(" Manage Sub Category");
    $('#sub_cat_name').val('');
    $('#sub_cat_id').val('');
	$('#cat_id').val('');
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

