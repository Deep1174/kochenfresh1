<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Global Setting </h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
  
      <div class="container-fluid">
    <!-- error message section -->
         <?php if($this->session->flashdata('fail')!=''){ ?>
          <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
        <?php } ?>  
        <?php if($this->session->flashdata('success')!=''){ ?>
          <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
        <?php } ?>  
   <!--  error message section--> 
        <div class="row">
          <div class="form-content">
            <div class="form-row">
              <div class="form-content-inner">
         <form action="<?=base_url()?>GlobalSetting/save_data" method="post" >
         <input type="hidden" name="delivery_id" value="" id="delivery_id" >


                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">

                 Phone <input type="text" class="form-control delivery" name="phone"  value="<?php echo $details[0]['phone']; ?>"  maxlength="10" >

                <!--   Note:   <textarea class="form-control" name="note"></textarea> -->
                    </div>
                </div>

                  <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">

                 Email <span class="star">*</span> <input type="text" class="form-control"  name="email"  data-validation="email" data-validation-help="e.g - email@gmail.com" value="<?php echo $details[0]['email']; ?>">

                <!--   Note:   <textarea class="form-control" name="note"></textarea> -->
                    </div>
                </div>
                  <div class="clearfix"></div>
              
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" id="sub" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                    <a href="<?php echo base_url().'GlobalSetting'; ?>" class="darkgrey btn-radius15 " title="Cancel">Cancel </a>
                </div>               
                <div class="clearfix"></div>
         </form>
      
         
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    lang: 'es'
  });
</script>

<script>
  $(function () { //alert("ol");
    $('.delivery').on('input', function (e){ //alert("olsw");
      this.value = this.value.replace(/[^0-9\.]/g,'');
    });
  });
</script>



