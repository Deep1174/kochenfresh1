<div class="page-content">
<div class="page-head">
<div class="page-main-head">
<h1> View Item List</h1>
</div>

<div class="clearfix"></div>
</div>
<?php
// echo "<pre>";
// print_r($result);
$shipping_details = $this->db->where('user_id',$result[0]['user_id'])->get('kf_shipping')->result_array();
// echo "<pre>";
// print_r($shipping_details);
?>

<div class="search-result">
 
<div class="container-fluid">
<div class="row">
  <div class="col-md-12">
      <div class="search-result-table">
        <div class="row" style="margin-bottom: 25px; padding: -15px 10px 0 10px;">
        <div class="col-md-12" style="font-weight: bold; padding: 10px 0 20px 0;">
        <center>
          <u>Shipping Details</u>
        </center>
          
        </div>
          <div class="col-md-3" style="font-weight: bold;">
            Order Placed:
          </div>
          <div class="col-md-3">
            <?php echo date('d-m-Y H:i A',strtotime($result[0]['order_date'])); ?>
          </div>

          <div class="col-md-3" style="font-weight: bold;">
            Order Id: 
          </div>
          <div class="col-md-3"><?= $code ?></div>
           <div class="col-md-12" style="padding: 7px;"></div><div class="clearfix"></div>
          <div class="col-md-3" style="font-weight: bold;">
             Name:
          </div>
          <div class="col-md-3">
            <?php echo $result[0]['shipping_first_name']." ".$result[0]['shipping_last_name']; ?>
          </div>
          <div class="col-md-3" style="font-weight: bold;"> Phone No: </div>
          <div class="col-md-3">
            <?php echo $result[0]['shipping_phone_number'] ?>
          </div>
          <div class="col-md-12" style="padding: 7px;"></div><div class="clearfix"></div>
          <div class="col-md-3" style="font-weight: bold;">
            Pin Code: 
          </div>
          
          <div class="col-md-3">
            <?php echo $result[0]['shipping_zipcode'] ?>
          </div>
          <div class="col-md-3" style="font-weight: bold;">
            Address: 
          </div>

          
          <div class="col-md-3">
            <?php echo $result[0]['shipping_address'] ?>
          </div> 
           <div class="col-md-12" style="padding: 7px;"></div><div class="clearfix"></div>  
           <div class="col-md-3" style="font-weight: bold;">
            Delivery Date: 
          </div>
          
          <div class="col-md-3">
          <?php if($result[0]['delivery_date']=='0000-00-00')
          {
           echo 'N/A'; 
          } else {
           echo date('d-m-Y',strtotime($result[0]['delivery_date']));
            } ?>
          </div>

           <div class="col-md-12" style="padding: 7px;"></div><div class="clearfix"></div>  
           <div class="col-md-3" style="font-weight: bold;">
            Payment Date: 
          </div>
          
          <div class="col-md-3">
          <?php if($result[0]['payment_date']=='0000-00-00')
          {
           echo 'N/A'; 
          } else {
           echo date('d-m-Y',strtotime($result[0]['payment_date']));
            } ?>
          </div>

          






        <?php if(!empty($result[0]['note'])) { ?> <div class="col-md-12" style="padding: 7px;"></div><div class="clearfix"></div>
         <div class="col-md-3" style="font-weight: bold;">
            Note:
          </div>
         <div class='col-md-12' >
              <?php echo $result[0]['note'] ?>
          </div> 
         <?php } ?>
           
            
          <!--  <div class="col-md-3">
            <?php echo $result[0]['delivery_date']; ?>
          </div> -->
          
          <div class="clearfix"></div>
        </div>
      		
			<?php if(!empty($result)){?>
       		<table class="table table-bordered  table-striped">
                   <thead class="thead-inverse">
                   			<th>SL No.</th>
                            <th>Item</th>
                            <th>Unit</th>
                            <th>Unit Price</th>
							<th>Quantity</th>
							<th>Total Price</th>
                        </thead>
             			<tbody>
						<?php
						$grand_total =0;
						foreach($result as $k=>$val){ 
            
              ;?>
                        	<tr>
                            	<th><?= $k+1?></th>
                            	  <td><?= $val['item_name']?></td>
                                <td><?= $val['unit_value']?> <?= $val['unit_name']?>.</td>
                                <td><?= number_format($val['price'],2)?>/-</td>
								<td> <?= $val['quantity']?> <?= $val['unit_name']?> </td>
								<td><?= number_format($total = $val['quantity'] *  $val['price'],2); ?>/-</td>
                            </tr>
                        <?php 
						$grand_total = $grand_total + $total;
						} ?>   
                            <tr>
                            	<th colspan="5" style="text-align:right;">Total</th>
                                <th><?= number_format($grand_total,2)?></th>
                            </tr>
                        </tbody>
              </table>
			<?php } ?>
			<div class="col-md-12 text-right"><a href=" <?php echo $_SERVER['HTTP_REFERER']; ?>" class="btn darkgrey btn-radius15 bck-btn" style="width:120px; background:#000; margin-bottom:20px;">Back</a></div>
           
        </div>
    </div>
    
</div>
</div>
</div>
</div>

<?php
// echo "<pre>";
// print_r($result);exit();
?>