<div class="page-content">
<div class="page-head">
<div class="page-main-head">
<h1> View Item List</h1>
</div>

<div class="clearfix"></div>
</div>

<div class="form_section">
<form action="<?=base_url()?>Item/lists" method="GET">
  <div class="container-fluid">
   <div class="row">
    <div class="form-content">
      <div class="form-row category-form">
        <h2>Search</h2>
          <div class="form-content-inner">
            <div class="col-md-6 col-sm-6">
              <div class="form-group form-left">
                <label for="name"> Item Name </label>
                  <input type="text" class="form-control" name="item_name" id="item_name" placeholder="Enter Item Name" value="<?=$this->input->get('item_name');?>">
              </div>
            </div>
            <div class="col-md-6 col-sm-6">
              <div class="form-group form-right">
                <label for="department">Category </label>
                  <select class="form-control" id="cat_id" name="cat_id" >
                  <option value="">select Category</option>
                  <?php if(!empty($category)){
                    foreach($category as $val){
                  ?>
                  <option value="<?php echo $val['cat_id'];?>" <?php if($val['cat_id']==$this->input->get('cat_id')){ echo"selected";}?>><?php echo isset($val['cat_name'])?$val['cat_name']:'';?></option>
                  <?php } } ?>
                  </select>
              </div>
            </div>
            <div class="clearfix"></div>
           <!--  <div class="col-md-6 col-sm-6">
            <div class="form-group form-left">
            <label for="designation"> Sub Category </label>
            <select class="form-control" id="cat_id" name="Sub_cat_id"  >
              <option value="">select Category</option>
              <?php if(!empty($subCategory)){
                  foreach($subCategory as $val){
              ?>
              <option value="<?php echo $val['sub_cat_id'];?>" <?php if($val['sub_cat_id']==$this->input->get('Sub_cat_id')){ echo"selected";}?>><?php echo isset($val['sub_cat_name'])?$val['sub_cat_name']:''?></option>
              <?php } } ?>
              </select>
              </div>
              </div>   -->          
              <div class="clearfix"></div>
              <div class="col-md-6 col-sm-6">
                <input name="" type="submit" value="Search" class="yellow btn-radius15 ">
              </div>
              <div class="col-md-6 col-sm-6">
                <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
              </div>
            <div class="clearfix"></div>
          </div>     
        </div>
      </div>
    </div>
  </div>
</form>
</div>

<div class="search-result">
  <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--error message section--> 
<div class="container-fluid">
<div class="row">
  <div class="col-md-12">
     <div class="">
      <div class="search-result-table">
        <?php if(!empty($all_Item['result']) & count($all_Item['result'])>0) { ?>
          <table class="table table-bordered table-striped">
            <thead class="thead-inverse">
              <tr>
                <th>
                  <div class="headname">Sl No. </div>
                </th>
                <th><div class="headname">Item Name </div></th>
                <th><div class="headname">Item Image </div></th>
                <th><div class="headname">Category Name</div>
                </th>
                
                <th><div class="headname">Item Description</div></th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
                foreach($all_Item['result'] as $value) {
                  //echo "<pre>";print_r($value);
                  $img = $value['img_name'];
              ?>
              <tr>
                <th scope="row"><?php echo $page+1;?></th>
                <td><?php echo isset($value['item_name'])?$value['item_name']:'';?></td>
                <td>
				<?php if($img!=''){?>
                  <img src="<?php echo base_url();?>uploads/items/<?php echo $img;?>" alt="item Image" width="50" height="50" />
				<?php }  else { ?>
				  <img src="<?php echo base_url();?>images/no-image.jpeg" alt="no Image" width="50" height="50" />
				  <?php } ?>
                </td>
                <td><?php echo isset($value['cat_name'])?$value['cat_name']:'';?></td>
                
                <td><?php echo isset($value['desc'])?$value['desc']:'';?></td>
                <td>
                  <a href="<?=base_url()?>Item/edit/<?php echo isset($value['item_id'])?$value['item_id']:''?>" class="edit" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>

                  <a href="<?=base_url()?>Item/delete/<?php echo isset($value['item_id'])?$value['item_id']:''?>" class="delete" title="Delete" onclick="return confirm('Are you sure you want to delete ?')"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                  
                  <a href="javascript:void(0);" title="View Price" class="view button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" onclick="view_details('<?=$value['item_name']?>',<?php echo $value['item_id'];?>,'<?=$value['cat_name']?>')"><i class="fa fa-eye" aria-hidden="true"></i></a>
                </td>
              </tr>
              <?php
                $page++;
                }
              ?>
            </tbody>
          </table>
          <?php } else {
            echo "<center>"."<h1>No Record Found.</h1>"."</center>";
          }
          ?>
        </div>
      </div>
    </div>
    <div class="col-md-12">
      <div class="pagination-data text-center">
        <ul class="pagination">
          <?php echo $link;?>
        </ul>
      </div>
    </div>
</div>
</div>
</div>              
</div>
<!-- pop up-->
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content"  id="details_view" ></div>
  </div>
</div>

<script>
function view_details(item_name,item_id,cat_name,sub_cat_name)
{
  var url = '<?php echo base_url();?>Item/details_by_id';
    $.ajax({
    method  : "POST",
    url     : url,
    data    : {'item_id': item_id,'item_name':item_name,'cat_name':cat_name,'sub_cat_name':sub_cat_name},
    success : function (callBackData){
      $('#details_view').html(callBackData);          
    }
  });
  $('.view_buttn').attr('data-target',"#myModal");
}
</script>
<!-- End pop up-->
<script>
function reset_page() {
  window.location.href='<?= base_url()?>Item/lists';
}
</script> 