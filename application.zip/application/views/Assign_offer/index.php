<div class="page-content">
<div class="page-head">
<div class="page-main-head">
<h1> View Assign Offer</h1>
</div>

<div class="clearfix"></div>
</div>

<div class="form_section">

 <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--  error message section-->  


<form action="<?=base_url()?>AssignOffer/save_data" method="post">
 <input type="hidden" name="assign_id" value="" id="assign_id" >
  <div class="container-fluid">
   <div class="row">
    <div class="form-content">
      <div class="form-row category-form">
        <h2>Search</h2>
          <div class="form-content-inner">
          
            <div class="col-md-6 col-sm-12">
              <div class="form-group ">
                <label for="offer"> Select Offer </label>
                  <select id="offer_id" name="select_offer" class="form-control" data-validation="required" data-validation-error-msg="Please Select Offer " >
                  <option value="">Select Offer</option>
                  <?php if(!empty($offer)){
                    foreach($offer as $val){
                  ?>
                  <option value="<?php echo $val['offer_id'];?>" <?php if($val['offer_id']==$this->input->get('offer_id')){ echo"selected";}?>><?php echo isset($val['title'])?$val['title']:'';?></option>
                  <?php } } ?>
                  </select>
              </div>
            </div>

            <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <label for="category"> Category <span class="star">*</span> </label>
                    <select name="select_cat" id="cat" class="form-control" data-validation="required" data-validation-error-msg="Please Select Category" onchange="get_item(this)" >
          <option value=''>Select Category</option>
          <?php foreach($category as $value){?>
          <option value='<?=$value['cat_id'] ?>'><?=$value['cat_name'] ?></option>
          <?php } ?>
          </select>
                      
          </div>
                </div>
            <div class="clearfix"></div>
                   
              <div class="clearfix"></div>
              
             
            <div class="clearfix"></div>

            <div id="item">
            </div>

            <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  
          <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>

          </div>     
        </div>
      </div>
    </div>
  </div>
</form>
</div>

             
</div>

<!-- <script>
function reset_page() {
  window.location.href='<?= base_url()?>AssignOffer/index';
}
</script>  -->

<script src="<?=base_url()?>js/jquery-1.9.1.min.js"></script>
<script>
function get_item(obj)
{
  var cat_id = $(obj).val();
  var offer_id = $(obj).val();
         var url = "<?= base_url() ?>AssignOffer/get_item";
         $.ajax({
              method:"POST",
              url:url,
             
              data: {'offer_id':offer_id, 'cat_id':cat_id  },

        
              success: function (data, textStatus, jqXHR){

                $('#item').html(data);

         
			  }
		 });
		 
     
}
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>