<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Manage Item</h1>
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
  <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--error message section-->  
<div class="container-fluid">
  <div class="row">
    <div class="form-content">
      <div class="form-row">
        <div class="form-content-inner">
         <form action="<?=base_url()?>Item/update" method="post" enctype="multipart/form-data">
					<div class="col-md-12 col-sm-12">
            <div class="form-group">
              <label for="designationname"> Category <span class="star">*</span> </label>
              <select class="form-control" id="cat_id" name="cat_id" data-validation="required" data-validation-error-msg="Please select Category" >
              <option>select Category</option>
    					<?php if(!empty($category)){
    							foreach($category as $val){
    					?>
    					<option value="<?php echo $val['cat_id'];?>" <?php if($val['cat_id'] == $itemDetails[0]['cat_id']) { echo "selected";}?> ><?php echo isset($val['cat_name'])?$val['cat_name']:'';?></option>
    					<?php } } ?>
    					</select>
            </div>
            <!-- <div class="form-group">
              <label for="designationname"> Sub Category <span class="star">*</span> </label>
              <select class="form-control" id="Sub_cat_id" name="Sub_cat_id" data-validation="required" data-validation-error-msg="Please select Category" >
              <option>select Category</option>
              <?php if(!empty($subCategory)){
                  foreach($subCategory as $val1){
              ?>
              <option value="<?php echo $val1['cat_id'];?>" <?php if($val1['cat_id'] == $itemDetails[0]['sub_cat_id']){ echo "selected";}?> ><?php echo isset($val1['cat_name'])?$val1['cat_name']:''?></option>
              <?php } } ?>
              </select>
            </div> -->
		      </div>
    <div class="col-md-12 col-sm-12">
      <div class="form-group">
        <label for="designationname"> Item Name <span class="star">*</span> </label>
        <input type="text" class="form-control" id="item_name" placeholder="Enter Item Name" name="item_name" value="<?php echo isset($itemDetails[0]['item_name'])?$itemDetails[0]['item_name']:'';?>" data-validation="required" data-validation-error-msg="Please Enter Item Name ">
        <input type="hidden" name="item_hidden_id" id="item_id" value="<?php echo isset($itemDetails[0]['item_id'])?$itemDetails[0]['item_id']:'';?>">
    </div>
    </div>

    <!--- Image Upload Starts Here -->
    <?php $img = $itemDetails[0]['img_name'];?>
      <div class="col-md-12 col-sm-12" >
        <div class="form-group">
          <label for="banner_img"> Item Image [jpeg,jpg,png] </label>
          <input type="file" name="item_image" onchange="readURL(this);" class="form-control"/>
        </div>
          <?php if($img != '') { ?>
          <img id="preViewId" src="<?php echo base_url();?>uploads/items/<?php echo $img;?>" style="width: 300px; height: 200px;" />
          <?php } else { ?>
          <img id="preViewId" src="" style="display:none" />
          <?php } ?>

          <input type="hidden" name="uploaded_item_image" value="<?php echo isset($itemDetails[0]['img_name'])?$itemDetails[0]['img_name']:'';?>"/>
      </div>
    <!--- Image Upload Ends Here -->

				<div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <label for="designationname"> Item Description  </label>
                  <textarea class="form-control" name="item_description"><?php echo isset($itemDetails[0]['desc'])?$itemDetails[0]['desc']:'';?></textarea>
                </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Update" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  
          <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>
         </form>
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script>
  
   function cancel()
  {
    window.location.reload();
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
	function get_sub_cat(obj)
	{
		var cat_id = $(obj).val();
		var url = "<?=base_url()?>Item/get_sub_cat_by_cat_id";
		$.ajax({
              method:"POST",
              url:url,
              dataType:'json',
              data: {'cat_id':cat_id},
     
              success: function (data, textStatus, jqXHR){
				  var html='<option>Select sub Category</option>';
				  for(var i=0; i<data.length; i++)
				  {
					  html+='<option value="'+data[i].cat_id+'">'+data[i].cat_name+'</option>';
				  }
				 // alert(html);
				  $('#Sub_cat_id').html(html);
			  }
            });
	}

  function readURL(input) {
    $('#preViewId').css('display','block');
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
        $('#preViewId')
          .attr('src', e.target.result)
          .width(300)
          .height(200);
        };
      reader.readAsDataURL(input.files[0]);
    }
  }
  </script>

