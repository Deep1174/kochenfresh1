<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Set Item Price</h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
   <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--  error message section-->  
      <div class="container-fluid">
        <div class="row">
          <div class="form-content">
            <div class="form-row">
			
              <div class="form-content-inner">
         <form action="<?=base_url()?>SetItemPrice/save" method="post">
					<div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <label for="designationname">  Category  <span class="star">*</span> </label>
                    <select class="form-control" id="cat_id" name="cat_id" data-validation="required" data-validation-error-msg="Please select Category" onchange="get_item(this)">
                    <option value="">select Category</option>
					<?php if(!empty($category)){
							foreach($category as $val){
					?>
					<option value="<?=$val['cat_id'] ?>"><?=$val['cat_name'] ?></option>
					<?php } } ?>
					</select>
                </div>
				<!--- <div class="form-group">
                    <label for="designationname">  Sub Category  <span class="star">*</span> </label>
                    <select class="form-control" onchange="get_item(this)" id="sub_cat_id" name="sub_cat_id" value="" data-validation="required" data-validation-error-msg="Please select Sub Category">
                    <option value="">select Sub Category </option>
					
					</select>
                </div>-->
				</div>
                <div class="col-md-12 col-sm-12">
                  <div class="form-group ">
                    <label for="designationname">  Item  <span class="star">*</span> </label>
                    
					<select class="form-control" id="item_id" name="item_id" data-validation="required" data-validation-error-msg="Please select item" onchange="remove_prev_price()">
                    <option value="">select itemy </option>
					
					</select>
                </div>
                
                </div>
                
				<!-- item price -->
				<div id="item_price1">
				<div class="col-md-12 col-sm-12">
                  <div class="form-group  bg-color col-md-6 col-sm-6">
                    <label for="designationname"> Quantity  <span class="star">*</span> </label>
                    
					<input type="text" class="form-control Quantity" onkeypress="remove_prev_details(this)" id="qtn" name="quantity[]" data-validation="required" data-validation-error-msg="Enter Quantity">
                </div>
				 <div class="form-group  bg-color col-md-6 col-sm-6">
                    <label for="designationname">   Unit  <span class="star">*</span> </label>
                    
					<select class="form-control unit_id" id="unit_id" name="unit_id[]" data-validation="required" data-validation-error-msg="Please select unit" onchange="already_add(this)">
                    <option value="">select unit </option>
					<?php foreach($unit_master as $key=>$val){ ?>
					<option value="<?= $val['unit_id']?>"><?= $val['unit_name']?></option>
					<?php } ?>
					</select>
                </div>
                </div>
				<div class="col-md-12 col-sm-12">
                  <div class="form-group">
                    <label for="designationname"> Item Price  <span class="star">*</span> </label>
                   
                  
				  <input type="text" class="form-control Price" id="item_price" name="item_price[]" data-validation="required" data-validation-error-msg="Enter price">
                </div>
                 </div>
				</div>
				<input type="hidden" value="1" id="div_count">
				<div class="bttn-sec">
				<a href="javascript:void(0);"onclick="add_div()" class="add-more">Add More</a>
				<a href="javascript:void(0);" class="remove" onclick="remove_div()">remove</a>
                </div>
				<!-- item price -->
                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">
                  
          <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>
         </form>
        
              </div>
            </div>
          </div>
        </div>
      </div>
   
  </div>
</div>
<script>
  function add_div()
  {
	  var count = $('#div_count').val();
	  var newcount = parseInt(count)+parseInt(1);
	  var html = $('#item_price1').html();
	  var new_html = '<div id="item_price'+newcount+'">'+html+'</div>';
	  $('#div_count').val(newcount);
	  $('#div_count').before(new_html);
  }
  function remove_div()
  {
	  var count = $('#div_count').val();
	  if(parseInt(count)>1)
	  {
	  var newcount = parseInt(count)- parseInt(1);
	  $('#item_price'+count).remove();
	  $('#div_count').val(newcount);
	  }
	  
  }
   function cancel()
  {
    window.location.reload();
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
	function get_sub_cat(obj)
	{
		var cat_id = $(obj).val();
		var url = "<?=base_url()?>Item/get_sub_cat_by_cat_id";
		$.ajax({
              method:"POST",
              url:url,
              dataType:'json',
              data: {'cat_id':cat_id},
     
              success: function (data, textStatus, jqXHR){
				  var html='<option value="">Select sub Category</option>';
				  for(var i=0; i<data.length; i++)
				  {
					  html+='<option value="'+data[i].cat_id+'">'+data[i].cat_name+'</option>';
				  }
				  $('#sub_cat_id').html(html);
			  }
            });
	}
	function get_item(obj)
	{
		
		var cat_id = $(obj).val();
		var url = "<?=base_url()?>SetItemPrice/get_item_by_sub_cat_id";
		$.ajax({
              method:"POST",
              url:url,
              dataType:'json',
              data: {'cat_id':cat_id},
     
              success: function (data, textStatus, jqXHR){
				  var html='<option value="">Select sub Category</option>';
				  for(var i=0; i<data.length; i++)
				  {
					  html+='<option value="'+data[i].item_id+'">'+data[i].item_name+'</option>';
				  }
				  $('#item_id').html(html);
			  }
            });
	}
	
	function already_add(obj)
	{
		var unit = $(obj).val();
		var item_id = $('#item_id').val();
		var count =0;
		$("select").map(function(){
			var value = $(this).val();
			var name = $(this).attr('name');
			
			// if(name=="unit_id[]" && value==unit && count==1)
			// {
				
				// $(obj).val('');
				// $(obj).focus();
				// $(obj).parent().parent().next().find('#item_price').val('');
			// }
			if(name=="unit_id[]" && value==unit && count==0)
			{
				var quantity = $(obj).parent().prev().find('#qtn').val();
				//count=1;
				var url = "<?=base_url()?>SetItemPrice/get_item_price";
					$.ajax({
						  method:"POST",
						  url:url,
						  dataType:'json',
						  data: {'item_id':item_id,'unit':unit,'quantity':quantity},
				 
						  success: function (data, textStatus, jqXHR){
							if(data!=='no data')
							{
								 if($(obj).val()!='')
								 {
								 $(obj).parent().parent().next().find('#item_price').val(data);
								 }
							}
							else
							{
								$(obj).parent().parent().next().find('#item_price').val('');
							}
							 
						  }
						});
			}
			
		});
	}
	function remove_prev_price()
	{
		$('.unit_id').val('');
		$('.Price').val('');
		$('.Quantity').val('');
		
	}
	function remove_prev_details(obj)
	{
		$(obj).parent().parent().next().find('#item_price').val('');
		 $(obj).parent().next().find('.unit_id').val('');
		
	}
  </script>

