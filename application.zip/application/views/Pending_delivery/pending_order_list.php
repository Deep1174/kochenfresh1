
          <div class="page-content">
              <div class="page-head">
                    <div class="page-main-head">
                          <h1> View Pending Order</h1>
                        </div>
                        
                        <div class="clearfix"></div>
                </div>
              
                  <div class="form_section">
                    <form action="<?=base_url()?>PendingDelivery" method="get" name="search-form">
                        
                        <div class="container-fluid">
                               <div class="row">
                                  <div class="form-content">
                                      
                                      <div class="form-row category-form">
                                            <h2>Search</h2> 
                                            
                                            <div class="form-content-inner">
                                                       <div class="col-md-12 col-sm-12">
														  <div class="form-group form-left">
															<label for="validfrom"> Order Date<span class="star">*</span> </label>
															<input type="text" class="form-control" id="dt1" placeholder="Enter Order Date" name="order_date" value="<?php if($this->input->get('order_date')==''){ echo date('d-m-Y');}else { echo $this->input->get('order_date'); } ?>" readonly="true"></div>
														</div>
           
                                                    <div class="clearfix"></div>
                                                               
                                                  <div class="col-md-6 col-sm-6">
                                                                <input name="" type="submit" value="Search" class="yellow btn-radius15 ">
                                                              
                                                             </div>
                                                             <div class="col-md-6 col-sm-6">
                                                               <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
                                                        
                                                      
                                                             </div>
                                                             
                                                        <div class="clearfix"></div>
                                                            
                                            </div>     
                                        </div>
                                        
                                    </div>
                                 </div>
                          </div>
                     </form>
            </div>

<?php
                      // echo "<pre>";
                      // print_r($all_item);exit();
                      ?>
            <!-- Search Result -->
<div class="search-result">
  <div class="container-fluid">
      <div class="row">
          <div class="col-md-12">
            <div class="table-responsive">
              <div class="search-result-table sorting-table">
                 
                 <?php //if(isset($all_item)&& count($all_item)>0):?>
                  <table class="table table-bordered table-striped">
                    <thead class="thead-inverse">
                      <tr>
                      <th scope="col">
                    No                    </th>
                        <th>Order ID</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Contact No.</th>
                        <th>Item Name</th>
                        <th>Total Amount</th>
                        <th>Order Date</th>
                        <th>Payment Status</th>
                      </tr>
                    </thead>
                      <?php 
                      //$i=1;
                      //foreach ($all_item as  $value) { ?>
                      
                     <tbody> 
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        
                        <td></td>
                        <td></td>
                        <td>
                        <span class="green-block"></span>
                      
                         </td>
                      </tr>
                      
                    </tbody> 
                     <?php  //$i++; } ?>
                  </table>
                  <?php //else: ?> 
                <CENTER><h3 style="color:gray;"> No Data Found</h3></CENTER><br>
                <?php  //endif; ?> 
              </div>
            </div>
          </div>

          <div class="col-md-12">
            <div class="pagination-data text-center">
              <ul class="pagination">
              
              </ul>
            </div>
          </div>



      </div>
    </div>
</div>


</div>

 <!-- end Result --> 
            

<script>
function reset_page()
{
	
	window.location.href='<?= base_url()?>PendingDelivery';
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>
<script src="<?php echo base_url(); ?>css/calender/jquery-ui.js"></script>
 <script>
 $(document).ready(function () {
    $("#dt1").datepicker({
        dateFormat: "dd-m-yy",
       // minDate: 0,
        onSelect: function (date) {
            var date2 = $('#dt1').datepicker('getDate');
            date2.setDate(date2.getDate() );
        }
    });
});

</script> 
    
        
        
    
     
    