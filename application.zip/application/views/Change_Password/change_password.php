<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Change Password</h1>
    </div>
    <div class="clearfix"></div>
  </div>

  <div class="form_section">
  <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--  error message section-->  
      <div class="container-fluid">
        <div class="row">
          <div class="form-content">
            <div class="form-row">
              <div class="form-content-inner">
              <form action="<?=base_url()?>ChangePassword/save" method="post">
                <div class="col-md-12 col-sm-12">
                    <div class="form-group">
                      <label for="username"> Old password <span class="star">*</span> </label>
                      <input type="password" class="form-control" id="username" placeholder=" Enter Old password" name="old_password" data-validation="required" data-validation-error-msg="Please Enter Old Password ">
                    </div>
                </div>

                <div class="col-md-12 col-sm-12">
                    <div class="form-group">
                      <label for="username"> New Password <span class="star">*</span> </label>
                      <input type="password" class="form-control" id="username" placeholder=" Enter New Password" name="new_password" data-validation="required" data-validation-error-msg="Please Enter New Password ">
                    </div>
                </div>

                <div class="col-md-12 col-sm-12">
                    <div class="form-group">
                      <label for="username"> Confirm Password <span class="star">*</span> </label>
                      <input type="password" class="form-control" id="username" placeholder=" Enter Confirm Password" name="confirm_password" data-validation="required" data-validation-error-msg="Please Enter Confirm Password ">
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-6">
                  <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
                </div>
                <div class="col-md-6 col-sm-6">

                <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
                </div>
                <div class="clearfix"></div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>