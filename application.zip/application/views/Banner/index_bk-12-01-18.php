<!--right side content section start here-->
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1 id="head"> Manage Banner</h1>
    </div>
   
    <div class="clearfix"></div>
  </div>
  <div class="form_section">
   <!-- error message section -->
  <?php if($this->session->flashdata('fail')!=''){ ?>
    <div class="alert alert-danger"><?=$this->session->flashdata('fail')?></div>
  <?php } ?>  
  <?php if($this->session->flashdata('success')!=''){ ?>
    <div class="alert alert-success"><?=$this->session->flashdata('success')?></div>
  <?php } ?>  
  <!--  error message section-->  
    <div class="container-fluid">
      <div class="row">
        <div class="form-content">
          <div class="form-row">
            <div class="form-content-inner">
            <form action="<?=base_url()?>Banner/save" method="post" enctype="multipart/form-data">
              <div class="col-md-12 col-sm-12">
                <div class="form-group">
                  <label for="designationname"> Banner Name <span class="star">*</span> </label>
                  <input type="text" name="banner_name" id="banName" class="form-control" placeholder="Enter Banner Name" data-validation="required" data-validation-error-msg="Please Enter Banner Name" />
                  <input type="hidden" name="id" id="banIdHiddn"/>
                </div>
        
              </div>
         <div class="col-md-6 col-sm-6">
         <div class="form-group">
                  <label for="designationname"> Upload Image  </label>
                  <input type="file" name="image" id="image" class="form-control"  onchange="readURL(this);" />
                 
                </div>
        </div>
          
       
        <img id="image_div" src=""  height='70' width='80' style="display:none;"/>
        


              <div class="clearfix"></div>
              <div class="clearfix"></div>
              <div class="col-md-6 col-sm-6">
                <input name="" type="submit" value="Save" class="yellow btn-radius15 ">
              </div>
              <div class="col-md-6 col-sm-6">
              <a href="javascript:void(0);" class="darkgrey btn-radius15 " title="Cancel" onclick="cancel()">Cancel </a>
              </div>
              <div class="clearfix"></div>
            </form>
            <?php  if(!empty($all_banner)){ ?>
              <div class="small-table-content">
                <div class="col-md-12">
                  <div class="form-group">

                  <table class="table table-bordered  table-striped">
                      <thead class="thead-inverse">
                        <tr>
                        <th>Banner Name</th>
                        <th>Banner Image</th>
                        <th>Status</th>
                        <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                        foreach($all_banner['result'] as $val){
                        $jsonData = json_encode($val);
                      ?>
                        <tr>
                        <td><?php echo isset($val['offer_title'])?$val['offer_title']:'';?></td>
              <td>
              <?php if($val['offer_image']!='') { ?>
              <image src="<?= base_url()?>uploads/offer_banner/<?=$val['offer_image']?>" height="70" width="80"/>
              <?php } else
                
                { ?>

              <image src="<?= base_url()?>uploads/offer_banner/banner_no_image.png" height="42" width="42"/>
              <?php  } ?>

              </td>

              <td><?php if($val['status'] == '1'){echo "Active";}else{echo "Inactive";}?></td>
                    
              <td><a class="edit" onclick='edit_banner(<?php echo $jsonData;?>)' title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>
              
              <a href="<?=base_url()?>Banner/Status/<?php echo $val['id']?>/<?php echo $val['status'];?>" class="delete" <?php if($val['status']==1){ ?> title="Inactivate" onclick="return confirm('Are you sure you want to inactivate it ?')" <?php } else { ?> title="Activate" onclick="return confirm('Are you sure you want to activate it ?')" <?php } ?> ><?php if($val['status'] == 1){ ?> <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                  <?php } else { ?><i class="fa fa-thumbs-down" aria-hidden="true"></i> <?php }?> </a>
                            
              </td>
              </tr>
              <?php } ?>
              </tbody>
              </table>
                    



              </div>
              </div>
              <div class="clearfix"></div>
              </div>
             <?php } ?>
             <?php echo $link;?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
function edit_banner(jsonData)
{
  $('#head').html('Edit Banner ' + jsonData.offer_title );
  $('#banIdHiddn').val(jsonData.id);
  $('#banName').val(jsonData.offer_title);
  //alert(jsonData.offer_image);
   
  if(jsonData.offer_image!='')
  {
    $('#image_div').css('display','block');
    var html="<image height='70' width='80' src='<?=base_url()?>uploads/offer_banner/"+jsonData.offer_image+"'>";
     $('#image_div').attr('src','<?=base_url()?>uploads/offer_banner/'+jsonData.offer_image);
  }
  else
  {
    $('#image_div').css('display','block');
    var html="<image height='70' width='80' src='<?=base_url()?>uploads/offer_banner/banner_no_image.png'>";
     $('#image_div').attr('src','<?=base_url()?>uploads/offer_banner/banner_no_image.png');

  }
  
}
function cancel()
{
  window.location.reload();
}
function readURL(input) {
  $('#image_div').css('display','block');
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
        $('#image_div')
          .attr('src', e.target.result)
          .width(42)
          .height(42);
        };
      reader.readAsDataURL(input.files[0]);
    }
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>