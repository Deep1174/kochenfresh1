<style type="text/css">
.order_date
{
  padding: 20px;
}
.big-checkbox {width: 20px; height: 20px;}
</style>
<div class="page-content">
  <div class="page-head">
    <div class="page-main-head">
      <h1> Place Order</h1>
    </div>

    <div class="clearfix"></div>
  </div>

  <div class="form_section">
    <form action="<?php echo base_url() ?>Placeorder/order_insert" method="post">

      <div class="container-fluid">
        <div class="row">
          <div class="form-content">

            <div class="form-row category-form">
              <h2> Details</h2>

              <div class="form-content-inner">
                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">

                    <label for="name">  First Name <span class="star">*</span></label>
                    <input type="text" class="form-control" name="fname" id="fname" placeholder="Enter First Name" data-validation="required" data-validation-error-msg="Enter First Name" value="<?=$this->input->get('name')?>">
                  </div>
                </div>

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">

                    <label for="name">  Last Name <span class="star">*</span></label>
                    <input type="text" class="form-control" name="lname" id="lname" placeholder="Enter Last Name" data-validation="required" data-validation-error-msg="Enter Last Name" value="<?=$this->input->get('lname')?>">
                  </div>
                </div>

                <div class="clearfix"></div>
                <?php /*
                <!--<div class="col-md-6 col-sm-6">
                <div class="form-group form-left">

                <label for="employeecode">Order Id </label>
                <input type="text" class="form-control" id="employeecode" name="order_id" placeholder="Enter order Id" value="<?=$this->input->get('order_id')?>">
                </div>
                </div>


                <div class="col-md-6 col-sm-6">
                <div class="form-group form-right">

                <label for="employeecode">Order Status </label>
                <select id="status" class="form-control valid"  name="status">
                <option value="">select</option>
                <option value="0" <?php if($this->input->get('status')=='0'){ echo "selected"; } ?>>Pending</option>
                <option value="1"  <?php if($this->input->get('status')=='1'){ echo "selected"; } ?>>Out For Delevery</option>
                <option value="2"  <?php if($this->input->get('status')=='2'){ echo "selected"; } ?>>Cancel</option>
                </select>
                </div>
                </div>--> */ ?>

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">

                    <label for="employeecode">Email <span class="star">*</span></label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter your email" data-validation="email" data-validation-help="e.g - email@gmail.com" value="<?=$this->input->get('email')?>">
                  </div>
                </div>

                 <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">

                    <label for="phone"> Phone No <span class="star">*</span></label>
                    <input type="text" class="form-control" name="phone" id="phone" placeholder="Enter Phone number"  data-validation="required" data-validation-error-msg="Please Enter Phone No" onkeypress="return isNumber(event)">
                  </div>
                </div>

                <div class="clearfix"></div>

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">

                    <label for="address"> Address <span class="star">*</span></label>
                    <input type="text" class="form-control" name="address" id="address" placeholder="Enter Address" data-validation="required" data-validation-error-msg="Enter full address">
                  </div>
                </div>

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">

                    <label for="pincode"> Pincode <span class="star">*</span></label>
                    <input type="text" class="form-control" name="pincode" id="pincode" placeholder="Enter Pincode" maxlength="6" data-validation="required" data-validation-error-msg="Please Enter Pin" onkeypress="return isNumber(event)" >
                  </div>
                </div>

                <div class="clearfix"></div>

               

                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-left">

                    <label for=""> Order Date<span class="star">*</span> </label>
                    <input type="text" class="form-control" id="dt1"  name="order_date" value="<?php if($this->input->get('order_date')==''){ echo date('d-m-Y');}else{echo $this->input->get('order_date');} ?>" readonly="true">
                  </div>
                </div>


                <div class="col-md-6 col-sm-6">
                  <div class="form-group form-right">

                    <label for="">  </label>
                    <input type="checkbox" class="big-checkbox" id="chk_shipping_dtls" name="chk_shipping_dtls" value="1" >My Shipping information is same as my Billing information

       
                  </div>
                </div>

                <div class="clearfix"></div>

            <div id="shipping_dtls">
                  

                      <div class="col-md-6 col-sm-6">
                          <div class="form-group form-left">

                            <label for="name">  First Name <span class="star">*</span></label>
                            <input type="text" class="form-control" name="ship_fname" id="ship_fname" placeholder="Enter First Name" data-validation="required" data-validation-error-msg="Enter First Name" value="<?=$this->input->get('name')?>">
                          </div>
                      </div>

                      <div class="col-md-6 col-sm-6">
                          <div class="form-group form-right">

                            <label for="name">  Last Name <span class="star">*</span></label>
                            <input type="text" class="form-control" name="ship_lname" id="ship_lname" placeholder="Enter Last Name" data-validation="required" data-validation-error-msg="Enter Last Name" value="<?=$this->input->get('lname')?>">
                          </div>
                      </div>

                      <div class="clearfix"></div>

                      <div class="col-md-6 col-sm-6">
                          <div class="form-group form-left">

                            <label for="employeecode">Email <span class="star">*</span></label>
                            <input type="text" class="form-control" id="ship_email" name="ship_email" placeholder="Enter your email" data-validation="email" data-validation-help="e.g - email@gmail.com" value="<?=$this->input->get('email')?>">
                          </div>
                      </div>

                      <div class="col-md-6 col-sm-6">
                          <div class="form-group form-right">

                            <label for="phone"> Phone No <span class="star">*</span></label>
                            <input type="text" class="form-control" name="ship_phone" id="ship_phone" placeholder="Enter Phone number" data-validation="required" data-validation-error-msg="Please Enter Phone No" onkeypress="return isNumber(event)">
                          </div>
                      </div>

                      <div class="clearfix"></div>

                      <div class="col-md-6 col-sm-6">
                          <div class="form-group form-left">

                            <label for="address"> Address <span class="star">*</span></label>
                            <input type="text" class="form-control" name="ship_address" id="ship_address" placeholder="Enter Address" data-validation="required" data-validation-error-msg="Enter full address">
                          </div>
                      </div>

                      <div class="col-md-6 col-sm-6">
                          <div class="form-group form-right">

                            <label for="pincode"> Pincode <span class="star">*</span></label>
                            <input type="text" class="form-control" name="ship_pincode" id="ship_pincode" maxlength="6" placeholder="Enter Pincode" data-validation="required" data-validation-error-msg="Please Enter Pin" onkeypress="return isNumber(event)" >
                          </div>
                      </div>

                      <div class="clearfix"></div>


            </div>



                <div class="clearfix"></div>

                <div id="sectionForAll">
                  
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group form-left">

                        <label for=""> Item Category <span class="star">*</span></label>

                        <select class ="form-control" id ="item_cat" data-validation="required" name="item_cat[]" >
                          <option value="">select</option>
                          <?php $category = $this->db->select('*')->order_by('cat_name', "asc")->get(' kf_category')->result_array();
                          foreach ($category as $key => $groups_value) {
                            ?>
                            <option value="<?php echo $groups_value['cat_id']?>"><?php echo $groups_value['cat_name']?>  </option>
                            <?php
                          } ?>
                        </select>
                      </div>
                    </div>


                    <div class="col-md-2 col-sm-2">
                      <div class="form-group form-right">

                        <button type="button" onclick="additemDiv()" class="btn btn-default" style="margin-top: 30px;"><i class="fa fa-plus"></i></button>
                      </div>
                    </div>


                    <div id ="ifYes">   </div>

                    <div id ="ItemQuantity">   </div>
                  
                </div>

                <div class="col-md-9 col-sm-9" >
                    <div class="form-group form-right">

                            
                    </div>
                </div>
                <div class="col-md-3 col-sm-3" id="grand_total_div" style="display: none;">
                    <div class="form-group form-right">

                      <label for=""> Grand Total </label>
                      <input type="text" class="form-control" name="grand_total" id="grand_total" >
                    </div>
                </div>
               

                <div class="clearfix"></div>

                <div class="col-md-6 col-sm-6">

                  <input name="submit" type="submit" value="Submit" class="yellow btn-radius15 ">
                </div>

                <div class="col-md-6 col-sm-6">

                  <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
                </div>

                <div class="clearfix"></div>

              </div>
            </div>

          </div>
        </div>

      </form>
    </div>
  </div>


    <!-- pop up-->


    <script>

    function mark(order_id)
    {
      $('#order_id').val(order_id);
      $('.view_btn').attr('data-target',"#myModal3");
    }
    function view_details(order_id)
    {
      var url = '<?php echo base_url();?>Orders/details_by_id';
      //
      $.ajax({
        method:"get",
        url:url,

        data: {'order_id': order_id},
        success: function (data, textStatus, jqXHR){

          $('#details_view').html(data);
        }

      });
      $('.view_buttn').attr('data-target',"#myModal");
    }

    </script>

    <!-- End pop up-->

    <script>
    function reset_page()
    {

      window.location.href='<?php echo base_url()?>Orders';
    }
  </script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
  $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
  });
</script>
<script src="<?php echo base_url(); ?>css/calender/jquery-ui.js"></script>
<script>
$(document).ready(function () {

  $("#dt1").datepicker({
    dateFormat: "dd-m-yy",
    //minDate: 0,
    onSelect: function (date) {
      var date2 = $('#dt1').datepicker('getDate');
      date2.setDate(date2.getDate() );
      // $('#dt2').datepicker('setDate', date2);
      //sets minDate to dt1 date + 1
      //  $('#dt2').datepicker('option', 'minDate', date2);
    }
  });
  $('#dt2').datepicker({
    dateFormat: "dd-m-yy",
    onClose: function () {
      var dt1 = $('#dt1').datepicker('getDate');
      var dt2 = $('#dt2').datepicker('getDate');
      //check to prevent a user from entering a date below date of dt1
      if (dt2 <= dt1) {
        var minDate = $('#dt2').datepicker('option', 'minDate');
        $('#dt2').datepicker('setDate', minDate);
      }
    }
  });
});

</script>
<script type="text/javascript">
  $('#item_cat').change(function(){
    var type = $('#item_cat').val();
    //console.log(type)
    var id = 'first';
    $.ajax({
      url : '<?php echo base_url()?>Placeorder/item',
      type : 'POST',
      data : 'type=' + type + '&id='+id,
      beforeSend : function(jqXHR, settings ){
      },
      success : function( data, textStatus, jqXHR){
        $('#ifYes').html(data);
      },
      error : function( jqXHR, textStatus, errorThrown){

      }

    });

  });


</script>
<script type="text/javascript">

function randStr(size){
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

  for (var i = 0; i < size; i++)
  text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}

function additemDiv(){

  const newID = randStr(12);

  var html = 	`<div id="${newID}" >
  <div class="col-md-4 col-sm-4">
  <div class="form-group form-left">

  <label for=""> Item Category <span class="star">*</span></label>

  <select class ="form-control" id ="item_cat_${newID}" onchange="subcatitem('${newID}')" data-validation="required" data-validation-error-msg="" name="item_cat[]">
  <option value="">select</option>
  <?php $category = $this->db->select('*')->get(' kf_category')->result_array();
  foreach ($category as $key => $groups_value) {
    ?>
    <option value="<?php echo $groups_value['cat_id']?>"><?php echo $groups_value['cat_name']?>  </option>
    <?php
  } ?>
  </select>
  </div>
  </div>


  <div class="col-md-2 col-sm-2">
  <div class="form-group form-left">

  <button type="button" onclick="additemDiv()" class="btn btn-default" style="margin-top: 30px;"><i class="fa fa-plus"></i></button>
  <button type="button" onclick="remDiv('${newID}')" class="btn btn-default" style="margin-top: 30px;"><i class="fa fa-minus"></i></button>
  </div>
  </div>


  <div id ="ifYes_${newID}">   </div>

  <div id ="ItemQuantity_${newID}">   </div>
  </div>
  <div class="clearfix"></div>`;


  $("#sectionForAll").append(html);

}

function remDiv(id){
  $("#"+id).remove();
  cal_ttl_prc()
}


</script>

<script type="text/javascript">
  function myfunc(val,id) {
    var type = $('#sub_cat_'+id).val();
    $.ajax({

      url : '<?php echo base_url()?>Placeorder/subitem',
      type : 'POST',
      data : 'type=' +type+ '&val='+val,
      beforeSend : function(jqXHR, settings ){
      },
      success : function( data, textStatus, jqXHR){
        data = JSON.parse(data)
        if(data.length > 0){

          
          //console.log(data[0].unit_id)
          $("#qty_"+id).val(data[1][0].unit_name)
          $("#price_"+id).val(data[0][0].price)

        } else {
          $("#qty_"+id).val('')
          $("#price_"+id).val('')
        }
      },
      error : function( jqXHR, textStatus, errorThrown){

      }

    });
  }

	function show_dtls(val,id){
	    var type = $("#sub_cat_"+id).val();
	    $.ajax({

	      	url : '<?php echo base_url()?>Placeorder/qty_change',
	      	type : 'POST',
	      	data : 'type=' +id+ '&val=' +val,

	      	success : function( data, textStatus, jqXHR){
	        	//alert(data);die();
	        	$("#item_dtls_"+id).html(data);
	      	},
	    });
	}

  	function show_prc(val,id){
    	var type = $("#item_dtls_"+id).val();
    	
    	$.ajax({

      		url : '<?php echo base_url()?>Placeorder/price_change',
      		type : 'POST',
      		data : 'type=' +id+ '&val=' +val,

      		success : function( data, textStatus, jqXHR){
        		data = JSON.parse(data)
        		if(data.length > 0){

          
          			//console.log(data[0].price)
          			$("#price_"+id).val(data[0][0].price)
          		} else {
          			$("#price_"+id).val('')
        		}
      		},
    	});
  	}


  	function cal_prc(val,id){
	    	var quantity   = $("#qty_"+id).val();
	    	var price      = $("#price_"+id).val();
        console.log(quantity);
        console.log(price);
        console.log(val);
            if( val == 7){
              var result     = parseFloat((quantity * price) * 1000);
            }else if( val == 2){
              var result     = parseFloat((quantity * price) / 1000);
            }else{
              var result     = quantity * price;
            }
	    	
	    	$("#item_price"+id).val(result);
		    document.getElementById('grand_total_div').style.display = "block";
        cal_ttl_prc();
        	
  	}

    function cal_ttl_prc(){

      var grandprice = document.querySelectorAll('input[type="text"].get-total');
        var ttl_price = 0;
        for(i=0; i<grandprice.length; i++){
            ttl_price = parseInt(ttl_price) + parseInt(grandprice[i].value);
        }
        $("#grand_total").val(ttl_price);
        //console.log(ttl_price);
    }
    function subcatitem(id){
  var type = $("#item_cat_"+id).val();
  //console.log(type);
  $.ajax({
    url : '<?php echo base_url()?>Placeorder/item',
    type : 'POST',
    data : 'type=' + type + '&id='+id,
    beforeSend : function(jqXHR, settings ){
    },
    success : function( data, textStatus, jqXHR){
      $("#ifYes_"+id).html(data);
    },
    error : function( jqXHR, textStatus, errorThrown){

    }

  });
}
</script>
<script>
function reset_page()
{
  
  window.location.href='<?php echo base_url()?>Placeorder';
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
<script type="text/javascript">
  $(function () {
        $("#chk_shipping_dtls").click(function () {
            if ($(this).is(":checked")) {
                $("#shipping_dtls").hide();
            } else {
                $("#shipping_dtls").show();
            }
        });
    });

  /*$(".get-total").map(function(){
    var toal_val = 0;
    var value = $(this).val();
    for(i = 0; i < value.length; i++) {
      toal_val= Number(toal_val)+Number(value);
    }
    $("#grand_total").val(toal_val);
    console.log('ok');
  });*/

</script>
<script type="text/javascript">

  /*var grandprice = document.querySelectorAll("get-total");
  var ttl_price = 0;
  for(i=0; i<=grandprice.length; i++){
    ttl_price = Number(ttl_price) + Number(grandprice.val);
  }
  $("#grand_total").val(ttl_price);
  console.log(grandprice);*/
</script>
