
          <div class="page-content">
              <div class="page-head">
                    <div class="page-main-head">
                          <h1> View Order List</h1>
                        </div>
                        
                        <div class="clearfix"></div>
                </div>
              
                  <div class="form_section">
                    <form action="<?=base_url()?>Orders" method="get" name="search-form">
                        
                        <div class="container-fluid">
                               <div class="row">
                                  <div class="form-content">
                                      
                                      <div class="form-row category-form">
                                            <h2>Search</h2> 
                                            
                                            <div class="form-content-inner">
                                                       <div class="col-md-6 col-sm-6">
														  <div class="form-group form-left">
															<label for="validfrom"> From Date<span class="star">*</span> </label>
															<input type="text" class="form-control" id="dt1" placeholder="Enter  From Date" name="from_date" value="<?php if($this->input->get('from_date')==''){ echo date('d-m-Y');}else{echo $this->input->get('from_date');} ?>" readonly="true"></div>
														</div>

														<div class="col-md-6 col-sm-6">
														  <div class="form-group form-right">
															<label for=" Valid To">  To Date<span class="star">*</span> </label>
															<input type="text" class="form-control" id="dt2" placeholder="Enter  To Date" name="to_date" value="<?php if($this->input->get('to_date')==''){ echo date('d-m-Y');}else{echo $this->input->get('to_date');} ?>" readonly="true">
															</div>
														</div>     
                                                       <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-left">
                                                                    
                                                                        <label for="name"> customer Name </label>
                                                                   <input type="text" class="form-control" name="name" id="name" placeholder="Enter Customer Name" value="<?=$this->input->get('name')?>">
                                                                </div>
                                                         </div>
                                                         
                                                   <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-right">
                                                                    
                                                                        <label for="employeecode">Order Id </label>
                                                                   <input type="text" class="form-control" id="employeecode" name="order_id" placeholder="Enter order Id" value="<?=$this->input->get('order_id')?>">
                                                                </div>
                                                    </div>  
													 													
                                                    <div class="clearfix"></div>
													<div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-left">
                                                                    
                                                                <label for="employeecode">Order Status </label>
                                                                 <select id="status" class="form-control valid"  name="status"> 
																 <option value="">select</option>
																 <option value="0" <?php if($this->input->get('status')=='0'){ echo "selected"; } ?>>Pending</option>
																 <option value="1"  <?php if($this->input->get('status')=='1'){ echo "selected"; } ?>>Out For Delevery</option>
																 <option value="2"  <?php if($this->input->get('status')=='2'){ echo "selected"; } ?>>Cancel</option>
																 </select>
                                                                </div>
                                                       </div> 
                                                      <!--   <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-left">
                                                                    
                                                                        <label for="department">status </label>
                                                                   <select class="form-control" id="status" name="status">
                                                                        <option value="">Select Status</option>
																		<option value="1">Active</option>
																		<option value="0">InActive</option>
                                                                      
                                                                     </select>
                                                                </div>
                                                         </div> -->

           
                                                    <div class="clearfix"></div>
                                                               
                                                  <div class="col-md-6 col-sm-6">
                                                                <input name="" type="submit" value="Search" class="yellow btn-radius15 ">
                                                              
                                                             </div>
                                                             <div class="col-md-6 col-sm-6">
                                                               <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
                                                        
                                                      
                                                             </div>
                                                             
                                                        <div class="clearfix"></div>
                                                            
                                            </div>     
                                        </div>
                                        
                                    </div>
                                 </div>
                          </div>
                     </form>
           
           
            </div>
            
                <div class="search-result">
                      <div class="container-fluid">
                          <div class="row">
                                
                                
                           
                              <div class="col-md-12">
                                 <div class="table-responsive">
                                
                                  <div class="search-result-table">
                                  <?php  if(!empty($order_list)){
										$search_data = $this->input->get();
										 $search_data = json_encode($search_data);
									?>
									<div class="col-md-12" >
									<a target="_blank" href='<?=base_url()?>Orders/print_order_list?search_data=<?=$search_data?>'><input type="button" class="view button" value="Print" style="float:right"></a>
									<a target="_blank" href='<?=base_url()?>Orders/excel_dowload?search_data=<?=$search_data?>'><input type="button" class="view button" value="Dowload Excel" style="float:right"></a>
									</div>
									 <div class="clearfix"></div>
									 <div class="col-md-12">
                                      <table class="table table-bordered table-striped">
                                      <thead class="thead-inverse">
                                        <tr>
                                          <th>
                                          <div class="headname">Sl No. </div>
                                          
                                          </th>
										 
                                          <th><div class="headname">Order ID </div>
                                          
											</th>
                                          <th><div class="headname">Customer Name</div>
										  <th><div class="headname">Customer Email</div>
										   <th><div class="headname">Customer Phone</div>
										  <th><div class="headname">Total Amount </div>
                      <th><div class="headname">Coupon Name </div>
										  
                                           <th>Payment Status</th> 
                                          <th>Order Status</th>
										  <th>Date</th>
										  <th>Action</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                      <?php foreach($order_list as $k=>$val){ 
									   $item_details = get_total_item_count_price($val['order_id']);
									   $total_amount = isset($item_details['total_amount'])?$item_details['total_amount']:'0';
									   $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';
									  ?>
                    <?php //echo "<pre>";print_r($val); ?>
                                        <tr>
                                          <th scope="row"><?= $k+$page+1?></th>
										  <td><?= $val['order_code']?></td>
                                          <td><?= $val['name'] ." ". $val['lastname'];?></td>
										  <td><?= $val['email']?></td>
										  <td><?= $val['phone']?></td>
                                          <td><?= number_format($total_amount,2); ?></td>
                                          <td>
                                            <?php
                                            $Coupon_name = $this->db->select('cupon_name')->where('cupon_id',$val['cupon_id'])->get('kf_cupon')->result_array();
                                            if($Coupon_name['cupon_name'] == 0)
                                            {
                                              echo 'N/A';
                                            }
                                            else
                                             {
                                              echo $Coupon_name;
                                             }

                                             ?></td>
                                         <td><?php if($val['payment_status'] ==1){ echo "paid";} else { echo "pending";}?></td> 
										  
                                          <td><?php if($val['status'] == 0)
										  {
											  echo"pending";
										  }	
											
											elseif($val['status'] == 1 && $val['payment_status'] ==1){
												echo"Delivered";
											}
											elseif($val['status'] == 1){
												echo"Out For Delevery";
											}
											else
											{echo "canceled";}											
										  ?></td>
										  
										  <td><?= date('d-m-Y H:i A', strtotime($val['order_date'])); ?> </td>
                                          <td>
										   
                                          <!-- <a  href="<?=base_url()?>Users/edit/<?= $val['user_id']?>" class="edit" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i> </a>-->
                                           <?php if( $val['payment_status'] !=1){ ?>
										  <a href="<?=base_url()?>Orders/change_status/<?= $val['order_id']?>?status=<?=$val['status']?>" <?php if($val['status']==1){ ?> class="view button"  title="pending order"  onclick="return confirm('Are you sure?')" <?php } else { ?>  class="delete" title="out for delevery" onclick="return confirm('Are you sure  ?')" <?php } ?>  ><?php if($val['status']==1){ ?> <i class="fa fa-thumbs-down" aria-hidden="true"></i>
											<?php } else{ ?><i class="fa fa-thumbs-up" aria-hidden="true"></i> <?php }?> </a>
                                           <?php } ?>
                                         
                                          <!--view popup-->
                                           <a href="<?=base_url()?>Orders/view/<?= $val['order_id']?>?code=<?=$val['order_code']?>" title="View Details" class="view button" class="btn btn-info btn-lg" ><i class="fa fa-eye" aria-hidden="true">
                                          </i></a>
                                        <?php if( $val['payment_status'] !=1){ ?>
											<a href="<?=base_url()?>Orders/cancelOrder/<?= $val['order_id']?>" class=" delete"  title="Cancel Order" onclick="return confirm('Do you sure to cancel the order?')" ><i class="fa fa-times" aria-hidden="true"></i>
											 </a>
										<?php } ?>
										 <a href="<?=base_url()?>Orders/paid_amount/<?= $val['order_id']?>?status=<?=$val['payment_status']?>"   <?php if($val['payment_status']==1){ ?>  title="Pending payment"  class="view button" onclick="return confirm('Are you sure?')"  <?php }  else { ?>  title="Paid" class=" delete" onclick="return confirm('Are you sure  ?')" <?php } ?> >
										
										 <i class="fa fa-check" aria-hidden="true"></i>
										
										 </a>

                                          
                                          </td>
                                        </tr><?php } ?>
                                        
                                       
                                      </tbody>
                               </table><?php } ?>
        
                                    </div>
                                
                                
                                </div>
                                
                                </div>
                                
                                <div class="col-md-12">
                                  <div class="pagination-data text-center">
                                         <ul class="pagination">
										
                                              <?php echo $link;?>
											 
                                            </ul>
                                    </div>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
           
                                    
    </div>

    <!-- pop up-->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-sm">
              <div class="modal-content"  id="details_view" >
 

  </div>
</div>
</div>

 <script>
 function view_details(order_id)
  {
    var url = '<?php echo base_url();?>Orders/details_by_id';
  //
  $.ajax({
        method:"get",
        url:url,
        
        data: {'order_id': order_id},
        success: function (data, textStatus, jqXHR){

            $('#details_view').html(data);          
          }

      });
  $('.view_buttn').attr('data-target',"#myModal");
  }

 </script>

 <!-- End pop up-->

<script>
function reset_page()
{
	
	window.location.href='<?= base_url()?>Orders';
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>
<script src="<?php echo base_url(); ?>css/calender/jquery-ui.js"></script>
 <script>
 $(document).ready(function () {

    $("#dt1").datepicker({
        dateFormat: "dd-m-yy",
        //minDate: 0,
        onSelect: function (date) {
            var date2 = $('#dt1').datepicker('getDate');
            date2.setDate(date2.getDate() );
           // $('#dt2').datepicker('setDate', date2);
            //sets minDate to dt1 date + 1
          //  $('#dt2').datepicker('option', 'minDate', date2);
        }
    });
    $('#dt2').datepicker({
        dateFormat: "dd-m-yy",
        onClose: function () {
            var dt1 = $('#dt1').datepicker('getDate');
            var dt2 = $('#dt2').datepicker('getDate');
            //check to prevent a user from entering a date below date of dt1
            if (dt2 <= dt1) {
                var minDate = $('#dt2').datepicker('option', 'minDate');
                $('#dt2').datepicker('setDate', minDate);
            }
        }
    });
});

</script> 
    
        
        
    
     
    