<div class="page-content">
<div class="page-head">
<div class="page-main-head">
<h1> View Item List</h1>
</div>

<div class="clearfix"></div>
</div>


<div class="search-result">
 
<div class="container-fluid">
<div class="row">
  <div class="col-md-12">
      <div class="search-result-table">
      		<div class="text-right"><p class="bold-text">Order Id: <?= $code ?></p></div>
			<?php if(!empty($result)){?>
       		<table class="table table-bordered  table-striped">
                   <thead class="thead-inverse">
                   			<th>SL No.</th>
                            <th>Item</th>
                            <th>Unit</th>
                            <th>Unit Price</th>
							<th>Quantity</th>
							<th>Total Price</th>
                        </thead>
             			<tbody>
						<?php
						$grand_total =0;
						foreach($result as $k=>$val){ ;?>
                        	<tr>
                            	<th><?= $k+1?></th>
                            	<td><?= $val['item_name']?></td>
                                <td><?= $val['unit_value']?> <?= $val['unit_name']?>.</td>
                                <td><?= $val['price']?>/-</td>
								<td><?= $val['quantity']?></td>
								<td><?= $total = $val['quantity'] *  $val['price']?>/-</td>
                            </tr>
                        <?php 
						$grand_total = $grand_total + $total;
						} ?>   
                            <tr>
                            	<th colspan="5" style="text-align:right;">Total</th>
                                <th><?= $grand_total?></th>
                            </tr>
                        </tbody>
              </table>
			<?php } ?>
			<div class="col-md-12 text-right"><a href="<?= base_url()?>Orders" class="btn darkgrey btn-radius15 bck-btn" style="width:120px; background:#000; margin-bottom:20px;">Back</a></div>
            
        </div>
    </div>
    
</div>
</div>
</div>
</div>