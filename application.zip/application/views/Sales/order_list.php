
          <div class="page-content">
              <div class="page-head">
                    <div class="page-main-head">
                          <h1> View Sales Report</h1>
                        </div>
                        
                        <div class="clearfix"></div>
                </div>
              
                  <div class="form_section">
                    <form action="<?=base_url()?>SalesReport" method="get" name="search-form">
                        
                        <div class="container-fluid">
                               <div class="row">
                                  <div class="form-content">
                                      
                                      <div class="form-row category-form">
                                            <h2>Search</h2> 
                                            
                                            <div class="form-content-inner">
                                                       <div class="col-md-6 col-sm-6">
														  <div class="form-group form-left">
															<label for="validfrom"> From Date<span class="star">*</span> </label>
															<input type="text" class="form-control" id="dt1" placeholder="Enter  From Date" name="from_date" value="<?php if($this->input->get('from_date')==''){ echo date('d-m-Y');}else{echo $this->input->get('from_date');} ?>" readonly="true"></div>
														</div>

														<div class="col-md-6 col-sm-6">
														  <div class="form-group form-right">
															<label for=" Valid To">  To Date<span class="star">*</span> </label>
															<input type="text" class="form-control" id="dt2" placeholder="Enter  To Date" name="to_date" value="<?php if($this->input->get('to_date')==''){ echo date('d-m-Y');}else{echo $this->input->get('to_date');} ?>" readonly="true">
															</div>
														</div>     
													 													
                                                      <!--   <div class="col-md-6 col-sm-6">
                                                              <div class="form-group form-left">
                                                                    
                                                                        <label for="department">status </label>
                                                                   <select class="form-control" id="status" name="status">
                                                                        <option value="">Select Status</option>
																		<option value="1">Active</option>
																		<option value="0">InActive</option>
                                                                      
                                                                     </select>
                                                                </div>
                                                         </div> -->

           
                                                    <div class="clearfix"></div>
                                                               
                                                  <div class="col-md-6 col-sm-6">
                                                                <input name="" type="submit" value="Search" class="yellow btn-radius15 ">
                                                              
                                                             </div>
                                                             <div class="col-md-6 col-sm-6">
                                                               <input  type="button" value="Reset" class=" darkgrey btn-radius15 " onclick="reset_page()">
                                                        
                                                      
                                                             </div>
                                                             
                                                        <div class="clearfix"></div>
                                                            
                                            </div>     
                                        </div>
                                        
                                    </div>
                                 </div>
                          </div>
                     </form>
           
           
            </div>
            
                <div class="search-result">
                      <div class="container-fluid">
                          <div class="row">
                                
                                
                           
                              <div class="col-md-12">
                                 <div class="table-responsive">
                                
                                  <div class="search-result-table">
                                  <?php  if(!empty($order_list)){
										$search_data = $this->input->get();
										 $search_data = json_encode($search_data);
									?>
									<!-- <div class="col-md-12" >
									<a target="_blank" href='<?=base_url()?>Orders/print_order_list?search_data=<?=$search_data?>'><input type="button" class="view button" value="Print" style="float:right"></a>
									<a target="_blank" href='<?=base_url()?>Orders/excel_dowload?search_data=<?=$search_data?>'><input type="button" class="view button" value="Dowload Excel" style="float:right"></a>
									</div> -->
									 <div class="clearfix"></div>
									 <div class="col-md-12">
                   <table class="table table-bordered table-striped">
                   <thead class="thead-inverse">
                       <tr>
                       <!-- <th>SL
                         </th>  -->            
										  <th><div class="headname">Total Amount </div>
                       <th><div class="headname">Paid Amount </div>
                      <th><div class="headname">Due Amount </div>
                      <!-- <th><div class="headname">Date</div> -->

                      </tr>
                      </thead>
                      <tbody>
                    <?php foreach($order_list as $k=>$val){ 
									   $item_details = get_total_item_count_price($val['order_id']);

                     $total_amount = isset($item_details['total_amount'])?$item_details['total_amount']:'0';

                     $item_paid_details = get_paid_item_count_price($val['order_id']);
									   $total_Paid_amount = isset($item_paid_details['total_amount'])?$item_paid_details['total_amount']:'0';
									   $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';

                     $totalamount += $total_amount;

                     $totalPaidamount += $total_Paid_amount; 

                     $due=($total_amount-$total_Paid_amount); 
                    $dueamount +=$due;

                   }
									  ?>

                      <tr>
                      <!-- <th scope="row"><?= $k+$page+1?></th> -->
										  <td>
                      <?= number_format($totalamount,2);?>
                      </td>
                      <td>
                      <?php $status="1";
                            if($param['from_date']=="")
                            {
                              $fromdate=date('d-m-Y');

                            }
                            else
                            {
                              $fromdate=$param['from_date'];
                            }
                            if($param['to_date']=="")
                            {
                              $todate=date('d-m-Y');

                            }
                            else
                            {
                              $todate=$param['to_date'];
                            }
                            
                       $link = base_url('SalesReport/paidamount').'?status='.$status.'&fromdate='.$fromdate.'&todate='.$todate; ?>
                      <a href="<?php echo $link;?>" target="_blank"><?= number_format($totalPaidamount,2);?></a>
                       </td>
                      <td>
                      <?php $status="0"; $dlink = base_url('SalesReport/dueamount').'?status='.$status.'&fromdate='.$fromdate.'&todate='.$todate; ?>
                      <a href="<?php echo $dlink;?>" target="_blank"><?= number_format($dueamount,2); ?></a>
                      </td>
										  <!-- <td><?= date("d/m/Y", strtotime($val['order_date'])); ?> </td> -->
                      
                      </tr>
   
                       </tbody>
                       </table>
                       <?php } ?>
        
                        </div>
                                
                                
                        </div>
                                
                        </div>
                                
                        <div class="col-md-12">
                        <div class="pagination-data text-center">
                        <ul class="pagination">
											 
                        </ul>
                        </div>
                        </div>
                                
                                
                        </div>
                        </div>
                        </div>            
                        </div>

    <!-- pop up-->
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
    <div class="modal-content"  id="details_view" >
 

</div>
</div>
</div>

<script>
function reset_page()
{
	
	window.location.href='<?= base_url()?>SalesReport';
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
    $(".alert-success").delay(2000).fadeOut(2000);
    $(".alert-danger").delay(2000).fadeOut(2000);
    });
  </script>
<script src="<?php echo base_url(); ?>css/calender/jquery-ui.js"></script>
 <script>
 $(document).ready(function () {

    $("#dt1").datepicker({
        dateFormat: "dd-m-yy",
        //minDate: 0,
        onSelect: function (date) {
            var date2 = $('#dt1').datepicker('getDate');
            date2.setDate(date2.getDate() );
            /* $('#dt2').datepicker('setDate', date2);
            //sets minDate to dt1 date + 1
            $('#dt2').datepicker('option', 'minDate', date2); */
        }
    });
    $('#dt2').datepicker({
        dateFormat: "dd-m-yy",
        onClose: function () {
            var dt1 = $('#dt1').datepicker('getDate');
            var dt2 = $('#dt2').datepicker('getDate');
            //check to prevent a user from entering a date below date of dt1
            if (dt2 <= dt1) {
                var minDate = $('#dt2').datepicker('option', 'minDate');
                $('#dt2').datepicker('setDate', minDate);
            }
        }
    });
});

</script> 
    
        
        
    
     
    