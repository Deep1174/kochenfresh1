<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item extends CI_Controller {

	function __construct() {
    error_reporting(0);
    parent::__construct();
    $this->load->model('ItemModel');
  }

	/**
  * load department page
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       D.M 
  * @copyright    N/A
  * @link         ItemPayroll/Item
  * @since        4.11.2016
  * @deprecated   N/A
  **/

	public function index($page=0)
	{
		if(check_login())
		{
			$data['category'] =$this->db->where('status',1)->order_by('cat_name','asc')->get('kf_category')->result_array();
			$data['content']="Item/index";
			$this->load->view('layout_home',$data);
		}
	}
	
  /**
  * check  Login credential
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       D.M 
  * @copyright    N/A
  * @link         ItemPayroll/Item/save
  * @since        4.11.2016
  * @deprecated   N/A
  **/
	
	public function save()
	{
		if(check_login())
		{
  		$data = $this->input->post();
  		//echo"<pre>";print_r($data);exit();
  		$data = $this->security->xss_clean($data);
  		//Item insert data
  		$insert_data['cat_id']     = $data['cat_id'];
  		$insert_data['sub_cat_id'] = '0';
  		$insert_data['item_name']  =  $data['item_name'];;
  		$insert_data['desc']       = $data['item_description'];

      //////////////////For File Upload///////////////////
      //echo "<pre>";print_r($_FILES);exit();
      $config['upload_path']      ='./uploads/items/';
      $config['allowed_types']    = 'gif|jpg|png|jpeg|jpe';
      $config['max_size']         = '';
      $config['max_width']        = '';
      $config['max_height']       = '';
      //$config['encrypt_name']   = true;
      
      $this->load->library('upload', $config); //Required to Load Image library.//
      
      //File Upload Function .`item_image` is the file name taken from view form.//
      $this->upload->do_upload('item_image');

      /* if( ! $this->upload->do_upload('item_image') ) {
      
          $error = $this->upload->display_errors(); //display_errors() to Show Errors.//
          $this->session->set_flashdata('fail',$error);
          redirect(base_url('AddProject'));
      } else { */
      
          $fileUploaded = $this->upload->data();  // Stored uploaded file.//
          //echo "<pre>";print_r($fileUploaded);exit();
          ////// Taken file name only to insert into database. //////
          $fileName = $fileUploaded['file_name'];
          //echo $fileName;exit();
      //}
      $insert_data['img_name'] = $fileName;
      //////////////////End File Upload///////////////////
  		
  		//insert into data base
  		$this->db->insert('kf_item',$insert_data);
  		$this->session->set_flashdata('success', 'Item added successfully');
      redirect(base_url('Item'));
    }
	}

	/**
  * load Login page
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       M.K.Sah 
  * @copyright    N/A
  * @link         inventory/login
  * @since        17.11.2017
  * @deprecated   N/A
  */

	public function lists($page=0)
	{
		if(check_login())
		{
      $param = $this->input->get();
      $param = $this->security->xss_clean($param);
      //echo"<pre>";print_r($param);exit();
      if(isset($param['page'])&&$param['page']!='')
      {
        $page=$param['page'];
      }
			if(isset($param['item_name'])&&$param['item_name']!='')
      {
        $item_name=$param['item_name'];
      } else {
				$item_name='';
			}
      if(isset($param['cat_id']))
      {
        $cat_id = $param['cat_id'];
      }
      else
      {
        $cat_id = '';
      }
			if(isset($param['Sub_cat_id']))
      {
        $Sub_cat_id = $param['Sub_cat_id'];
      }
      else
      {
        $Sub_cat_id = '';
      }

      $config = array();
      $config['page_query_string'] = TRUE;
      $config['query_string_segment'] = 'page';
      $config['use_page_numbers'] = TRUE;
      $config["base_url"] =base_url().'Item/lists?item_name='.$item_name.'&cat_id='.$cat_id.'&Sub_cat_id='.$Sub_cat_id;
      $config["total_rows"] = $this->ItemModel->record_count($param);
      $config["per_page"] = 25;
      $config['next_link'] = 'Next';
      $config['prev_link'] = 'Previous';
      $this->pagination->initialize($config);
      if($page!=0)
      {
        $page = ($page*$config["per_page"])-$config["per_page"];
      }
      $data['link']   =  $this->pagination->create_links();
      $data['param']  = $param;
      $data['page']   = $page;
      $data['all_Item'] = $this->ItemModel->all_data_list($config["per_page"],$page,$param);
      //echo "<pre>";print_r($data['all_Item']);
      $data['subCategory'] = $this->db->get('kf_sub_category')->result_array();
      $data['category'] = $this->db->get('kf_category')->result_array();
	  $data['content']="Item/Item_list";
	  $this->load->view('layout_home',$data);
		}
	}

  /**
  * load Login page
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       M.K.Sah 
  * @copyright    N/A
  * @link         inventory/login
  * @since        17.11.2017
  * @deprecated   N/A
  */

  public function delete($id)
  {
  	if(check_login())
  	{
  	$delete_status['status'] = '0';
  	$this->db->where('item_id',$id)->update('kf_item',$delete_status);
  	$this->session->set_flashdata('success', 'Item  deleted successfully.');
  	redirect(base_url('Item/lists'));
  	}
  }

  



  /**
  * load Login page
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       M.K.Sah 
  * @copyright    N/A
  * @link         inventory/login
  * @since        17.11.2017
  * @deprecated   N/A
  */

	public function edit($id)
	{
		if(check_login())
		{
      $data['category'] = $this->db->get('kf_category')->result_array();
      $data['subCategory'] = $this->db->get('kf_category')->result_array();
  		$data['itemDetails'] = $this->db->where('item_id',$id)->get('kf_item')->result_array();
  		//echo"<pre>";print_r($data['itemDetails']);exit;
  		$data['content']="Item/edit";
  		$this->load->view('layout_home',$data);
		}
	}

  /**
  * load Login page
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       M.K.Sah 
  * @copyright    N/A
  * @link         inventory/login
  * @since        17.11.2017
  * @deprecated   N/A
  **/

  public function update() {
    if (check_login()) {
      $data = $this->input->post();
      $data = array_map('trim', $data);
      $data = $this->security->xss_clean($data);

      $update_data['cat_id']     = $data['cat_id'];
      $update_data['sub_cat_id'] = '0';
      $update_data['item_name']  = $data['item_name'];
      $update_data['item_id']    = $data['item_hidden_id'];
      $update_data['desc']       = $data['item_description'];
      $update_data['status']     = '1';

      //////////////////For File Upload///////////////////
      /*echo "<pre>";print_r($_FILES);exit();*/
      $config['upload_path']      ='./uploads/items';
      $config['allowed_types']    = 'gif|jpg|png|jpeg|jpe';
      $config['max_size']         = '';
      $config['max_width']        = '';
      $config['max_height']       = '';
      //$config['encrypt_name']   = true;
      
      $this->load->library('upload', $config);

      if( $this->upload->do_upload('item_image') == '' ) {
          $fileName = $this->input->post('uploaded_item_image');
          //echo "<pre>";print_r($fileName);exit();
      } else {
        $DeleteFIleName = $this->input->post('uploaded_item_image');
        //print_r($DeleteFIleName);exit();
        $fileUploaded = $this->upload->data();
        $fileName     = $fileUploaded['file_name'];
        unlink('./uploads/items/'.$DeleteFIleName);
      }
      $update_data['img_name']  = $fileName;
      //////////////////End File Upload///////////////////
     
      //echo '<pre>';print_r($update_data);exit();
      $this->ItemModel->edit_data('kf_item', 'item_id',$update_data['item_id'], $update_data);
      //echo $this->db->last_query();exit();
      $this->session->set_flashdata('success', 'Item update successfully');
      redirect(base_url('Item/lists'));
    }
  }
  
  /**
  * load Login page
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       M.K.Sah 
  * @copyright    N/A
  * @link         inventory/login
  * @since        17.11.2017
  * @deprecated   N/A
  */

public function details_by_id()
{
  check_login();
  $item_id = $this->input->POST('item_id');
  $item_name = $this->input->POST('item_name');
  $cat_name = $this->input->POST('cat_name');
  
  //echo $user_id;exit();
  $price_details = $this->db->from('kf_item_price_unit price')->join('kf_unit_master unit','unit.unit_id=price.unit_id','left')->where('item_id',$item_id)->get()->result_array();
  //echo "<pre>";print_r($price_details);
  $html='<div class="modal-body">
    <div class="col-md-12"><h2 class="form-head view-information"> Item Information</h2> 
    </div>      
    <div class="view-details">       
    
    <div class="col-md-12">
    <div class="row mgbt-xs-0">
    <label class="col-md-5 col-xs-5 control-label name-label">Item Name :</label>
    <div class="col-md-7 col-xs-7">'.$item_name.'</div>
    </div>
    </div>
    
    <div class="col-md-12">
    <div class="row mgbt-xs-0">
    <label class="col-md-5 col-xs-5 control-label name-label">Category :</label>
    <div class="col-md-7 col-xs-7">'.$cat_name.'</div>
    </div>
    </div>
	  
    <div class="col-md-6">
    <div class="row mgbt-xs-0">
    </div>
    </div>
    </div>
	<!-- view details-->
	<div class="col-md-12"><h2 class="form-head view-information"> Item Price Information</h2> 
    </div> 
	<!-- item price -->
	<div class="view-details">';       
    if(!empty($price_details)){ foreach( $price_details as $k=>$details){ if($details['price']>0){
    $html.='<div class="col-md-12">
    <div class="row mgbt-xs-0">
    <label class="col-md-5 col-xs-5 control-label name-label">'.$details['unit_value'].' '.$details['unit_name'].' :</label>
    <div class="col-md-7 col-xs-7">RS: '.$details['price'].' /- </div>
    </div>
    </div>
   
   
    <div class="col-md-6">
    <div class="row mgbt-xs-0">
    </div>
    </div>';
	}}
	}
	else{
	$html.='<div class="col-md-12">
    No Information Found
    </div>
    
   
    <div class="col-md-6">
    <div class="row mgbt-xs-0">
    </div>
    </div>';
	}
    $html.='</div>
	<!--  item price-->	
    <div class="clearfix"></div>
    <div class="modal-body">
    <div class="clearfix"></div>
    <div class="modal-footer">
    <button type="button" class="btn btn-default yellow yellow-btn" data-dismiss="modal">Close</button>
    </div>';
         
  echo $html;
}


  public function get_sub_cat_by_cat_id()
  {
	  if(check_login())
		{
		  $data = $this->input->post();
		  $subcat = $this->db->where('parent_id',$data['cat_id'])->get('kf_category')->result_array();
		  echo json_encode($subcat);
		}
  }
}
