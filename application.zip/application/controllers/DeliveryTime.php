<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DeliveryTime extends CI_Controller {

	function __construct() {
        error_reporting(0);
        parent::__construct();
        $this->load->model('CommonModel');
       
    }
    
    public function index($page=0)
	{   
        if(check_login())
        {
            $data['details'] = $this->db->select('*')->where('delivery_id',1)->get('kf_delivery')->result_array();

            $data['content']  ="Delivery_Time/add";
        
            $this->load->view('layout_home',$data);
        }
	}

    function save_data()
    {
        if(check_login())
        {
            $data = $this->input->post();
            $data = $this->security->xss_clean($data);
           
            if($data['note'] != '')
            {
                $update['note']            = $data['note'];
                $update['add_date']        = date('y-m-d h:i:s');

                $this->CommonModel->edit_data('delivery_id','1','kf_delivery',$update);
                $this->session->set_flashdata('success','Reason has been updated successfully');
                redirect(base_url('DeliveryTime'));

            }
           
           
            
        }

    }

        function status()
    {
        if(check_login())
        {

            $status = $this->db->select('status')->get('kf_delivery')->result_array();

            if($status[0]['status']== 0){

            $update['add_date']        = date('y-m-d h:i:s');
            $update['status']          = '1';

             $this->session->set_flashdata('success','Store Open Successfully.');

            } else 
            {

            $update['add_date']        = date('y-m-d h:i:s');
            $update['status']          = '0';

            $this->session->set_flashdata('success','Store Close Successfully.');

            }
            
            $this->CommonModel->edit_data('delivery_id','1','kf_delivery',$update);
           
           
            redirect(base_url('DeliveryTime'));
        }

    }


}
?>
