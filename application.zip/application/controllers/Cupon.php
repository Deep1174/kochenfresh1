<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cupon extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('CommonModel');
    }

	/**
    * load Cupon page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         KochenFresh/Cupon
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{

		if(check_login())
		{
			/**Listing section**/
			$param = $this->input->get();
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			$config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'Cupon';
            $config["total_rows"] = $this->CommonModel->record_count($param,'kf_cupon','cupon_name');
            $config["per_page"] = 25;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['all_cupon'] = $this->CommonModel->all_data_list($config["per_page"],$page,$param,'kf_cupon','cupon_name');

            $data['param'] = $param;
            $data['page'] = $page;
            //echo"<pre>";print_r($data);	exit();		
			/** listing section **/			
			$data['content']="Cupon/add";
			// echo"<pre>";print_r($data);	exit();
			$this->load->view('layout_home',$data);
			// echo"<pre>";print_r($data);	exit();
		}
	}
	
	/**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         KochenFresh/Cupon/save
    * @since        4.11.2016
    * @deprecated   N/A
    */
	
	public function save_data()
	{
		if(check_login())
		{
		$data = $this->input->post();
		// echo "<pre>";
		// print_r($data);exit();
		//echo"<pre>";print_r($data);
		//edit section
		$insert_data['cupon_name'] = strtoupper($data['cupon_name']);
		$insert_data['discount_price_type'] = $data['discount_price_type'];
		$insert_data['discount_amount'] = $data['discount_amount'];
		$insert_data['purchase_price'] = $data['purchase_price'];
		$insert_data['valid_from'] = date('Y-m-d H:i:s', strtotime(str_replace('/', '-', $data['valid_from'])));
		$insert_data['valid_to'] = date('Y-m-d H:i:s', strtotime(str_replace('/', '-', $data['valid_to'])));
		$insert_data['user'] = $data['user'];
		$insert_data['description'] = strtoupper($data['description']);
		
		//echo"<pre>";print_r($insert_data);exit;
	    $have_data = $this->db->where('cupon_name',strtoupper($data['cupon_name']))->get('kf_cupon')->result_array();
		if($data['cupon_id']!='')
		{
			if(!empty($have_data) && $have_data[0]['cupon_id']!=$data['cupon_id'])
			{
				$this->session->set_flashdata('fail', 'Coupon already added');
				redirect(base_url('Cupon'));
			}
			else{
				$this->session->set_flashdata('success', 'Coupon updated successfully');
				$this->db->where('cupon_id',$data['cupon_id'])->update('kf_cupon',$insert_data);
				redirect(base_url('Cupon'));
			}
			
		}
		// insert section
		else{
		
			if(!empty($have_data) && $have_data[0]['status']==1)
			{
				$this->session->set_flashdata('fail', 'Coupon already added');
				redirect(base_url('Cupon'));
			}
			else if(!empty($have_data) && $have_data[0]['status']==0)
			{
				$update_data['status'] = 1;
				$update_data['discount_price_type'] = $data['discount_price_type'];
				$update_data['discount_amount'] = $data['discount_amount'];
				$update_data['purchase_price'] = $data['purchase_price'];
				$update_data['valid_from'] = date('Y-m-d H:i:s', strtotime(str_replace('/', '-', $data['valid_from'])));
				$update_data['valid_to'] = date('Y-m-d H:i:s', strtotime(str_replace('/', '-', $data['valid_to'])));
				$update_data['description'] = strtoupper($data['description']);
				$update_data['user'] = $data['user'];
		
				$this->db->where('cupon_id',$have_data[0]['cupon_id'])->update('kf_cupon',$update_data);
				$this->session->set_flashdata('success', 'Coupon  added successfully');
				redirect(base_url('Cupon'));
			}
			else{
				$this->CommonModel->data_insert('kf_cupon',$insert_data);
				$this->session->set_flashdata('success', 'Coupon  added successfully');
				redirect(base_url('Cupon'));
			}
		}
		}
	}
	
	public function delete($id)
	{
		if(check_login())
		{
		$delete_status['status'] = 0;
		$this->db->where('cupon_id',$id)->update('kf_cupon',$delete_status);
		$this->session->set_flashdata('success', 'Coupon deleted successfully');
		redirect(base_url('cupon'));
		}
	}



    
}
