<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UnitMaster extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('CommonModel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         KochenFresh/UnitMaster
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{

		if(check_login())
		{
			/**Listing section**/
			$param = $this->input->get();
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			$config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'UnitMaster';
            $config["total_rows"] = $this->CommonModel->record_count($param,'kf_unit_master','unit_name');
            $config["per_page"] = 25;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['all_unit'] = $this->CommonModel->all_data_list($config["per_page"],$page,$param,'kf_unit_master','unit_name');

            $data['param'] = $param;
            $data['page'] = $page;
            //echo"<pre>";print_r($data);			
			/** listing section **/			
			$data['content']="UnitMaster/add";
			$this->load->view('layout_home',$data);
		}
	}
	
	/**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         EmployeePayroll/Company/save
    * @since        4.11.2016
    * @deprecated   N/A
    */
	
	public function save_data()
	{
		if(check_login())
		{
		$data = $this->input->post();
		//echo"<pre>";print_r($data);
		//edit section
		$insert_data['unit_name'] = strtoupper($data['unit_name']);
		
			//echo"<pre>";print_r($have_data);exit;
	    $have_data = $this->db->where('unit_name',strtoupper($data['unit_name']))->get('kf_unit_master')->result_array();
		if($data['unit_id']!='')
		{
			if(!empty($have_data) && $have_data[0]['unit_id']!=$data['unit_id'])
			{
				$this->session->set_flashdata('fail', 'Unit already added');
				redirect(base_url('UnitMaster'));
			}
			else{
				$this->session->set_flashdata('success', 'Unit updated successfully');
				$this->db->where('unit_id',$data['unit_id'])->update('kf_unit_master',$insert_data);
				redirect(base_url('UnitMaster'));
			}
			
		}
		// insert section
		else{
		
			if(!empty($have_data) && $have_data[0]['status']==1)
			{
				$this->session->set_flashdata('fail', 'Unit already added');
				redirect(base_url('UnitMaster'));
			}
			else if(!empty($have_data) && $have_data[0]['status']==0)
			{
				$update_data['status'] = 1;
				$this->db->where('unit_id',$have_data[0]['unit_id'])->update('kf_unit_master',$update_data);
				$this->session->set_flashdata('success', 'Unit  added successfully');
				redirect(base_url('UnitMaster'));
			}
			else{
				$this->CommonModel->data_insert('kf_unit_master',$insert_data);
				$this->session->set_flashdata('success', 'Unit  added successfully');
				redirect(base_url('UnitMaster'));
			}
		}
		}
	}
	
	public function delete($id)
	{
		if(check_login())
		{
		$delete_status['status'] = 0;
		$this->db->where('unit_id',$id)->update('kf_unit_master',$delete_status);
		$this->session->set_flashdata('success', 'Unit  deleted successfully');
		redirect(base_url('UnitMaster'));
		}
	}



    
}
