<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SubCategory extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('CommonModel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         EmployeePayroll/Company
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{
		if(check_login())
		{
			$param = $this->input->get();
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			$config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'SubCategory';
            $config["total_rows"] = $this->CommonModel->sub_cat_record_count($param,'kf_category','cat_id');
            $config["per_page"] = 5;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['sub_cat_list_list'] = $this->CommonModel->sb_cat_all_data_list($config["per_page"],$page,$param,'kf_category','cat_id');

            $data['param'] = $param;
            $data['page'] = $page;
            //echo"<pre>";print_r($data);			
			/** listing section **/		
			$data['category_list']= $this->db->where('status',1)->get('kf_category')->result_array();;			
			$data['content']="SubCategory/add";
			$this->load->view('layout_home',$data);
		}
	}
	
	/**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         EmployeePayroll/SubCategory/save
    * @since        4.11.2016
    * @deprecated   N/A
    */
	
	public function save()
	{
		if(check_login())
		{
			$data = $this->input->post();
			//echo"<pre>";print_r($data);
			//edit section
			$insert_data['cat_name'] = strtoupper($data['sub_cat_name']);
			$insert_data['parent_id'] = $data['cat_id'];
			
				//echo"<pre>";print_r($have_data);exit;
			$have_data = $this->db->where('parent_id',$data['cat_id'])->where('cat_name',strtoupper($data['sub_cat_name']))->get('kf_category')->result_array();
			if($data['sub_cat_id']!='')
			{
				if(!empty($have_data) && $have_data[0]['sub_cat_id']!=$data['sub_cat_id'])
				{
					$this->session->set_flashdata('fail', 'Sub Category already added');
					redirect(base_url('SubCategory'));
				}
				else{
					$this->session->set_flashdata('success', 'Sub Category updated successfully');
					$this->db->where('sub_cat_id',$data['sub_cat_id'])->update('kf_category',$insert_data);
					redirect(base_url('SubCategory'));
				}
				
			}
			// insert section
			else{
			
				if(!empty($have_data) && $have_data[0]['status']==1)
				{
					$this->session->set_flashdata('fail', 'Sub Category already added');
					redirect(base_url('SubCategory'));
				}
				else if(!empty($have_data) && $have_data[0]['status']==0)
				{
					$update_data['status'] = 1;
					$this->db->where('sub_cat_id',$have_data[0]['sub_cat_id'])->update('kf_category',$update_data);
					$this->session->set_flashdata('success', 'SubCategory  added successfully');
					redirect(base_url('SubCategory'));
				}
				else{
					$this->CommonModel->data_insert('kf_category',$insert_data);
					$this->session->set_flashdata('success', 'Sub Category  added successfully');
					redirect(base_url('SubCategory'));
				}
			}
		}
	}
	
	public function delete($id)
	{
		if(check_login())
		{
		$delete_status['status'] = 0;
		$this->db->where('sub_cat_id',$id)->update('kf_category',$delete_status);
		$this->session->set_flashdata('success', 'Sub Category  deleted successfully');
		redirect(base_url('SubCategory'));
		}
	}



    
}
