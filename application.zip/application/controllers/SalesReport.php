<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'/third_party/mpdf/mpdf.php';
class SalesReport extends CI_Controller {

	function __construct() {
		error_reporting(0);
    parent::__construct();
		$this->load->model('SalesModel');
		$this->load->library('excel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         EmployeePayroll/Company
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{
		if(check_login())
		{
			$param = $this->input->get();
			
      $param = $this->security->xss_clean($param);

			if(isset($param['to_date']))
      {
          $to_date  = $param['to_date'];
      }
      else
      {
          $to_date = '';
      }
			if(isset($param['from_date']))
      {
          $from_date  = $param['from_date'];
      }
      else
      {
          $from_date = '';
      }

            
      $config["per_page"] = 5;
      $data['order_list'] = $this->SalesModel->all_data_list($config["per_page"],$page,$param);

      $data['param'] = $param;
			//echo"<pre>";print_r($data['order_list']);exit;
			$data['content']="Sales/order_list";
			$this->load->view('layout_home',$data);
		}
	}

	public function paidamount()
	{
		$param = $this->input->get();

		//echo"<pre>";print_r($param);exit();

		if(isset($param['todate']))
    {
        $todate  = $param['todate'];
    }
    else
    {
        $todate = '';
    }
		if(isset($param['fromdate']))
    {
        $fromdate  = $param['fromdate'];
    }
    else
    {
        $fromdate = '';
    }
    if(isset($param['status']))
    {
        $status  = $param['status'];
    }
    else
    {
        $status = '';
    }

    // echo $todate; exit();
    
    $config["per_page"] = 5;

    $data['order_list'] = $this->SalesModel->paid_amount_list($config["per_page"],$page,$param);
    //echo"<pre>";print_r($data['order_list']);exit;
    $data['param'] = $param;
		$data['content']="Sales/paid_order_list";
		$this->load->view('layout_home',$data);
	}

	public function dueamount()
	{
		$param = $this->input->get();

		//echo"<pre>";print_r($param);exit();

		if(isset($param['todate']))
    {
        $todate  = $param['todate'];
    }
    else
    {
        $todate = '';
    }
		if(isset($param['fromdate']))
    {
        $fromdate  = $param['fromdate'];
    }
    else
    {
        $fromdate = '';
    }
    if(isset($param['status']))
    {
        $status  = $param['status'];
    }
    else
    {
        $status = '';
    }

      //echo $status; exit();
      
      $config["per_page"] = 5;

      $data['order_list'] = $this->SalesModel->due_amount_list($config["per_page"],$page,$param);

      $data['param'] = $param;
			$data['content']="Sales/due_order_list";
			$this->load->view('layout_home',$data);
	}

    public function paid_excel_dowload()
   {
       $data = $this->input->get('search_data');
        $param = json_decode($data);
        //echo"<pre>";print_r($param);exit()
        $date= date('Y-m-d');
       $where=" ";

       if(isset($param->fromdate) && $param->fromdate!='')
        {
            
            $where.=" and DATE(order_date) >='". date('Y-m-d',strtotime($param->fromdate))."'";
        }
        if(isset($param->todate) && $param->todate!='')
        {
            
            $where.=" and DATE(order_date) <='". date('Y-m-d',strtotime($param->todate))."'";
        }
        if(isset($param->status) && $param->status!='')
        {
            
             $where .= " AND payment_status =".$param->status;
        }
      
       
         $sql="SELECT  orders.*,user.name,user.email,user.phone FROM kf_order orders left join kf_user user on user.user_id=orders.user_id WHERE 1 $where ORDER BY order_id DESC" ;      
             
        $recordSet = $this->db->query($sql);
        
        $result = $recordSet->result_array();
        
        $details = array();
        //echo"<pre>";print_r($result);exit();

        foreach($result as $k1=>$val1)
        {
            $item_details = get_total_item_count_price($val1['order_id']);
           $total_amount = isset($item_details['total_amount'])?$item_details['total_amount']:'0';
           $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';
            /**status **/
            if($val['status'] == 1)
          {
              $status = "Pending";
          } 
            elseif($val['status'] == 0){
                 $status = "Out For Delevery";
            }
            else
            { $status = "canceled";}
        
        
            $details[$k1]['order_id'] = $val1['order_code'];
		      	$details[$k1]['name'] = $val1['name'];
		      	$details[$k1]['email'] = $val1['email'];
		      	$details[$k1]['phone'] = $val1['phone'];
            $details[$k1]['total_amount'] = number_format($total_amount,2);
            $details[$k1]['status'] = $status;
            $details[$k1]['order_datedate'] = date('d-m-Y H:i:s', strtotime($val1['order_date']));
        }
        //echo"<pre>";print_r($details);exit;
        $this->excel->setActiveSheetIndex(0);     
        $this->excel->getActiveSheet()->setTitle('Sheet1');
        /** <!-- header section-->**/
        for ($col = 'A'; $col != 'J'; $col++) {
        $this->excel->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                }
        // $this->excel->getActiveSheet()->setCellValue('A1', 'Summary For Order List');
         //$this->excel->getActiveSheet()->getStyle('A1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
        $blueBold = array( "font" => array("bold" => true,"color" => array("rgb" => "0000ff"),),);
        $greenNotBold = array("font" => array("bold" => true,"color" => array("rgb" => "ce2208"),),);
        $this->excel->setActiveSheetIndex(0)->mergeCells('A1:I1');
            $this->excel->getActiveSheet()->setCellValue('A1', 'Paid Sales Order List');
            $this->excel->getActiveSheet()->getStyle("A1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER)->applyFromArray($blueBold);

            $this->excel->getActiveSheet()->getStyle('A1')->applyFromArray($blueBold);
            $this->excel->getActiveSheet()->getRowDimension('1')->setRowHeight(40);
            $this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(100);
            
         //$this->excel->getActiveSheet()->getStyle('A1')->getFill()->getStartColor()->setARGB('#86a5d6');

         $this->excel->getActiveSheet()->setCellValue('A3', 'Order ID ');
         $this->excel->getActiveSheet()->getStyle('A3')->applyFromArray($greenNotBold);
		     $this->excel->getActiveSheet()->setCellValue('B3', 'Customer Name ');
         $this->excel->getActiveSheet()->getStyle('B3')->applyFromArray($greenNotBold);
		     $this->excel->getActiveSheet()->setCellValue('C3', 'Customer Email ');
         $this->excel->getActiveSheet()->getStyle('C3')->applyFromArray($greenNotBold);
	     	 $this->excel->getActiveSheet()->setCellValue('D3', 'Customer Phone');
         $this->excel->getActiveSheet()->getStyle('D3')->applyFromArray($greenNotBold);
         $this->excel->getActiveSheet()->setCellValue('E3', 'Paid Amount');
         $this->excel->getActiveSheet()->getStyle('E3')->applyFromArray($greenNotBold);
         $this->excel->getActiveSheet()->setCellValue('F3', 'Order Status');
         $this->excel->getActiveSheet()->getStyle('F3')->applyFromArray($greenNotBold);
         $this->excel->getActiveSheet()->setCellValue('G3', 'Order Date');
         $this->excel->getActiveSheet()->getStyle('G3')->applyFromArray($greenNotBold);
         

        for ($col = ord('A'); $col <= ord('C'); $col++) {
            $this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(12);

            $this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        $this->excel->getActiveSheet()->fromArray($details, null, 'A4');


        $this->excel->getActiveSheet()->getStyle('A5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        
        $this->excel->getActiveSheet()->getStyle('B5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('C5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('D5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $filename = 'paid_sales_order.xls';
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $filename . '"'); 
        header('Cache-Control: max-age=0'); 
       
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
       
        $objWriter->save('php://output');
   }

   public function print_paid_order_list()
    {
        if(check_login())
        {
        //pdf settings
        $pdf = new mPDF('utf-8', array(290,295));
        $pdf->AddPage(P, // L - landscape, P - portrait 
        'A5', '12', '', '',
        25, // margin_left
        25, // margin right
        5, // margin top
        5, // margin bottom
        5, // margin header
        5); // margin footer
    //pdf settings
        $data = $this->input->get('search_data');
        $param = json_decode($data);
        //echo"<pre>";print_r($param);
        $date= date('Y-m-d');
       $where=" ";
       if(isset($param->fromdate) && $param->fromdate!='')
        {
            
            $where.=" and DATE(order_date) >='". date('Y-m-d',strtotime($param->fromdate))."'";
        }
        if(isset($param->todate) && $param->todate!='')
        {
            
            $where.=" and DATE(order_date) <='". date('Y-m-d',strtotime($param->todate))."'";
        }
        if(isset($param->status) && $param->status!='')
        {
            
             $where .= " AND payment_status =".$param->status;
        }
      
       
        $sql="SELECT  orders.*,user.name,user.email,user.phone FROM kf_order orders left join kf_user user on user.user_id=orders.user_id WHERE 1 $where ORDER BY order_id DESC" ;           
             
        $recordSet = $this->db->query($sql);
        
        $result = $recordSet->result_array();
        //echo"<pre>";print_r($result);exit();
                $html='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Kochen Fresh</title>

<style type="text/css">
 body { margin:0; padding:0; font-family:Verdana, Geneva, sans-serif; font-size:14px;}
 table td,  table  { border-collapse:collapse;}
  table td { padding:5px; border:1px solid #000; padding:8px;}
 
 @media print{ body { font-family:Verdana, Geneva, sans-serif; font-size:14px;}  table td { border:1px solid #000; border-collapse:collapse;} table { border-collapse:collapse; padding:8px;}}
</style>
</head>

<body>
<div style="width:960px; margin:0 auto 15px auto;">
<div style="padding:15px 0; text-align:right;"></div>
<p style="text-align:center;" ><img src="'.base_url().'images/log02.png" width="200" height="50"></p>

<P style="text-align:center; ">Paid Sales Order List</P>
  
<table class="table table-bordered table-striped "  width="100%"   >
  <tr>
    <td><strong>Order ID</strong></td>
	<td><strong>Customer Name</strong></td>
	<td><strong>Customer Email</strong></td>
	<td><strong>Customer Phone</strong></td>
    <td><strong>Paid Amount</strong></td>
    <td><strong>Order Stats</strong></td>
    <td><strong>Order Date</strong></td>
  </tr>';
  foreach($result as $k=>$val){
      if($val['status'] == 0)
  {
      $status = "pending";
  } 
    elseif($val['status'] == 1){
         $status = "Out For Delevery";
    }
    else
    { $status = "canceled";}    
       $item_details = get_total_item_count_price($val['order_id']);
       $total_amount = isset($item_details['total_amount'])?$item_details['total_amount']:'0';
       $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';
  $html.='<tr>
  <td>'.$val['order_code'].'</td>
   <td>'.$val['name'].'</td>
   <td>'.$val['email'].'</td>
   <td>'.$val['phone'].'</td>
  <td>'.number_format($total_amount,2).'</td>
  <td>'.$status.'</td>
 <td>'.date('d-m-Y H:i:s', strtotime($val['order_date'])).'</td>
  </tr>';
  
  } 
$html.='</table></div>
</body>
</html>
';
echo $html;exit;
$pdfname = "sales-voucher-print-copy";
                             //echo $html;exit;
                              $pdf->WriteHTML($html);
                              $pdfFilePath = "employee-pay-slip-".$data['emp_id'].".pdf";
                              $pdf->Output($pdfFilePath,'I');
    }
    }

    public function due_excel_dowload()
   {
       $data = $this->input->get('search_data');
        $param = json_decode($data);
        //echo"<pre>";print_r($param);exit();
        $date= date('Y-m-d');
       $where=" ";

       if(isset($param->fromdate) && $param->fromdate!='')
        {
            
            $where.=" and DATE(order_date) >='". date('Y-m-d',strtotime($param->fromdate))."'";
        }
        if(isset($param->todate) && $param->todate!='')
        {
            
            $where.=" and DATE(order_date) <='". date('Y-m-d',strtotime($param->todate))."'";
        }
        if(isset($param->status) && $param->status!='')
        {
            
             $where .= " AND payment_status =".$param->status;
        }
      
       
        $sql="SELECT  orders.*,user.name,user.email,user.phone FROM kf_order orders left join kf_user user on user.user_id=orders.user_id WHERE 1 $where ORDER BY order_id DESC" ;     
             
        $recordSet = $this->db->query($sql);
        
        $result = $recordSet->result_array();
        
        $details = array();
        //echo"<pre>";print_r($result);exit();

        foreach($result as $k1=>$val1)
        {
            $item_details = get_total_item_count_price($val1['order_id']);
           $total_amount = isset($item_details['total_amount'])?$item_details['total_amount']:'0';
           $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';
            /**status **/
            if($val['status'] == 0)
          {
              $status = "Pending";
          } 
            elseif($val['status'] == 1){
                 $status = "Out For Delevery";
            }
            else
            { $status = "canceled";}
        
        
            $details[$k1]['order_id'] = $val1['order_code'];
		      	$details[$k1]['name'] = $val1['name'];
		      	$details[$k1]['email'] = $val1['email'];
			      $details[$k1]['phone'] = $val1['phone'];
            $details[$k1]['total_amount'] = $val1['total_amount'];
            $details[$k1]['status'] = $status;
            $details[$k1]['order_datedate'] = date('d-m-Y H:i:s', strtotime($val1['order_date']));
        }
        //echo"<pre>";print_r($details);exit;
        $this->excel->setActiveSheetIndex(0);     
        $this->excel->getActiveSheet()->setTitle('Sheet1');
        /** <!-- header section-->**/
        for ($col = 'A'; $col != 'J'; $col++) {
        $this->excel->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                }
        // $this->excel->getActiveSheet()->setCellValue('A1', 'Summary For Order List');
         //$this->excel->getActiveSheet()->getStyle('A1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
        $blueBold = array( "font" => array("bold" => true,"color" => array("rgb" => "0000ff"),),);
        $greenNotBold = array("font" => array("bold" => true,"color" => array("rgb" => "ce2208"),),);
        $this->excel->setActiveSheetIndex(0)->mergeCells('A1:I1');
                $this->excel->getActiveSheet()->setCellValue('A1', 'Due Sales Order List');
                $this->excel->getActiveSheet()->getStyle("A1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER)->applyFromArray($blueBold);

                $this->excel->getActiveSheet()->getStyle('A1')->applyFromArray($blueBold);
            $this->excel->getActiveSheet()->getRowDimension('1')->setRowHeight(40);
            $this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(100);
            
         //$this->excel->getActiveSheet()->getStyle('A1')->getFill()->getStartColor()->setARGB('#86a5d6');

         $this->excel->getActiveSheet()->setCellValue('A3', 'Order ID ');
         $this->excel->getActiveSheet()->getStyle('A3')->applyFromArray($greenNotBold);
		     $this->excel->getActiveSheet()->setCellValue('B3', 'Customer Name ');
         $this->excel->getActiveSheet()->getStyle('B3')->applyFromArray($greenNotBold);
		     $this->excel->getActiveSheet()->setCellValue('C3', 'Customer Email ');
         $this->excel->getActiveSheet()->getStyle('C3')->applyFromArray($greenNotBold);
		     $this->excel->getActiveSheet()->setCellValue('D3', 'Customer Phone');
         $this->excel->getActiveSheet()->getStyle('D3')->applyFromArray($greenNotBold);
         $this->excel->getActiveSheet()->setCellValue('E3', 'Total Amount');
         $this->excel->getActiveSheet()->getStyle('E3')->applyFromArray($greenNotBold);
         $this->excel->getActiveSheet()->setCellValue('F3', 'Order Status');
         $this->excel->getActiveSheet()->getStyle('F3')->applyFromArray($greenNotBold);
         $this->excel->getActiveSheet()->setCellValue('G3', 'Order Date');
         $this->excel->getActiveSheet()->getStyle('G3')->applyFromArray($greenNotBold);
         

        for ($col = ord('A'); $col <= ord('C'); $col++) {
            $this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(12);

            $this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        $this->excel->getActiveSheet()->fromArray($details, null, 'A4');


        $this->excel->getActiveSheet()->getStyle('A5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        
        $this->excel->getActiveSheet()->getStyle('B5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('C5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('D5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $filename = 'due_sales_order.xls';
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $filename . '"'); 
        header('Cache-Control: max-age=0'); 
       
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
       
        $objWriter->save('php://output');
   }

   public function print_due_order_list()
    {
        if(check_login())
        {
        //pdf settings
        $pdf = new mPDF('utf-8', array(290,295));
        $pdf->AddPage(P, // L - landscape, P - portrait 
        'A5', '12', '', '',
        25, // margin_left
        25, // margin right
        5, // margin top
        5, // margin bottom
        5, // margin header
        5); // margin footer
    //pdf settings
        $data = $this->input->get('search_data');
        $param = json_decode($data);
        //echo"<pre>";print_r($param);
        $date= date('Y-m-d');
       $where=" ";
       if(isset($param->fromdate) && $param->fromdate!='')
        {
            
            $where.=" and DATE(order_date) >='". date('Y-m-d',strtotime($param->fromdate))."'";
        }
        if(isset($param->todate) && $param->todate!='')
        {
            
            $where.=" and DATE(order_date) <='". date('Y-m-d',strtotime($param->todate))."'";
        }
        if(isset($param->status) && $param->status!='')
        {
            
             $where .= " AND payment_status =".$param->status;
        }
      
       
        $sql="SELECT  orders.*,user.name,user.email,user.phone FROM kf_order orders left join kf_user user on user.user_id=orders.user_id WHERE 1 $where ORDER BY order_id DESC" ;           
             
        $recordSet = $this->db->query($sql);
        
        $result = $recordSet->result_array();
        //echo"<pre>";print_r($result);exit();
                $html='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Kochen Fresh</title>

<style type="text/css">
 body { margin:0; padding:0; font-family:Verdana, Geneva, sans-serif; font-size:14px;}
 table td,  table  { border-collapse:collapse;}
  table td { padding:5px; border:1px solid #000; padding:8px;}
 
 @media print{ body { font-family:Verdana, Geneva, sans-serif; font-size:14px;}  table td { border:1px solid #000; border-collapse:collapse;} table { border-collapse:collapse; padding:8px;}}
</style>
</head>

<body>
<div style="width:960px; margin:0 auto 15px auto;">
<div style="padding:15px 0; text-align:right;"></div>
<p style="text-align:center;" ><img src="'.base_url().'images/log02.png" width="200" height="50"></p>

<P style="text-align:center; ">Due Sales Order List</P>
  
<table class="table table-bordered table-striped "  width="100%"   >
  <tr>
    <td><strong>Order ID</strong></td>
	<td><strong>Customer Name</strong></td>
	<td><strong>Customer Email</strong></td>
	<td><strong>Customer Phone</strong></td>
  <td><strong>Total Amount</strong></td>
  <td><strong>Payment Status</strong></td>
  <td><strong>Order Stats</strong></td>
  <td><strong>Order Date</strong></td>
  </tr>';
  foreach($result as $k=>$val){
  if($val['status'] == 0)
  {
    $status = "pending";
  } 
  elseif($val['status'] == 1){
       $status = "Out For Delevery";
  }
  else
  { $status = "canceled";}  
  if($val['payment_status']==0)
  {
    $paymentStatus = 'Due';
  } 
  if($val['payment_status']==1)
  {
    $paymentStatus = 'paid';
  }  
  $item_details = get_total_item_count_price($val['order_id']);
  $total_amount = isset($item_details['total_amount'])?$item_details['total_amount']:'0';
  $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';
  $html.='<tr>
  <td>'.$val['order_code'].'</td>
  <td>'.$val['name'].'</td>
  <td>'.$val['email'].'</td>
  <td>'.$val['phone'].'</td>
  <td>'.number_format($val['total_amount'],2).'</td>
  <td>'.$paymentStatus.'</td>
  <td>'.$status.'</td>
  <td>'.date('d-m-Y H:i:s', strtotime($val['order_date'])).'</td>
  </tr>';
  
  } 
$html.='</table></div>
</body>
</html>
';
echo $html;exit;
$pdfname = "sales-voucher-print-copy";
                             //echo $html;exit;
                              $pdf->WriteHTML($html);
                              $pdfFilePath = "employee-pay-slip-".$data['emp_id'].".pdf";
                              $pdf->Output($pdfFilePath,'I');
    }
    }
   
}
