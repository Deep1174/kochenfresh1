<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ChangePassword extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
    }

	/**
    * load Change Password page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       M.K.Sah 
    * @copyright    N/A
    * @link         /login
    * @since        16.11.2017
    * @deprecated   N/A
    **/

	public function index()
	{
		if(check_login())
		{
			$data['content'] ="Change_Password/change_password";
			$this->load->view('layout_home',$data);
		}
	}

    /**
    * load Save Change Password page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       M.K.Sah 
    * @copyright    N/A
    * @link         /login
    * @since        16.11.2017
    * @deprecated   N/A
    **/

	public function save() {
        if (check_login()) {

            $data = $this->input->post();
            $data = $this->security->xss_clean($data);

            $md5_convert_data = md5(trim($data['old_password']));
      		$salt_key = get_encript_id(trim($data['old_password']));
		    $old_password = $md5_convert_data.$salt_key;

		    $md5_new_convert_data = md5(trim($data['new_password']));
      		$salt_new_key = get_encript_id(trim($data['new_password']));
        	$new_password = $md5_new_convert_data.$salt_new_key;

        	$md5_con_convert_data = md5(trim($data['confirm_password']));
      		$salt_con_key = get_encript_id(trim($data['confirm_password']));
        	$confirm_password = $md5_con_convert_data.$salt_con_key;

            $user_id = $this->session->userdata('kf_user_id');
            $login_details =$this->db->where('id',$user_id)->get('kf_admin_user')->result_array();

            if ($login_details[0]['password']!= $old_password) {
                $this->session->set_flashdata('fail','Incorrect user password.Please try again.');
                redirect(base_url('ChangePassword'));
            }

            if ($new_password != $confirm_password) {
                $this->session->set_flashdata('fail', 'New Password and Confirm Password did not match.');
                redirect(base_url('ChangePassword'));
            } else {
                $this->db->SET('password',$confirm_password)->WHERE('id',$login_details[0]['id'])->UPDATE('kf_admin_user');
                $this->session->set_flashdata('success', 'Password Changed Successfully.');
                redirect(base_url('ChangePassword'));
            }
        }
    } 
}
