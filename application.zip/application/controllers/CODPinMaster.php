<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CODPinMaster extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('CommonModel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         KochenFresh/CODPinMaster
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{

		if(check_login())
		{
			/**Listing section**/
			$param = $this->input->get();
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			$config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'CODPinMaster';
            $config["total_rows"] = $this->CommonModel->record_count($param,'kf_cod_pin','pin_code');
            $config["per_page"] = 25;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['all_unit'] = $this->CommonModel->all_data_list($config["per_page"],$page,$param,'kf_cod_pin','pin_code');

            $data['param'] = $param;
            $data['page'] = $page;
            //echo"<pre>";print_r($data);			
			/** listing section **/			
			$data['content']="CODPinMater/add";
			$this->load->view('layout_home',$data);
		}
	}
	
	/**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         EmployeePayroll/Company/save
    * @since        4.11.2016
    * @deprecated   N/A
    */
	
	public function save_data()
	{
		if(check_login())
		{
		$data = $this->input->post();
		//echo"<pre>";print_r($data);
		//edit section
		$insert_data['pin_code'] = strtoupper($data['pin_code']);
		
			//echo"<pre>";print_r($have_data);exit;
	    $have_data = $this->db->where('pin_code',strtoupper($data['pin_code']))->get('kf_cod_pin')->result_array();
		if($data['pin_id']!='')
		{
			if(!empty($have_data) && $have_data[0]['pin_id']!=$data['pin_id'])
			{
				$this->session->set_flashdata('fail', 'Delivery PIN already added');
				redirect(base_url('CODPinMaster'));
			}
			else{
				$this->session->set_flashdata('success', 'Delivery PIN updated successfully');
				$this->db->where('pin_id',$data['pin_id'])->update('kf_cod_pin',$insert_data);
				redirect(base_url('CODPinMaster'));
			}
			
		}
		// insert section
		else{
		
			if(!empty($have_data) && $have_data[0]['status']==1)
			{
				$this->session->set_flashdata('fail', 'Unit already added');
				redirect(base_url('CODPinMaster'));
			}
			else if(!empty($have_data) && $have_data[0]['status']==0)
			{
				$update_data['status'] = 1;
				$this->db->where('pin_id',$have_data[0]['pin_id'])->update('kf_cod_pin',$update_data);
				$this->session->set_flashdata('success', 'Delivery PIN added successfully');
				redirect(base_url('CODPinMaster'));
			}
			else{
				$this->CommonModel->data_insert('kf_cod_pin',$insert_data);
				$this->session->set_flashdata('success', 'Delivery PIN added successfully');
				redirect(base_url('CODPinMaster'));
			}
		}
		}
	}
	
	public function delete($id)
	{
		if(check_login())
		{
		$delete_status['status'] = 0;
		$this->db->where('pin_id',$id)->update('kf_cod_pin',$delete_status);
		$this->session->set_flashdata('success', 'Delivery PIN  deleted successfully');
		redirect(base_url('CODPinMaster'));
		}
	}



    
}
