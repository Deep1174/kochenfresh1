<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ContactUs extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('ContactModel');
    }

	/**
	* load UsersList page
	* 
	* @param1       
	* @return       view page
	* @access       public
	* @author       M.K.Sah
	* @copyright    N/A
	* @link         UsersPayroll/UsersList
	* @since        20.11.2016
	* @deprecated   N/A
	**/

	public function index($page=0)
	{
		if(check_login())
		{
            $search_term = $this->input->GET('search','');
            $search_status = $this->input->GET('status','');
            //echo $search_status;
			if(isset($search_term) ? $search_term:'');		
			if(isset($search_status) ? $search_status:'');		

			$config['use_page_numbers'] = TRUE;
			$config["base_url"] 		= base_url().'ContactUs/index';
			$config["total_rows"] 		= $this->ContactModel->record_count();
			$config["per_page"] 		= 5;
			$config['next_link'] 		= 'Next';
			$config['prev_link'] 		= 'Previous';

			$this->pagination->initialize($config);
			if($page!=0) {
				$page = ($page*$config["per_page"])-$config["per_page"];
			}

			$data['link']	=  $this->pagination->create_links();
			$data['result'] = $this->ContactModel->all_data_list($config["per_page"],$page,$search_term,$search_status);
			//echo"<pre>";print_r($data['result']);exit();
			$data['page']	= $page;

			$data['content']="contact_us/contact_list";
			$this->load->view('layout_home',$data);
		}
	}


	/**
	* load UsersList page
	* 
	* @param1       
	* @return       view page
	* @access       public
	* @author       M.K.Sah
	* @copyright    N/A
	* @link         UsersPayroll/UsersList
	* @since        20.11.2016
	* @deprecated   N/A
	**/

	public function delete($id){
		if(check_login())
		{
			$this->db->where('id', $id)->delete('kf_contact_us');
			$this->session->set_flashdata('success', 'Contact deleted successfully.');
			redirect(base_url('ContactUs'));
		}
	}

	/**
	* load UsersList page
	* 
	* @param1       
	* @return       view page
	* @access       public
	* @author       M.K.Sah
	* @copyright    N/A
	* @link         UsersPayroll/UsersList
	* @since        20.11.2016
	* @deprecated   N/A
	**/

	public function details_by_id()
   {
	    check_login();
	  	$recviedID = $this->input->GET('id');
	  	$data = $this->db->WHERE('id', $recviedID)->get('kf_contact_us')->result_array();
	  	//echo "<pre>";print_r($data[0]['message']);
	    $stats['status'] = 1;
		$this->db->where('id',$recviedID)->update('kf_contact_us',$stats);
		$html='<div class="modal-body">
			<div class="col-md-12"><h2 class="form-head view-information"> Purpose </h2> 
			</div>
			<div class="view-details">
			</div>'.$data[0]['message'].'
			<div class="col-md-6">
			<div class="row mgbt-xs-0">
			</div>
			</div>
			<div class="clearfix"></div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-default yellow yellow-btn" data-dismiss="modal">Close</button>
			</div>
			</div>';  
	         
	  	echo $html;
	}
}
