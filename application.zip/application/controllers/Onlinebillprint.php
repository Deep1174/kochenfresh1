<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Onlinebillprint extends CI_Controller {

    /**
     * load Login page
     * 
     * @param1       
     * @return       view page
     * @access       public
     * @author       S.G 
     * @copyright    N/A
     * @link         
     * @since        14.04.2017
     * @deprecated   N/A
     */
    function __construct() {
        error_reporting(0);
        parent::__construct();
        $this->load->model('CommonModel');
    }

    public function index() {

        $order_id                    = $_GET['id'];
        
        // $count_print                       = $this->db->select('count_print')->where('transaction_id',$transaction_id)->get('fc_transaction table')->result_array();
        
        // $fetch_number                      = $count_print[0]['count_print'];
        // $inc_fetch_number                  = $fetch_number+1;
        
        // $inset_data['count_print']         = $inc_fetch_number;
       
        //$this->CommonModel->edit_data('fc_transaction','transaction_id',$transaction_id,$inset_data);
      
        $this->load->view('Orders/Onlinebillprint');
    }

     public function printbill() {
        $transaction_id   = $_POST['billid'];
        $fetch_number     = $_POST['billcount'];
        $inc_fetch_number = $fetch_number + 1;

        $inset_data['count_print'] = $inc_fetch_number;
       $this->CommonModel->edit_data('fc_transaction','transaction_id',$transaction_id,$inset_data);
    }
}
