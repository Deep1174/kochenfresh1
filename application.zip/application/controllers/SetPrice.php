<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SetPrice extends CI_Controller {

	function __construct() {
        error_reporting(0);
        parent::__construct();
        $this->load->model('CommonModel');
       
    }
    
    public function index($page=0)
	{   
        if(check_login())
        {
            $data['details'] = $this->db->select('*')->where('price_id',1)->get('kf_min_price')->result_array();

            $data['content']  ="Set_Price/add";
        
            $this->load->view('layout_home',$data);
        }
	}

    function save_data()
    {
        if(check_login())
        {
            $data = $this->input->post();
            $data = $this->security->xss_clean($data);
           
         
            $update['min_price']            = $data['price'];
            $update['add_date']             = date('Y-m-d');

            $this->CommonModel->edit_data('price_id','1','kf_min_price',$update);

            $this->session->set_flashdata('success','Price has been updated successfully');
            redirect(base_url('SetPrice'));
        }

    }


}
?>
