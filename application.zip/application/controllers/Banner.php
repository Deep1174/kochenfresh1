<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('BannerModel');
    }

	/**
    * load Banner page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         EmployeePayroll/Company
    * @since        4.11.2016
    * @deprecated   N/A
    **/
	public function index($page=0)
    {

        if(check_login())
        {
            /**Listing section**/
            $param = $this->input->get();
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
            $config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'Banner';
            $config["total_rows"] = $this->BannerModel->record_count($param,'kf_offer','id');
            $config["per_page"] = 25;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['all_banner'] = $this->BannerModel->all_data_list($config["per_page"],$page,$param,'kf_offer','id');

            $data['param'] = $param;
            $data['page'] = $page;
            //echo"<pre>";print_r($data);           
            /** listing section **/         
            $data['content']="Banner/index";
            $this->load->view('layout_home',$data);
        }
    }
    
	/**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         EmployeePayroll/Banner/save
    * @since        4.11.2016
    * @deprecated   N/A
    **/
    public function save()
    {
        if(check_login())
        {
            $data = $this->input->post();
            //echo"<pre>";print_r($data);exit;
            //edit section
            $insert_data['offer_title'] = strtoupper($data['banner_name']);
            $insert_data['offer_heading'] = strtoupper($data['offer_heading']);
			//$insert_data['parent_id'] = 0;
			//$insert_data['status'] = 1;
            /** image upload**/
			if($_FILES['image']['name']){
            $oldname=$_FILES['image']['name'];
            $ext = pathinfo($oldname, PATHINFO_EXTENSION);
            $config['upload_path'] = 'uploads/offer_banner/';
            $config['allowed_types'] = '*';
			$config['overwrite'] = TRUE;
            $config['max_size'] = '';
            //$config['encrypt_name']  = true;
           // $config['file_name'] = "Banner_".$data['banner_name'].".".$ext;
            $this->load->library('upload');
            $this->upload->initialize($config);
            
            if(!$this->upload->do_upload('image'))
              {
                $error = array('error' => $this->upload->display_errors());
                
                $this->session->set_flashdata('fail', 'file upload faild');
                redirect(base_url('Banner'));
              }
            
                 else { 
                    $data1 = array('upload_data' => $this->upload->data()); 
                    $insert_data['offer_image']  = $data1['upload_data']['file_name'];
                 } 
            }
			/** image upload**/
            $have_data = $this->db->where('offer_title',strtoupper($data['banner_name']))->get('kf_offer')->result_array();
            //echo"<pre>";print_r($have_data);exit;
            if($data['id']!='')
            {
                if(!empty($have_data) && $have_data[0]['id']!=$data['id'])
                {
                    $this->session->set_flashdata('fail', 'Banner already added');
                    redirect(base_url('Banner'));
                }
                else{
                    $this->session->set_flashdata('success', 'Banner updated successfully');
                    $this->db->where('id',$data['id'])->update('kf_offer',$insert_data);
                    redirect(base_url('Banner'));
                }
                
            }
            // insert section
            else
            {
            
                if(!empty($have_data) && $have_data[0]['status']==1)
                {
                    $this->session->set_flashdata('fail', 'Banner already added');
                    redirect(base_url('Banner'));
                }
                else if(!empty($have_data) && $have_data[0]['status']==0)
                {
                    $update_data['status'] = 1;
                    $this->db->where('id',$have_data[0]['id'])->update('kf_offer',$update_data);
                    $this->session->set_flashdata('success', 'Banner added successfully');
                    redirect(base_url('Banner'));
                }
                else{
                    $this->BannerModel->data_insert('kf_offer',$insert_data);
                    $this->session->set_flashdata('success', 'Banner added successfully');
                    redirect(base_url('Banner'));
                }
            }
        }
    }

   

    public function Status($id,$statusVal){
        if(check_login()) {
            /*echo $id;echo "<br/>";
            echo $statusVal;exit();*/
            if($statusVal == 1)
                {
                    $changeStatus['status'] = 0;
                    $msg = "This Banner has been inactivated successfully.";
                } else {
                    $changeStatus['status'] = 1;
                    $msg = "This Banner has been activated successfully.";
                }
            $this->db->where('id',$id)->update('kf_offer',$changeStatus);
            $this->session->set_flashdata('success', $msg);
            redirect(base_url('Banner'));
        }
    }


}