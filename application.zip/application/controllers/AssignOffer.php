<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AssignOffer extends CI_Controller {

	function __construct() {
    //error_reporting(0);
    parent::__construct();
    $this->load->model('CommonModel');
  }

	/**
  * load AssignOffer page
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       P.C 
  * @copyright    N/A
  * @link         
  * @since        4.11.2016
  * @deprecated   N/A
  **/

  public function index($page=0)
  {

    if(check_login())
    {
      
      $data['offer'] =$this->db->where('status',1)->get('kf_offer')->result_array(); 
      $data['category'] =$this->db->where('status',1)->get('kf_category')->result_array();   
      $data['content']="Assign_offer/index";
      $this->load->view('layout_home',$data);
    }
  }

  public function get_item()
  {
    if(check_login())
    {
    $data = $this->input->POST();
    //echo "<pre>"; print_r($data); 
    $item_list = $this->db->where('status',1)->where('cat_id',$data['cat_id'])->get('kf_item')->result_array();
   
//$offer_list = $this->db->where('offer_id',$data['offer_id'])->where('cat_id',$data['cat_id'])->get('kf_assign_offer')->result_array();
    //echo $this->db->last_query();
    //echo "<pre>"; print_r($offer_list); exit();
    
    
   $html= ' <table class="table table-bordered table-striped">
            <thead class="thead-inverse">
              <tr>
                <th><div class="headname"> </div></th>
                <th><div class="headname">Item Name </div></th>
                
              </tr>
            </thead>
            <tbody>';
            if(!empty($item_list)){
             foreach($item_list as $k=>$val){ 

    // $count = count($val['item_id']);
    // for($i=0;$i<$count; $i++)
    // {
      
          //  $offer_list = $this->db->where('offer_id',$data['offer_id'])->where('item_id',$val['item_id'][$i])->get('kf_assign_offer')->result_array();
          //  echo $this->db->last_query();
//echo "<pre>"; print_r($offer_list); //exit();

      
     //  }
           $html.= '<tr>
              <td>
              <input type="checkbox" name="item[]" value="'.$val['item_id'].'"></td><td>'.$val['item_name'].'</td></tr>';
             } 
            }
            else{
              $html.='<tr><td colspan="2" align="center">No data found</td></tr>';
            } 
           $html.= ' </tbody>
          </table>';
   echo $html;
    }
  }
	

  /**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         EmployeePayroll/Company/save
    * @since        4.11.2016
    * @deprecated   N/A
    */
  
  public function save_data()
  {
    if(check_login())
    {
    $data = $this->input->post();
   // echo"<pre>";print_r($data);
    $data = $this->security->xss_clean($data);
    //Item insert data
    $count = count($data['item']);
    //echo "<pre>"; print_r($count); exit();
    
    
    for($i=0;$i<$count; $i++)
    {
      $have_item = $this->db->where('offer_id',$data['select_offer'])->where('item_id',$data['item'][$i])->get('kf_assign_offer')->result_array();
      //echo"<pre>";print_r($have_item);exit();
      
      $insert_data['cat_id'] =  $data['select_cat'];
      $insert_data['offer_id'] =  $data['select_offer'];
      $insert_data['item_id'] =  $data['item'][$i];

     // echo "<pre>"; print_r($insert_data); 
      
      if(!empty($have_item))
      {
        
         $this->db->where('assign_id',$have_item[0]['assign_id'])->update('kf_assign_offer',$insert_data);
      }
       else{
         
         $this->db->insert('kf_assign_offer',$insert_data);
       }
    }
    //insert into data base
    
    $this->session->set_flashdata('success', 'Assign Offer set successfully');
      redirect(base_url('AssignOffer'));
  }
  }


  
}
