<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('CommonModel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         EmployeePayroll/Company
    * @since        4.11.2016
    * @deprecated   N/A
    **/
	public function index($page=0)
	{
		if(check_login())
		{
			$param = $this->input->get();
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			$config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'Category';
            $config["total_rows"] = $this->CommonModel->cat_record_count($param,'kf_category','cat_name');
            $config["per_page"] = 5;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['param'] = $param;
            $data['page'] = $page;
            $data['all_category'] = $this->CommonModel->cat_all_data_list($config["per_page"],$page,$param,'kf_category','cat_name');
            //echo"<pre>";print_r($data);			
			/** listing section **/			
			$data['content']="Category/index";
			$this->load->view('layout_home',$data);
		}
	}
	
	/**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         EmployeePayroll/Category/save
    * @since        4.11.2016
    * @deprecated   N/A
    **/
    public function save()
    {
        if(check_login())
        {
            $data = $this->input->post();
           // echo"<pre>";print_r($data);exit;
            //edit section
            $insert_data['cat_name'] = strtoupper($data['cat_name']);
			$insert_data['parent_id'] = 0;
			$insert_data['status'] = 1;
            /** image upload**/
			if($_FILES['image']['name']){
            $oldname=$_FILES['image']['name'];
            $ext = pathinfo($oldname, PATHINFO_EXTENSION);
            $config['upload_path'] = 'uploads/category/';
            $config['allowed_types'] = '*';
			$config['overwrite'] = TRUE;
            $config['max_size'] = '';
            //$config['encrypt_name']  = true;
            $config['file_name'] = "cat_name_".$data['cat_name'].".".$ext;
            $this->load->library('upload');
            $this->upload->initialize($config);
            
            if(!$this->upload->do_upload('image'))
              {
                $error = array('error' => $this->upload->display_errors());
                
                $this->session->set_flashdata('fail', 'file upload faild');
                redirect(base_url('tender/add'));
              }
            
                 else { 
                    $data1 = array('upload_data' => $this->upload->data()); 
                    $insert_data['image']  = $data1['upload_data']['file_name'];
                 } 
            }
			/** image upload**/
            $have_data = $this->db->where('cat_name',strtoupper($data['cat_name']))->get('kf_category')->result_array();
            //echo"<pre>";print_r($have_data);exit;
            if($data['cat_id']!='')
            {
                if(!empty($have_data) && $have_data[0]['cat_id']!=$data['cat_id'])
                {
                    $this->session->set_flashdata('fail', 'Category already added');
                    redirect(base_url('Category'));
                }
                else{
                    $this->session->set_flashdata('success', 'Category updated successfully');
                    $this->db->where('cat_id',$data['cat_id'])->update('kf_category',$insert_data);
                    redirect(base_url('Category'));
                }
                
            }
            // insert section
            else
            {
            
                if(!empty($have_data) && $have_data[0]['status']==1)
                {
                    $this->session->set_flashdata('fail', 'Category already added');
                    redirect(base_url('Category'));
                }
                else if(!empty($have_data) && $have_data[0]['status']==0)
                {
                    $update_data['status'] = 1;
                    $this->db->where('cat_id',$have_data[0]['cat_id'])->update('kf_category',$update_data);
                    $this->session->set_flashdata('success', 'Category added successfully');
                    redirect(base_url('Category'));
                }
                else{
                    $this->CommonModel->data_insert('kf_category',$insert_data);
                    $this->session->set_flashdata('success', 'Category added successfully');
                    redirect(base_url('Category'));
                }
            }
        }
    }

    public function delete($id)
    {
        if(check_login())
        {
        $delete_status['status'] = 0;
        $this->db->where('cat_id',$id)->update('kf_category',$delete_status);
        $this->session->set_flashdata('success', 'Category deleted successfully.');
        redirect(base_url('Category'));
        }
    }


}