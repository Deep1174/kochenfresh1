<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'/third_party/mpdf/mpdf.php';
class Orders extends CI_Controller {

	function __construct() {
		//error_reporting(0);
        parent::__construct();
		$this->load->model('OrderModel');
		$this->load->library('excel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         EmployeePayroll/Company
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{
		if(check_login())
		{
			$param = $this->input->get();
			
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			if(isset($param['name'])&&$param['name']!='')
            {
                $name=$param['name'];
            }
			else{
				 $name='';
			}
            if(isset($param['order_id']))
            {
                $order_id  = $param['order_id'];
            }
            else
            {
                $order_id = '';
            }
			 if(isset($param['status']))
            {
                $status  = $param['status'];
            }
            else
            {
                $status = '';
            }
			if(isset($param['to_date']))
            {
                $to_date  = $param['to_date'];
            }
            else
            {
                $to_date = '';
            }
			if(isset($param['from_date']))
            {
                $from_date  = $param['from_date'];
            }
            else
            {
                $from_date = '';
            }
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			$config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'Orders?name='.$name.'&order_id='.$order_id.'&status='.$status.'&from_date='.$from_date.'&to_date='.$to_date;
            $config["total_rows"] = $this->OrderModel->record_count($param);
            $config["per_page"] = 5;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['order_list'] = $this->OrderModel->all_data_list($config["per_page"],$page,$param);

            $data['param'] = $param;
            $data['page'] = $page;
            			
			/** listing section **/		
			//$data['order_list']= $this->db->where('status',1)->get('kf_category')->result_array();
			//echo"<pre>";print_r($data['order_list']);		exit;	
			$data['content']="Orders/order_list";
			$this->load->view('layout_home',$data);
		}
	}
	
	public function view($order_id)
	{
		$data['code'] = $this->input->get('code');
		$sql = " SELECT * FROM  kf_order orders left join kf_user user on user.user_id=orders.user_id left join  kf_order_items order_item on order_item.order_id=orders.order_id left join kf_item item on  order_item.item_id=item.item_id left join kf_item_price_unit price on price.id=order_item.unit_price_id left join kf_unit_master unit on unit.unit_id=price.unit_id where orders.order_id=".$order_id;
		$result = $this->db->query($sql)->result_array();
		$data['result']=$result;
		$data['content']="Orders/View_order";
		$this->load->view('layout_home',$data);
	}
public function change_mark()
  {
	  $data = $this->input->post();
	 // echo"<pre>";print_r($status);exit;
	  $update_data['status'] = $data['status'];
	  
	  $this->db->where('order_id',$data['order_id'])->update('kf_order',$update_data);
	  //echo $this->db->last_query();exit;
	  redirect($_SERVER['HTTP_REFERER']);
  }
  public function change_status($order_id)
  {
	  $status = $this->input->get('status');
	  if($status ==0 || $status ==2)
	  {
		  $data['status'] = 1;
	  }
	  else{
		   $data['status'] = 0;
	  }
	  
	  $this->db->where('order_id',$order_id)->update('kf_order',$data);
	  //echo $this->db->last_query();exit;
	  redirect($_SERVER['HTTP_REFERER']);
  }
public function cancelOrder($order_id)
{
	  $data['status'] = 2;
	  $this->db->where('order_id',$order_id)->update('kf_order',$data);
	  
	  redirect($_SERVER['HTTP_REFERER']);
}

public function paid_amount($order_id)
{   
	  
	  $payment_status = $this->input->get('status');
	  if($payment_status ==0 )
	  {
		  $data['status'] = 1;
		  $data['payment_status'] = 1;
	  }
	  else{
		   $data['payment_status'] = 0;
	  }
	  $this->db->where('order_id',$order_id)->update('kf_order',$data);
	  
	  redirect($_SERVER['HTTP_REFERER']);
}

    

public function print_order_list()
	{
		if(check_login())
		{
		//pdf settings
		$pdf = new mPDF('utf-8', array(290,295));
        $pdf->AddPage(P, // L - landscape, P - portrait 
        'A5', '12', '', '',
        25, // margin_left
        25, // margin right
       5, // margin top
       5, // margin bottom
       5, // margin header
        5); // margin footer
	//pdf settings
		$data = $this->input->get('search_data');
		$param = json_decode($data);
		//echo"<pre>";print_r($param);
		$date= date('Y-m-d');
	   $where=" ";
	   $date_range = " (";
       if(isset($param->from_date) && $param->from_date!='')
		{
			
			$where.=" and DATE(orders.order_date) >='". date('Y-m-d',strtotime($param->from_date))."'";
			$from_date = $param->from_date;
			$date_range .= $from_date . "- ";
		}
		if(isset($param->to_date) && $param->to_date!='')
		{
			
			$where.=" and DATE(orders.order_date) <='". date('Y-m-d',strtotime($param->to_date))."'";
			$to_date = $param->to_date;
			$date_range .= $to_date;
		}
		else
		{
			$date_range .= date('d-m-Y');
		}
		 $date_range .= " ) ";
		/** search section**/
		if(!isset($param->from_date) && !isset($param->to_date) or( $param->from_date=='' && $param->to_date==''))
		{
        $where.=" and DATE(orders.order_date) = '$date'";
		}
		//name
		 if(isset($param->name) && $param->name!='')
		{
			
			 $where .= " AND user.name like '%".$param->name."%' ";
		}
		//order_id
		 if(isset($param->order_id) && $param->order_id!='')
		{
			
			 $where .= " AND orders.order_code like '%".$param->order_id."%' ";
		}
	    if(isset($param->status) && $param->status!='')
		{
			
			 $where .= " AND orders.status =".$param->status;
		}
      
	   
		   $sql="SELECT  orders.*,user.name,user.lastname,user.email,user.phone   FROM  kf_order orders left join kf_user user on user.user_id=orders.user_id  WHERE 1    $where  ORDER BY  orders.order_id DESC" ;  	   
             
        $recordSet = $this->db->query($sql);
		
        $result = $recordSet->result_array();
		//echo"<pre>";print_r($result);
				$html='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Order List</title>

<style type="text/css">
 body { margin:0; padding:0; font-family:Verdana, Geneva, sans-serif; font-size:14px;}
 table td,  table  { border-collapse:collapse;}
  table td { padding:5px; border:1px solid #000; padding:8px;}
 
 @media print{ body { font-family:Verdana, Geneva, sans-serif; font-size:14px;}  table td { border:1px solid #000; border-collapse:collapse;} table { border-collapse:collapse; padding:8px;}}
</style>
</head>

<body>
<div style="width:960px; margin:0 auto 15px auto;">
<div style="padding:15px 0; text-align:right;"></div>
<p style="text-align:center;" ><img src="'.base_url().'images/log02.png" width="200" height="50"></p>

<P style="text-align:center; ">Order List'.$date_range.' </P>
  
<table class="table table-bordered table-striped "  width="100%"   >
  <tr>
    <td><strong>Order ID</strong></td>
	<td><strong>Order Date</strong></td>
    <td><strong>Customer Name</strong></td>
    <td><strong>Email</strong></td>
    <td><strong>Phone No</strong></td>
    <td><strong>Total Amount</strong></td>
    <td><strong>Coupon Name</strong></td>
	<td><strong>Payment Status</strong></td>
	<td><strong>Order Status</strong></td>
	
  </tr>';
  foreach($result as $k=>$val){
	  
	
	if($val['status'] == 0)
	  {
		  $status ="pending";
	  }	
		
		elseif($val['status'] == 1){
			$status ="Out For Delevery";
		}
		elseif($val['status'] == 2){
			$status ="canceled";
		}
		elseif($val['status'] == 3){
			$status ="Delivered";
		}
		elseif($val['status'] == 4){
			$status ="Return";
		}		
	
 if($val['payment_status'] == 1)
 {
	 $payment_status = "Paid";
 }
 else{
	 $payment_status = "Unpaid";
 }


	   $item_details = get_total_item_count_price($val['order_id']);
	   $total_amount = isset($item_details['total_amount'])?$item_details['total_amount']:'0';
	   $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';
	   $Coupon_name = $this->db->select('cupon_name')->where('cupon_id',$val['cupon_id'])->get('kf_cupon')->result_array();
  $html.='<tr>
  <td>'.$val['order_code'].'</td>
   <td>'.date('d-m-Y H:i A', strtotime($val['order_date'])).'</td>
  <td>'.$val['name']." ".$val['lastname'].'</td>
  <td>'.$val['email'].'</td>
  <td>'.$val['phone'].'</td>
  <td>'.$total_amount.'</td>';

  if(count($Coupon_name) > 0){
  	$html .= '<td>'.$Coupon_name['cupon_name'].'</td>';
  } else {
  	$html .= '<td>N/A</td>';
  }


  $html.= '<td>'.$payment_status.'</td>
  <td>'.$status.'</td>

  </tr>';
  
  }
  
 
  
$html.='</table></div>
</body>
</html>
';
//echo $html;exit;
$pdfname = "sales-voucher-print-copy";
							 //echo $html;exit;
							  $pdf->WriteHTML($html);
							  $pdfFilePath = "orderlist".".pdf";
							  $pdf->Output($pdfFilePath,'I');
	}
	}





	public function print_user()
	{
		if(check_login())
		{
			//pdf settings
			$pdf = new mPDF('utf-8', array(290,295));
	        $pdf->AddPage(P, // L - landscape, P - portrait 
	        'A5', '12', '', '',
	        25, // margin_left
	        25, // margin right
	       	5, // margin top
	       	5, // margin bottom
	       	5, // margin header
	        5); // margin footer

			$data = $this->input->get('user_id');
			//echo "<pre>";print_r($data);
			$sql = " SELECT * FROM  kf_order orders left join kf_user user on user.user_id=orders.user_id left join  kf_order_items order_item on order_item.order_id=orders.order_id left join kf_item item on  order_item.item_id=item.item_id left join kf_item_price_unit price on price.id=order_item.unit_price_id left join kf_unit_master unit on unit.unit_id=price.unit_id where orders.order_id=".$data;
			$result = $this->db->query($sql)->result_array();
			//echo "<pre>";print_r($result);exit();



			$html='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
			<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<title>User Details</title>

			<style type="text/css">
			 body { margin:0; padding:0; font-family:Verdana, Geneva, sans-serif; font-size:14px;}
			 table td,  table  { border-collapse:collapse;}
			  table td { padding:5px; border:1px solid #000; padding:8px;}
			 
			 @media print{ body { font-family:Verdana, Geneva, sans-serif; font-size:14px;}  table td { border:1px solid #000; border-collapse:collapse;} table { border-collapse:collapse; padding:8px;}}
			</style>
			</head>

			<body>
			<div style="width:960px; margin:0 auto 15px auto;">
			<div style="padding:15px 0; text-align:right;"></div>
			<p style="text-align:center;" ><img src="'.base_url().'images/log02.png" width="200" height="50"></p>';
			
			$shipping_details = $this->db->where('user_id',$result[0]['user_id'])->get('kf_shipping')->result_array();

			// echo "<pre>";
			// print_r($shipping_details);exit();

			$html .= '<div class="row" style="margin-bottom: 25px; padding: -15px 10px 0 10px;">
        <div class="col-md-12" style="font-weight: bold; padding: 10px 0 20px 0;">
        <center>
          <u>Shipping Details</u>
        </center>
          
        </div>
          <div class="col-md-3" style="font-weight: bold;">
            Date:
          </div>
          <div class="col-md-3">'.date('d-m-Y H:i A',strtotime($result[0]['order_date'])).'</div>
          <div class="col-md-3" style="font-weight: bold;">
            Order Id: 
          </div>
          <div class="col-md-3">'.$result[0]['order_code'].'</div>
           <div class="col-md-12" style="padding: 7px;"></div><div class="clearfix"></div>
          <div class="col-md-3" style="font-weight: bold;">
             Name:
          </div>
          <div class="col-md-3">'.$shipping_details[0]['shipping_fname']." ".$shipping_details[0]['shipping_lname'].'</div>
          <div class="col-md-3" style="font-weight: bold;"> Phone No: </div>
          <div class="col-md-3">'.$shipping_details[0]['shipping_phone'].'</div>
          <div class="col-md-12" style="padding: 7px;"></div><div class="clearfix"></div>
          <div class="col-md-3" style="font-weight: bold;">
            Pin Code: 
          </div>
          
          <div class="col-md-3">'.$shipping_details[0]['shipping_code'].'</div>
          <div class="col-md-3" style="font-weight: bold;">
            Address: 
          </div>
          
          <div class="col-md-3">'.$shipping_details[0]['Shipping_add'].'</div>   
          <div class="col-md-12" style="padding: 7px;"></div><div class="clearfix"></div>
          <div class="col-md-3" style="font-weight: bold;">
            Note:
          </div>
          <div class="col-md-12">'.$shipping_details[0]['notes'].'</div>
          <div class="clearfix"></div>
        </div>';

			  
			$html .= '<table class="table table-bordered table-striped "  width="100%"   >
			  <tr>
			    <td><strong>SL No.</strong></td>
				<td><strong>Item</strong></td>
			    <td><strong>Unit</strong></td>
			    <td><strong>Unit Price</strong></td>
			    <td><strong>Quantity</strong></td>
			    <td><strong>Total Price</strong></td>
			  </tr>';

			  $grand_total =0;
			  foreach($result as $k=>$val){


				  
			  $html .='<tr><td>'; $html .= $k+1;
			  $html .= '</td><td>'; $html .= $val['item_name'];
			  $html .='</td>
			  <td>'.$val['unit_value'].' '.$val['unit_name'].'/-</td>
			  <td>'.number_format($val['price'],2).'</td>
			  <td>'.$val['quantity'].'</td>
			  <td>'.number_format($total = $val['quantity'] *  $val['price'],2).'</td>
			  </tr><tbody>';
			  
			  
  				$grand_total = $grand_total + $total;

  			}
 
  				$html .= '<tr>
  				<th colspan="5" style="text-align:right;">Total</th>
                <th>'. number_format($grand_total,2).'</th>
  				</tr>';
				$html.='</tbody></table></div>
				</body>
				</html>
				';
				//echo $html;exit;
				$pdfname = "sales-voucher-print-copy";
											 //echo $html;exit;
											  $pdf->WriteHTML($html);
											  $pdfFilePath = "userdetails".".pdf";
											  $pdf->Output($pdfFilePath,'I');


		}
	}








	
	public function excel_dowload()
   {
	   $data = $this->input->get('search_data');
		$param = json_decode($data);
		//echo"<pre>";print_r($param);
		$date= date('Y-m-d');
	   $where=" ";
       if(isset($param->from_date) && $param->from_date!='')
		{
			
			$where.=" and DATE(orders.order_date) >='". date('Y-m-d',strtotime($param->from_date))."'";
		}
		if(isset($param->to_date) && $param->to_date!='')
		{
			
			$where.=" and DATE(orders.order_date) <='". date('Y-m-d',strtotime($param->to_date))."'";
		}
		/** search section**/
		if(!isset($param->from_date) && !isset($param->to_date) or( $param->from_date=='' && $param->to_date==''))
		{
        $where.=" and DATE(orders.order_date) = '$date'";
		}
		//name
		 if(isset($param->name) && $param->name!='')
		{
			
			 $where .= " AND user.name like '%".$param->name."%' ";
		}
		//order_id
		 if(isset($param->order_id) && $param->order_id!='')
		{
			
			 $where .= " AND orders.order_code like '%".$param->order_id."%' ";
		}
	    if(isset($param->status) && $param->status!='')
		{
			
			 $where .= " AND orders.status =".$param->status;
		}
      
	   
		   $sql=" SELECT  orders.*,user.name,user.lastname,user.email,user.phone   FROM  kf_order orders left join kf_user user on user.user_id=orders.user_id  WHERE 1    $where  ORDER BY  orders.order_id DESC" ;  	   
             
        $recordSet = $this->db->query($sql);
		
        $result = $recordSet->result_array();
		
		$details = array();
		foreach($result as $k1=>$val1)
		{
		   $item_details = get_total_item_count_price($val1['order_id']);

		   $total_amount = !empty($item_details['total_amount'])?$item_details['total_amount']:'0';
		   // echo "<pre>"; print_r($total_amount);
		   $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';
		   $Coupon_name = $this->db->select('cupon_name')->where('cupon_id',$val['cupon_id'])->get('kf_cupon')->result_array();
			/**status **/
			if($val1['status'] == 0)
			  {
				  $status ="pending";
			  }	
		
		elseif($val1['status'] == 1){
			$status ="Out For Delevery";
		}
		elseif($val1['status'] == 2){
			$status ="canceled";
		}
		elseif($val1['status'] == 3){
			$status ="Delivered";
		}
		elseif($val1['status'] == 4){
			$status ="Return";
		}		
		
			$details[$k1]['order_id'] = $val1['order_code'];
			$details[$k1]['name'] = $val1['name']." ".$val1['lastname'];
			$details[$k1]['email'] = $val1['email'];
			$details[$k1]['phone'] = $val1['phone'];

	
			if(count($total_amount) > 0)
			{
				$details[$k1]['total_amount'] = $total_amount;
			}
			
			
			if(count($Coupon_name) > 0)
			{
				$details[$k1]['cupon_id'] = $Coupon_name['cupon_name'];
			}
			else
			{
				$details[$k1]['cupon_id'] = 'N/A';
			}
			$details[$k1]['status'] = $status;
			$details[$k1]['order_datedate'] = date('d-m-Y H:i A', strtotime($val1['order_date']));
		}
		//echo"<pre>";print_r($details);exit;
	    $this->excel->setActiveSheetIndex(0);     
        $this->excel->getActiveSheet()->setTitle('Sheet1');
		/** <!-- header section-->**/
		for ($col = 'A'; $col != 'J'; $col++) {
        $this->excel->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                }
        // $this->excel->getActiveSheet()->setCellValue('A1', 'Summary For Order List');
		 //$this->excel->getActiveSheet()->getStyle('A1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
		$blueBold = array( "font" => array("bold" => true,"color" => array("rgb" => "0000ff"),),);
		$greenNotBold = array("font" => array("bold" => true,"color" => array("rgb" => "ce2208"),),);
		$this->excel->setActiveSheetIndex(0)->mergeCells('A1:I1');
                $this->excel->getActiveSheet()->setCellValue('A1', 'Item Order List');
                $this->excel->getActiveSheet()->getStyle("A1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER)->applyFromArray($blueBold);

			$this->excel->getActiveSheet()->getStyle('A1')->applyFromArray($blueBold);
			$this->excel->getActiveSheet()->getRowDimension('1')->setRowHeight(40);
			$this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(100);
			
		 //$this->excel->getActiveSheet()->getStyle('A1')->getFill()->getStartColor()->setARGB('#86a5d6');

		 $this->excel->getActiveSheet()->setCellValue('A3', 'Order ID ');
		 $this->excel->getActiveSheet()->getStyle('A3')->applyFromArray($greenNotBold);
		 $this->excel->getActiveSheet()->setCellValue('B3', 'Customer Name ');
		 $this->excel->getActiveSheet()->getStyle('B3')->applyFromArray($greenNotBold);
		 $this->excel->getActiveSheet()->setCellValue('C3', 'Email ');
		 $this->excel->getActiveSheet()->getStyle('C3')->applyFromArray($greenNotBold);
		 $this->excel->getActiveSheet()->setCellValue('D3', 'Phone');
		 $this->excel->getActiveSheet()->getStyle('D3')->applyFromArray($greenNotBold);
		 $this->excel->getActiveSheet()->setCellValue('E3', 'Total Amount');
		 $this->excel->getActiveSheet()->getStyle('E3')->applyFromArray($greenNotBold);
		 $this->excel->getActiveSheet()->setCellValue('F3', 'Coupon Name');  
		 $this->excel->getActiveSheet()->getStyle('F3')->applyFromArray($greenNotBold);
		 $this->excel->getActiveSheet()->setCellValue('G3', 'Order Status'); 
		 $this->excel->getActiveSheet()->getStyle('G3')->applyFromArray($greenNotBold);
		 $this->excel->getActiveSheet()->setCellValue('H3', 'Order Date');
		 $this->excel->getActiveSheet()->getStyle('H3')->applyFromArray($greenNotBold);
			
        for ($col = ord('A'); $col <= ord('C'); $col++) {
            $this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(12);

            $this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
		$this->excel->getActiveSheet()->fromArray($details, null, 'A4');


        $this->excel->getActiveSheet()->getStyle('A555555')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('B555555')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('C555555')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('D555555')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('E555555')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('F555555')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $this->excel->getActiveSheet()->getStyle('G555555')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
		$this->excel->getActiveSheet()->getStyle('H555555')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $filename = 'order_list.xls';
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $filename . '"'); 
        header('Cache-Control: max-age=0'); 
       
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
       
        $objWriter->save('php://output');
   }
   
}
