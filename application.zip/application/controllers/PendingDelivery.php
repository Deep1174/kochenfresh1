<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'/third_party/mpdf/mpdf.php';
class PendingDelivery extends CI_Controller {

	function __construct() {
		error_reporting(0);
    parent::__construct();
		$this->load->model('PendingModel');
		$this->load->library('excel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         EmployeePayroll/Company
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{
		if(check_login())
		{
			$param = $this->input->get();
			
      $param = $this->security->xss_clean($param);

			if(isset($param['order_date']))
      {
        $order_date  = $param['order_date'];
      }
      else
      {
        $order_date = '';
      }
      $config = array();
      $config['page_query_string']        = TRUE;
      $config['query_string_segment']     = 'page';
      $config['use_page_numbers']         = TRUE;
      $config["base_url"]                 = base_url().'PendingDelivery?order_date='.$order_date;
      $config["total_rows"]               = $this->PendingModel->record_count($param);
      $config["per_page"]                 = 5;
      $config['next_link']                = 'Next';
      $config['prev_link']                = 'Previous';
      $data['all_item']                   = $this->PendingModel->all_data_list($config["per_page"],$page,$param);
      //$data['searchString']               = $this->input->post('searchSrting','');
      $data['page']                       = $page;
      $data['param']                      = $param;
      $data['order_date']                 = $order_date;
			$data['content']="Pending_delivery/pending_order_list";
			$this->load->view('layout_home',$data);
		}
	}
   
}
