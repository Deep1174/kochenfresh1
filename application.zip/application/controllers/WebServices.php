<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class WebServices extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('UsersModel');
		$this->load->library('email');
    }

	 /**
    * web api for login check with user email and password also check ip address is blocked or active
    * 
    * @param1       @email,@password,@ip addess
    * @return       user id if matched / message of invalid credetial if not matched
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         
    * @since        22.11.2017
    * @deprecated   N/A
    */
  public function check_login_details()
  {
  	date_default_timezone_set('Asia/Kolkata');

	 $phone        = $this->db->select('phone')->get('kf_globalsetting')->result_array();
	 $inquiry      = $phone[0]['phone'];
	 $email        = $this->input->get('email');
	 $password     = $this->input->get('password');
     $ip_address   = $this->input->get('ip_address');
	 
	 $md5_convert_data 	= md5(trim($password));
	 $salt_key 			= get_encript_id(trim($password));
	 $password 			= $md5_convert_data.$salt_key;
	 //** **//
	 $user_details = $this->db->where('email',$email)->where('password',$password)->where('status',1)->get('kf_user')->result_array();
     $phone        = $this->db->select('phone')->get('kf_globalsetting')->result_array(); 
	 $is_active_ip = $this->db->where('status',1)->where('ip_Address',$ip_address)->get('kf_ip_address')->result_array();
	
	 if(!empty($user_details))
	 {
		 
		 $response['response']     = 'true' ;
		 $response['message']      = 'successfully logedin' ;
		 $response['user_details'] = $user_details;
		 $response['inquiry']      = $inquiry;
		 echo json_encode($response);
	 }
	 else
	 {
		 $response['response'] = 'false' ;
		 $response['message']  = 'Invalid credential' ;
		 $response['user_id']  = 'null' ;
		 echo json_encode($response);
	 }
  }

	public function save_registerd_data()
	  {
	  	date_default_timezone_set('Asia/Kolkata');
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);
		
		$have_email = $this->db->where('email',$data['email'])->where('status', '1')->get('kf_user')->result_array();
		
		if(!empty($have_email))
		{
			$response['response'] = 'false' ;
			$response['message']  = 'email alreay exsist' ;
			echo json_encode($response);
		}
		else{
			$md5_convert_data 	= md5(trim($data['pwd']));
			$salt_key 			= get_encript_id(trim($data['pwd']));
			$password 			= $md5_convert_data.$salt_key;
			
			$insert_data['name']                   = $data['name'];
			$insert_data['lastname']               = $data['lastname'];
			$insert_data['email']                  = $data['email'];
			$insert_data['address']                = $data['address'];
			$insert_data['phone']                  = $data['phone'];
			$insert_data['pin_code']               = $data['pin'];
			$insert_data['ip_address']             = $data['mac_address'];
			$insert_data['password']               = $password;
			$insert_data['status']                 = 1;
			date_default_timezone_set('Asia/Kolkata');
          
			$insert_data['registration_date']      =  $curdate = date('Y-m-d, H:i:s a', time());
			
			$this->db->insert('kf_user',$insert_data);
			$insert_id = $this->db->insert_id();
            
            $ship_data['user_id']              = $insert_id;
            $ship_data['shipping_fname']       = $data['name'];
            $ship_data['shipping_lname']       = $data['lastname'];
            $ship_data['shipping_phone']       = $data['phone'];
            $ship_data['shipping_code']        = $data['pin'];
            $ship_data['Shipping_add']         = $data['address'];
            $ship_data['shipping_status']      ='1';
           
            $this->db->insert('kf_shipping',$ship_data);

			if($insert_id!='')
			{
				$have_id = $this->db->where('ip_Address',$data['mac_address'])->get('kf_ip_address')->result_array();
				if(empty($have_id)){
				$insert_ip['ip_Address'] = $data['mac_address'];
				$insert_ip['status'] = 1;
				$this->db->insert('kf_ip_address',$insert_ip);
				}
				/**check mail**/
				$mailbody1 = '<div style="width:650px; margin:0px auto;  padding:0px 0px; background:#fff;" >

            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff" style="border:20px solid #29387b" >
                <tr>
                  <td width="100%" colspan="10" style="flot:left; background:#fff; padding:15px 0 10px 15px; text-align:center;"><img src="http://' . $_SERVER['HTTP_HOST'] . '/admin/images/logotext.png" height="50" width="500"  alt=""></td>
                </tr>
                <tr>
                     <td style="padding:0px 15px; background:#29387b;"><p style="text-align:center; color:#fff; text-transform:uppercase; font-size:22px; margin:0; padding:10px 0; font-family:Verdana, Geneva, sans-serif; ">
                  Successfully registerd</p></td>
                </tr>
                            <tr>
                              <td style="padding:20px 15px; background:#fff;">
                                 <p>Hello '.$data['name'].'</p>
                                 <p>Your Registration Details :</p>
                                 <p>Email : '.$data['email'].'</p>
                                 <p>Password : '.$data['pwd'].'</p>
                                 <p>You have successfully registerd.</p>
                                 <p> Thank you for Registration .</p>
                                
                                <p>&nbsp;</p>
                    <p style="font-family:Verdana, Geneva, sans-serif; font-size:14px;">Regards,</p>
                    <p style="font-family:Verdana, Geneva, sans-serif; font-size:14px;">Kochen Fresh Team</p>
                  </td>
                </tr>
               <tr>
                 
               </tr>
               <tr>
                 <td style="background:#e32124; padding:6px 0;">
                <p style="color:#fff; font-family:Verdana, Geneva, sans-serif; text-align:center; font-size:12px;"> ©' . date('Y') . ' All Rights Reserved</p>
                </td>
               </tr>
            </table>
            </div>';
			

            $this->email->from('Aalexjhones@gmail.com', 'Kochen Fresh');
            $this->email->to($data['email']);
            $this->email->set_mailtype('html');

            $this->email->subject('Successfull registration');
            $this->email->message($mailbody1);
            $send = $this->email->send();
			/** check mail*/
				$response['response'] = 'true' ;
				$response['message']  = 'successfully registered' ;
				echo json_encode($response);
			}
			else{
				$response['response'] = 'false' ;
				$response['message']  = 'something wrong,try after sometime' ;
				echo json_encode($response);
			}
		}
	  }


	  	public function forgot_password()
	  {
	  	date_default_timezone_set('Asia/Kolkata');
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);
		
		$have_email = $this->db->where('email',$data['email'])->get('kf_user')->result_array();
		
		if(!empty($have_email))
		{
			$randnum  = rand(11111,99999);
			
			$md5_convert_data 	= md5(trim($randnum));
			$salt_key 			= get_encript_id(trim($randnum));
			$password 			= $md5_convert_data.$salt_key;

			$update_data['password'] = $password;

            $this->db->where('email',$data['email'])->update('kf_user',$update_data);

            $username = $this->db->select('name')->where('email',$data['email'])->get('kf_user')->result_array();


		
		/**check mail**/
		$mailbody1 = '<div style="width:650px; margin:0px auto;  padding:0px 0px; background:#fff;" >

            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff" style="border:20px solid #29387b" >
                <tr>
                  <td width="100%" colspan="10" style="flot:left; background:#fff; padding:15px 0 10px 15px; text-align:center;"><img src="http://' . $_SERVER['HTTP_HOST'] . '/admin/images/logotext.png" height="50" width="500"  alt=""></td>
                </tr>
                <tr>
                     <td style="padding:0px 15px; background:#29387b;"><p style="text-align:center; color:#fff; text-transform:uppercase; font-size:22px; margin:0; padding:10px 0; font-family:Verdana, Geneva, sans-serif; ">
                  Successfully registerd</p></td>
                </tr>
                            <tr>
                              <td style="padding:20px 15px; background:#fff;">
                                 <p>Hello '.$username[0]['name'].'</p>
                                 <p>Your New Password :</p>
                                 <p>Password : '.$randnum.'</p>
                                 <p>Please, Login with the new password.</p>
                                 <p> Thank you .</p>
                                
                                <p>&nbsp;</p>
                    <p style="font-family:Verdana, Geneva, sans-serif; font-size:14px;">Regards,</p>
                    <p style="font-family:Verdana, Geneva, sans-serif; font-size:14px;">Kochen Fresh Team</p>
                  </td>
                </tr>
               <tr>
                 
               </tr>
               <tr>
                 <td style="background:#e32124; padding:6px 0;">
                <p style="color:#fff; font-family:Verdana, Geneva, sans-serif; text-align:center; font-size:12px;"> ©' . date('Y') . ' All Rights Reserved</p>
                </td>
               </tr>
            </table>
            </div>';
			

            $this->email->from('Aalexjhones@gmail.com', 'Kochen Fresh');
            $this->email->to($data['email']);
            $this->email->set_mailtype('html');

            $this->email->subject('Kochen Fresh New Password');
            $this->email->message($mailbody1);
            $send = $this->email->send();
			/** check mail*/
				$response['response'] = 'true' ;
				$response['message']  = 'successfully password sent' ;
				echo json_encode($response);
		}

			else{
				$response['response'] = 'false' ;
				$response['message']  = 'something wrong,try after sometime' ;
				echo json_encode($response);
			}
		}

	public function itemlist_by_cat_id()
  	{
	 date_default_timezone_set('Asia/Kolkata');
	$category = $this->input->get('cat_id');
	$user_id = $this->input->get('user_id');
	
	$item_list = $this->db->select('*')->from('kf_item')->where('cat_id',$category)->where('status',1)->get()->result_array();
	$cat_name = $this->db->where('cat_id',$category)->where('status',1)->get('kf_category')->result_array();
	
	foreach($item_list as $k=>$val)
	{
		$is_wislist_item ='0';
		if($user_id !=''){
		 $wishlist_item_details = $this->db->where('user_id',$user_id)->where('item_id',$val['item_id'])->get('kf_wish_list')->result_array();
			if(!empty($wishlist_item_details))
			{
				$is_wislist_item ='1';
			}
		}
		$item_list[$k]['is_wishlist'] = $is_wislist_item;
		$item_list[$k]['img_name'] = base_url().'uploads/items/'.$val['img_name'];
		$item_price =  $this->db->select('concat(price.unit_value, "", unit.unit_name) as unit,price.*,unit.unit_name,item.item_name')->from('kf_item_price_unit price')->join('kf_item item','price.item_id=item.item_id','left')->join('kf_unit_master unit','unit.unit_id=price.unit_id')->where('price.item_id',$val['item_id'])->get()->result_array();
		$item_price_arr ='';
		
		if(!empty($item_price))
		{
			foreach($item_price as $ky=>$item_price_val)
		{
			$item_price_arr .= $item_price_val['unit'] .'-Rs:'. $item_price_val['price']." ";
			
		}
			 $item_list[$k]['item_price'] = $item_price_arr ;
			 
		}
		else{
			 $item_list[$k]['item_price'] = "No Data Found" ; 
		}
	     $total_cart_item = $this->db->select('count(id) as total_cart_item')->where('user_id',$user_id)->get('kf_add_to_cart')->result_array();
		 $item_list[$k]['total_cart_item'] = isset($total_cart_item[0]['total_cart_item'])?$total_cart_item[0]['total_cart_item']:0;
	}
	$response['cat_name']=isset($cat_name[0]['cat_name'])?$cat_name[0]['cat_name']:'N/A';
	             // echo"<pre>";print_r($item_list);
	if(!empty($item_list))
	{
		$response['response']='true';
		$response['message']=' ';
		$response['item_list']= $item_list ;
		echo json_encode($response);
		
	}
	else
	{
		$response['response']='False';
		$response['message']='No Data Found ';
		$response['item_list']= ' ' ;
		echo json_encode($response);
		 
	}
	
	
	}
	public function category_list()
  	{
	 	date_default_timezone_set('Asia/Kolkata');
	// $cat_list = $this->db->select('*')->from('kf_category')->where('parent_id',0)->where('status',1)->order_by("cat_id", 5)->order_by("cat_id","asc")->get()->result_array();
	// echo $this->db->last_query();

	 $sql = "SELECT * FROM kf_category WHERE `parent_id`= '0' AND `status` = '1' ORDER BY `cat_id`='5' DESC, cat_id ASC";

	 $cat_list = $this->db->query($sql)->result_array();

	
	foreach($cat_list as $k=>$val)
	{
			if($val['image']!='')
			{
				$cat_list[$k]['image'] = base_url().'uploads/category/'.$val['image'];
			}
			else{
				$cat_list[$k]['image'] = base_url().'images/no-image.jpeg';
			}
			
	}
	//echo"<pre>";print_r($cat_list);exit;
		if(!empty($cat_list))
		{
			$response['response']='true';
			$response['message']=' ';
			$response['category_list']= $cat_list ;
			echo json_encode($response);
			
		}
		else
		{
			$response['response']='False';
			$response['message']='No Data Found ';
			$response['category_list']= ' ' ;
			echo json_encode($response);
			 
		}
	
	
	}
	
	public function offer_images()
	{
		date_default_timezone_set('Asia/Kolkata');
		$offer_image = $this->db->where('status','1')->get('kf_offer')->result_array();
		
		foreach($offer_image as $k=>$val)
		{
			$offer_image[$k]['offer_image'] = base_url().'uploads/offer_banner/'.$val['offer_image'];
		}
		if(!empty($offer_image))
		{
			$response['response']='true';
			$response['message']=' ';
			$response['offer_details']= $offer_image ;
			echo json_encode($response);
			
		}
		else
		{
			$response['response']='False';
			$response['message']='No Data Found ';
			$response['offer_details']= ' ' ;
			echo json_encode($response);
			 
		}
	}
	public function get_item_price_by_id()
	{
		date_default_timezone_set('Asia/Kolkata');
		$item_id = $this->input->get('item_id');
		$user_id = $this->input->get('user_id');

		if($user_id =='null')
		{
			$user_id = '';
		}
		
		$item_details = $this->db->select('*')->from('kf_item')->where('item_id',$item_id)->where('status',1)->get()->result_array();
		$item_price =  $this->db->select('concat(price.unit_value, "", unit.unit_name) as unit,price.*,unit.unit_name,item.item_name')->from('kf_item_price_unit price')->join('kf_item item','price.item_id=item.item_id','left')->join('kf_unit_master unit','unit.unit_id=price.unit_id')->where('price.item_id',$item_id)->get()->result_array();
		//echo"<pre>";print_r($item_price);
		if(!empty($item_price))
		{

            $wishlist = $this->db->select('*')->from('kf_wish_list')->where('item_id', $item_id)->where('user_id', $user_id)->get()->result_array();
             

            
          
           
            if(!empty($wishlist))
            {
            	$response['wishlist_status']='1';
            }else
            {
            	$response['wishlist_status']='0';

            }

			$response['response']='true';
			$response['message']=' ';
			$response['item_name']=isset($item_details[0]['item_name'])?$item_details[0]['item_name']:'N/A';
			$response['item_image']=isset($item_details[0]['img_name'])&&$item_details[0]['img_name']!=''?base_url().'uploads/items/'.$item_details[0]['img_name']:'N/A';
			$response['item_price']= $item_price ;
			echo json_encode($response);
			
		}
		else
		{
			$response['wishlist_status']='0';
			$response['response']='False';
			$response['message']='No Data Found ';
			$response['item_price']= ' ' ;
			echo json_encode($response);
			 
		}
	}
	/**
    * web api check pin codes that are available and active
    * 
    * @param1       @email,@password,@ip addess
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function available_code()
	{
		date_default_timezone_set('Asia/Kolkata');
		$code = $this->input->get('pin_code');
		$result = $this->db->where('status',1)->where('pin_code',$code)->get('kf_cod_pin')->result_array();
		if(!empty($result))
		{
			$response['response']='true';
			$response['message']='available';
			
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='unavailable';
			
			echo json_encode($response);
		}
	}
	/**
    * web api for add to cart
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	

	public function add_to_cart()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id       = $this->input->get('user_id');
		$item_id       = $this->input->get('item_id');
		$unit_price_id = $this->input->get('unit_price_id');
		$quantity      = $this->input->get('quantity');
		$total_amount  = $this->input->get('total_price');

		
		$order_item_id                  = base64_decode($item_id);
		$unit_price_id                  = base64_decode($unit_price_id);
		
		$quantity                       = base64_decode($quantity);
		$total_amount                   = base64_decode($total_amount);

		$order_item_id                  = str_replace('[', "", $order_item_id);
		$order_item_id                  = str_replace(']', '', $order_item_id);	
		
		$quantity                       = str_replace('[', "", $quantity);
		$quantity                       = str_replace(']', '', $quantity);	
		
		$unit_price_id                  = str_replace('[', "", $unit_price_id);
		$unit_price_id                  = str_replace(']', '', $unit_price_id);	

		$total_amount                   = str_replace('[', "", $total_amount);
		$total_amount                   = str_replace(']', '', $total_amount);	

        $item_id_values_array           = explode(',', $order_item_id);
        $quantity_values_array          = explode(',', $quantity);
        $unit_price_id_values_array     = explode(',', $unit_price_id);
        $total_amount_values_array      = explode(',', $total_amount);

        $count                          =  count($item_id_values_array); 

       for ($i=0; $i <$count ; $i++) 
       { 
        
        $have_cart = $this->db->select('*')->where('unit_price_id', $unit_price_id_values_array[$i])->where('user_id', $user_id)->get('kf_add_to_cart')->result_array();

        $update_amount   = $have_cart[0]['total_price'];
        $update_quantity = $have_cart[0]['quantity'];
       
        if(!empty($have_cart))
        {

        $update_order_data['user_id']            =  $user_id;
        $update_order_data['item_id']            =  $item_id_values_array[$i];
        $update_order_data['unit_price_id']      =  $unit_price_id_values_array[$i];
        $update_order_data['quantity']           =  $update_quantity + $quantity_values_array[$i];
        $update_order_data['total_price']        =  $update_amount + $total_amount_values_array[$i];
        $update_order_data['cart_date']          =  date('Y-m-d H:i:s');
     
        $updated = $this->db->where('user_id',$user_id)->where('unit_price_id',$unit_price_id_values_array[$i])->update('kf_add_to_cart',$update_order_data);
        	
        }

        else
        {
        	
        $insert_order_data['user_id']            =  $user_id;
        $insert_order_data['item_id']            =  $item_id_values_array[$i];
        $insert_order_data['unit_price_id']      =  $unit_price_id_values_array[$i];
        $insert_order_data['quantity']           =  $quantity_values_array[$i];
        $insert_order_data['total_price']        =  $total_amount_values_array[$i];
        $insert_order_data['cart_date']          =  date('Y-m-d H:i:s');
     
        $this->db->insert('kf_add_to_cart',$insert_order_data);
        }
        
        }
	
		if($user_id!='' )
		{
			$response['response']='true';
			$response['message']='successfully added to cart';
			echo json_encode($response);
		}

		else{
			
			$response['response']='false';
			$response['message']='something worng,try after some time';
			echo json_encode($response);
		}
	}
	

	/**
    * web api for add to cart
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	

	public function cart_item_list()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id = $this->input->get('user_id');
		
		
		$result = $this->db->select('price.id as unit_price_id,concat(price.unit_value, "", unit.unit_name) as unit,price.price as unit_price,cart.*,cart.id as cart_id,item.item_name,item.img_name')->from('kf_add_to_cart cart')->join('kf_item item','cart.item_id=item.item_id','left')->join('kf_item_price_unit price','price.id=cart.unit_price_id','left')->join('kf_unit_master unit','unit.unit_id=price.unit_id','left')->where('cart.user_id',$user_id)->get()->result_array();
		
		$total_cart_price = 0;
		$total_cart_item = 0;
		if(!empty($result))
		{
			foreach($result as $k=>$val)
		{
			$total_cart_item = $total_cart_item + 1;
			$result[$k]['img_name'] = base_url().'uploads/items/'.$val['img_name'];
			$total_cart_price = $total_cart_price + $val['total_price'];
		}	//echo $this->db->last_query();
		//echo"<pre>";print_r($result);
		
			$response['response']='true';
			$response['message']='cart item list';
			$response['total_cart_price']=$total_cart_price;
			$response['total_cart_item']=$total_cart_item;
			$response['item_details']= $result;
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='no cart item found';
			echo json_encode($response);
		}
	}
	/**
    * web api for delete cart id
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/delete_cart_item
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function delete_cart_item()
	{
		date_default_timezone_set('Asia/Kolkata');
		$cart_id = $this->input->get('cart_id');
		if($this->db->where('id',$cart_id)->delete('kf_add_to_cart'))
		{
			$response['response']='true';
			$response['message']='cart item deleted';
			echo json_encode($response);
			
		}
		else{
			$response['response']='false';
			$response['message']='something wrong,try after some time';
			echo json_encode($response);
		}
	}
	
	/**
    * web api for add to wishlist
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function add_to_wishlist()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id = $this->input->get('user_id');
		$item_id = $this->input->get('item_id');
		
		
		$have_wish_list = $this->db->where('user_id',$user_id)->where('item_id',$item_id )->get('kf_wish_list')->result_array();
		if(empty($have_wish_list))
		{
			if($user_id!='')
			{
			$insert_data['user_id'] = $user_id;
			$insert_data['item_id'] = isset($item_id)&& $item_id!=''?$item_id:'';
			
			$this->db->insert('kf_wish_list',$insert_data);
			}
			$insert_id = $this->db->insert_id();
			if($insert_id!='')
			{

				$response['response']='true';
				$response['message']=' added to wish list';
				echo json_encode($response);
			}
			else{
				$response['response']='false';
				$response['message']='something worng,try after some time';
				echo json_encode($response);
			}
		}
		else{
			     $response['response']='false';
				$response['message']='Already added';
				echo json_encode($response);
		}
	}
	/**
    * web api for login check with user email and password also check ip address is blocked or active
    * 
    * @param1       @email,@password,@ip addess
    * @return       user id if matched / message of invalid credetial if not matched
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         
    * @since        22.11.2017
    * @deprecated   N/A
    */
	public function get_wish_list()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id = $this->input->get('user_id');

		

		$wishlist = $this->db->select('wish_list.id as wishlist_id,item.*')->from('kf_wish_list as wish_list')->join('kf_item as item', 'wish_list.item_id = item.item_id', 'LEFT')->where('wish_list.user_id', $user_id)->get()->result_array();
		 $total_item = '0';

		if(!empty($wishlist))
		{
			foreach($wishlist as $k=>$val)
			{
				$total_item = $total_item +1;
				$wishlist[$k]['img_name'] = base_url().'uploads/items/'.$val['img_name'];
			}
			$response_wish['response'] = 'True';
			$response_wish['total_item'] = "$total_item";
			$response_wish['message'] = '';
			$response_wish['wish_list'] = $wishlist;
		    echo json_encode($response_wish);
		}
		else
		{
			$response_wish['response'] = 'False';
			$response_wish['total_item'] = '0';
			$response_wish['message'] = 'No Data Found';
			$response_wish['wish_list'] = '';
			echo json_encode($response_wish);
		}
		
		
	}
	/**
    * web api for add to wishlist from cart
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function wishlist_from_cart()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id = $this->input->get('user_id');
		$cart_id = $this->input->get('cart_id');
		$item_details = $this->db->where('id',$cart_id)->get('kf_add_to_cart')->result_array();
		$item_id = isset($item_details[0]['item_id'])?$item_details[0]['item_id']:0;
		
		$have_wish_list = $this->db->where('user_id',$user_id)->where('item_id',$item_id )->get('kf_wish_list')->result_array();
		$this->db->where('id',$cart_id )->delete('kf_add_to_cart');
		if(empty($have_wish_list))
		{
			if($user_id!='')
			{
			$insert_data['user_id'] = $user_id;
			$insert_data['item_id'] = isset($item_id)&& $item_id!=''?$item_id:'';
			
			$this->db->insert('kf_wish_list',$insert_data);
			}
			$insert_id = $this->db->insert_id();
			if($insert_id!='')
			{
				
				
				
				$response['response']='true';
				$response['message']=' added to wish list';
				echo json_encode($response);
			}
			else{
				$response['response']='false';
				$response['message']='something worng,try after some time';
				echo json_encode($response);
			}
		}
		else{
			    $response['response']='false';
				$response['message']='Already added';
				echo json_encode($response);
		}
	}
	/**
    * web api remove from wishlist
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function remove_from_wishlist()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id = $this->input->get('user_id');
		$item_id = $this->input->get('item_id');
		if($user_id!='' && $item_id!='')
		{
			$this->db->where('item_id',$item_id)->where('user_id',$user_id)->delete('kf_wish_list');
			    $response['response']='true';
				$response['message']='removed';
				echo json_encode($response);
		}
		else{
			    $response['response']='false';
				$response['message']='something wrong,try after sometime';
				echo json_encode($response);
		}
	}
	/**
    * web api remove all item wishlist
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function clear_wishlist()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id = $this->input->get('user_id');
		
		if($user_id!='')
		{
			$this->db->where('user_id',$user_id)->delete('kf_wish_list');
			    $response['response']='true';
				$response['message']='removed';
				echo json_encode($response);
		}
		else{
			    $response['response']='false';
				$response['message']='something wrong,try after sometime';
				echo json_encode($response);
		}
	}
	/**
    * order details page before check out with cupon code checking
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function order_details()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id= $this->input->get('user_id');
		$item_price_id= $this->input->get('item_price_id');
		$iyem_id = $this->input->get('item_id');
		$quantity = $this->input->get('quantity');
		$cupon_id = $this->input->get('cupon_id'); 
		
		$user_details = $this->db->where('user_id',$user_id)->get('kf_user')->result_array();
		if(!empty($user_details))
		{
			$user_details = $user_details;
		}
		else{
			$user_details = "no data found";
		}
		$item_details = $this->db->select('*,concat(price.unit_value, "", unit.unit_name) as unit,price.price as unit_price,item.item_name')->from('kf_item_price_unit price')->join('kf_item item','item.item_id=price.item_id','left')->join('kf_unit_master unit','unit.unit_id=price.unit_id')->where('price.id',$item_price_id)->get()->result_array();
		
		
		
		$count =0;
		if(!empty($item_details)){
			foreach($item_details as $k=>$val)
			{
				$total_amount = round(($val['unit_price']*$quantity) ,2);
				$count = $count +1;
				$item_details[$k]['total_amount'] = "$total_amount";
				$item_details[$k]['img_name'] = base_url().'uploads/items/'.$val['img_name'];
				$item_details[$k]['quantity'] = "$quantity";
			}
		}
		else{
			$item_details = "no data found";
		}
		
		/** cupon section **/
		$coupon_details=$this->db->where('cupon_id',$cupon_id)->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->get('kf_cupon')->result_array();
		$have_user_order=$this->db->where('user_id',$user_id)->get('kf_order')->result_array();
		if(!empty($coupon_details)  && ((empty($have_user_order)&& $coupon_details[0]['user']=="New User")|| ($coupon_details[0]['user']=="All User")) &&$coupon_details[0]['purchase_price']<=$total_amount)
		{
			
			if($coupon_details[0]['discount_price_type'] == 'lumpsum')
			{
				$discount_amount =  $coupon_details[0]['discount_amount'];
				$total_price_amount = $total_amount - $coupon_details[0]['discount_amount'];
			}
			else
			{
				
				$total_amount_percentage = $total_amount * ($coupon_details[0]['discount_amount']/100);
				$discount_amount =  $total_amount_percentage;
			    $total_price_amount = $total_amount - $total_amount_percentage;

			}
			$response['cupon_discount']="$discount_amount";
			
		}
		else{
			
			$response['cupon_discount']="0.00";
		}
		/** cupon section **/
		 $response['cupon_id']="$cupon_id";
		 $response['response']='true';
		 $response['total_item']="$count";
		 $response['user_details']=$user_details;
		 $response['item_details']=$item_details;
		 echo json_encode($response);
		
	}
	/**
    * user details y user id
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function user_details()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id= $this->input->get('user_id');
		$user_details = $this->db->where('user_id',$user_id)->get('kf_user')->result_array();
		if(!empty($user_details))
		{
			$response['response']='true';
			$response['user_details']=$user_details;
		}
		else{
			$response['response']='false';
			$response['user_details']= "no data found";
		}
		echo json_encode($response);
	}
	/**
    * update user y user id
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function update_user()
	{ 
		date_default_timezone_set('Asia/Kolkata');
		$user_id       = $this->input->get('user_id');
		$name 	       = $this->input->get('name');
		$lastname      = $this->input->get('lastname');
		$phone         = $this->input->get('phone');
		$pin_code      = $this->input->get('pin_code');
		$address       = $this->input->get('address');
		$old_password  = $this->input->get('old_password');
		$password      = $this->input->get('password');		

		if($name!='')
		{
			$update_data['name'] = $name;
		}
		if($lastname!='')
		{
			$update_data['lastname'] = $lastname;
		}
		if($phone!='')
		{
			$update_data['phone'] = $phone; 
		}
		if($pin_code!='')
		{
			$update_data['pin_code'] = $pin_code;
		}
		if($address!='')
		{
			$update_data['address'] = $address;
		}
		if($password!='')
		{
			 $md5_convert_data 	      = md5(trim($password));
	         $salt_key 			      = get_encript_id(trim($password));
	         $password 			      = $md5_convert_data.$salt_key;
	         $update_data['password'] = $password;
		}

		if($old_password!='')
		{
			 $md5_convert_data 	      = md5(trim($old_password));
	         $salt_key 			      = get_encript_id(trim($old_password));
	         $old_password 			  = $md5_convert_data.$salt_key;

			 $match_password          = $this->db->select('*')->where('password', $old_password)->where('user_id', $user_id)->get('kf_user')->result_array();	         
	         if(empty($match_password))
	         {
	         $response['response']='false';
			 $response['msg']= "Invalid Old Password";
			 echo json_encode($response);
			 exit;
	         }


		}
	        

		
		if($this->db->where('user_id',$user_id)->update('kf_user',$update_data))
		{
			
			$response['response']='true';
			$response['msg']= "user information successfully updated";
		}
		else{
			$response['response']='false';
			$response['msg']= "try after some time";
		}
		echo json_encode($response);
	}
	/**
    * all cupon code list active and valid for current date
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function allusercoupon()
	{
		date_default_timezone_set('Asia/Kolkata');
		$allusercoupon=$this->db->select('*')->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->where('status',1)->get('kf_cupon')->result_array();
		
		
		if(!empty($allusercoupon))
		{
			$response_allusercoupon['reponse'] = 'True';
			$response_allusercoupon['message'] = '';
			$response_allusercoupon['order_details'] = $allusercoupon;
			echo json_encode($response_allusercoupon);
		}
		else
		{
			$response_allusercoupon['reponse'] = 'False';
			$response_allusercoupon['message'] = 'No Data Found';
			$response_allusercoupon['order_details'] = '';
			echo json_encode($response_allusercoupon);
		}

	}
	/**
    * applied cupon code
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	
	public function applied_cupon()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id 	  = $this->input->get('user_id');
		$cupon_id = $this->input->get('cupon_id'); 
		/** cupon section **/
		$coupon_details=$this->db->where('cupon_id',$cupon_id)->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->get('kf_cupon')->result_array();
		$have_user_order=$this->db->where('user_id',$user_id)->get('kf_order')->result_array();
		if(!empty($coupon_details) && (empty($have_user_order)&& $coupon_details[0]['user']=="New User")|| $coupon_details[0]['user']=="All User") 
		{
			if(!empty($have_user_order) && $have_user_order[0]['cupon_id']==$cupon_id)
			{
				$response_allusercoupon['reponse'] = 'false';
				$response_allusercoupon['message'] = 'not a valid cupon';
				echo json_encode($response_allusercoupon);
			}
			else{
				$response_allusercoupon['reponse'] = 'true';
				$response_allusercoupon['message'] = 'applied';
				echo json_encode($response_allusercoupon);
			}
			
		}
		else{
			
			$response_allusercoupon['reponse'] = 'false';
			$response_allusercoupon['message'] = 'not a valid cupon';
			echo json_encode($response_allusercoupon);
		}
	}
	/**
    * place single order by user id
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function place_single_order()
	{
		date_default_timezone_set('Asia/Kolkata');
		$this->db->trans_start();
		$user_id= $this->input->get('user_id');
		$order_id= $this->input->get('order_id');
		$item_price_id= $this->input->get('item_price_id');
		$item_id = $this->input->get('item_id');
		$quantity = $this->input->get('quantity');
		$cupon_id = $this->input->get('cupon_id');
		$discount_amount = $this->input->get('discount_amount');
		$total_amount = $this->input->get('total_amount');

		$randnum  = rand(1111111111,9999999999);
        
        $sql      = "select max(order_id) from kf_order";
 
        $order_id = $this->db->query($sql)->result_array();
		
		$have_order_id = $this->db->where('order_code',$order_id[0]['max(order_id)'])->get('kf_order')->result_array();
		if(empty($have_order_id)){
			/** order insert**/
			$genrate_id                         = 100 + $order_id[0]['max(order_id)'];
			$insert_data['order_code']          = 'KF'.$genrate_id;
			$insert_data['user_id']             = $user_id;
			$insert_data['cupon_id']            = $cupon_id;
			$insert_data['discount_amount']     = $discount_amount;
			$insert_data['total_amount']        = $total_amount;
			$insert_data['payment_status']      = 0;
			$insert_data['status']              = 0;
			$insert_data['order_date']          = date('Y-m-d H:i:s');
			$this->db->insert('kf_order',$insert_data);
			/**order  item insert**/
			$insert_id                          = $this->db->insert_id();
			$insert_item['order_id']            = $insert_id;
			$insert_item['item_id']             = $item_id;
			$insert_item['unit_price_id']       = $item_price_id;
			$insert_item['quantity']            = $quantity;
			$this->db->insert('kf_order_items',$insert_item);
			$insert_item_id = $this->db->insert_id();
		
		$this->db->trans_complete();
		if($insert_id !='' && $insert_item_id!='')
		{
			$genrate_id = 100 + $order_id[0]['max(order_id)'];
			$insert_data['KForder'] = 'KF'.$genrate_id;
			$response['reponse'] = 'true';
			$response['message'] = 'order placed';
			echo json_encode($response);
		}
		else{
			$response['reponse'] = 'false';
			$response['message'] = 'try after some time';
			echo json_encode($response);
		}
		}
		else{
			$response['reponse'] = 'false';
			$response['message'] = 'try after some time';
			echo json_encode($response);
		}
	}
	/**
    * user order details with cupon details and item
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function UserOrderDetails()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id = $this->input->get('user_id');
		$user_orders =  $this->db->select('order.*,cupon.cupon_id,cupon.cupon_name')->from('kf_order order')->join('kf_cupon cupon','order.cupon_id=cupon.cupon_id','left')->get()->result_array();
		
		
		foreach($user_orders as $k=>$val)
		{
			$user_orders[$k]['item_details'] = $this->db->select('*')->from('kf_order_items order_item')->join('kf_item item','order_item.item_id=item.item_id','left')->join('kf_item_price_unit as price', 'price.id = order_item.unit_price_id ', 'LEFT')->join('kf_unit_master as unit', 'price.unit_id = unit.unit_id', 'LEFT')->where('order_item.order_id', $val['order_id'])->get()->result_array();
		}
		
		if(!empty($user_orders))
		{
			$response_orderdetails['reponse'] = 'True';
			$response_orderdetails['message'] = '';
			$response_orderdetails['order_details'] = $user_orders;
			echo json_encode($response_orderdetails);
		}
		else
		{
			$response_orderdetails['reponse'] = 'False';
			$response_orderdetails['message'] = 'No Data Found';
			$response_orderdetails['order_details'] = '';
			echo json_encode($response_orderdetails);
		}

		
	}

		public function checkout_user()
	  {
	  	date_default_timezone_set('Asia/Kolkata');
		$data            = $this->input->get(); 
		$data            = $this->security->xss_clean($data);
		$user_id         = $this->input->get('user_id');
	 	
            if($data['shipping_fname']!='' && $data['shipping_lname']!='' && $data['shipping_phone']!='' && $data['shipping_code']!='')
			{
				$have_res = $this->db->select('*')->where('user_id', $user_id)->get('kf_shipping')->result_array();
				
				if(empty($have_res))
				{

				$insert_ship['user_id']              = $user_id;
				$insert_ship['shipping_status']      = $data['shipping_status'];
				$insert_ship['shipping_fname']       = $data['shipping_fname'];
				$insert_ship['shipping_lname']       = $data['shipping_lname'];
				$insert_ship['shipping_phone']       = $data['shipping_phone'];
				$insert_ship['shipping_code']        = $data['shipping_code'];
				$insert_ship['Shipping_add']         = $data['Shipping_add'];

				$this->db->insert('kf_shipping',$insert_ship);

		     	$response['reponse'] = 'True';
			    $response['user_id'] = $user_id;
			    echo json_encode($response);

				}else{

				$update_ship['user_id']              = $user_id;
				$update_ship['shipping_status']      = $data['shipping_status'];
				$update_ship['shipping_fname']       = $data['shipping_fname'];
				$update_ship['shipping_lname']       = $data['shipping_lname'];
				$update_ship['shipping_phone']       = $data['shipping_phone'];
				$update_ship['shipping_code']        = $data['shipping_code'];
				$update_ship['Shipping_add']         = $data['Shipping_add'];

				$this->db->where('user_id',$user_id)->update('kf_shipping',$update_ship);
				

		     	$response['reponse'] = 'True';
			    $response['user_id'] = $user_id;
			    echo json_encode($response);

				}
				
			}
			else
			{
				$response['reponse'] = 'False';
			    $response['user_id'] = $user_id;
			    echo json_encode($response);
			}

     }


	  public function checkout_userdetails()
	{
		date_default_timezone_set('Asia/Kolkata');
		$user_id      = $this->input->get('user_id');
		$user_details =  $this->db->select('*')->from('kf_user')->where('user_id', $user_id)->get()->result_array();
		$ship_details =  $this->db->select('*')->from('kf_shipping')->where('user_id', $user_id)->get()->result_array();
		
		$status       =  $ship_details[0]['shipping_status'];

		if($status=='')
		{
			$status   = '0';
		}
		
		if(!empty($user_details))
		{
			$response_orderdetails['reponse'] = 'True';
			$response_orderdetails['message'] = '';
			$response_orderdetails['status']  = $status;

			$response_orderdetails['user_details'] = $user_details;
			$response_orderdetails['ship_details'] = $ship_details;
			echo json_encode($response_orderdetails);
		}
		else
		{
			$response_orderdetails['reponse'] = 'False';
			$response_orderdetails['status']  = $status;
			$response_orderdetails['message'] = 'No Data Found';
			$response_orderdetails['user_details'] = '';
			$response_orderdetails['ship_details'] = '';
			echo json_encode($response_orderdetails);
		}

		
	}

		/**
    * user Submit Order list and item
    * 
    * @param1       order_code, user_id,cupon_id,discount_amount,total_amount,payment_status,status,order_date,order_item_id,quantity,unit_price_id
    * @return       cod is available  / not
    * @access       public
    * @author       D.K
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        26.12.2017
    * @deprecated   N/A
    **/
    
		public function orderlist()
	  {
	  	date_default_timezone_set('Asia/Kolkata');
		
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);

		$delivery = $this->db->select('status, note')->where('delivery_id', '1')->get('kf_delivery')->result_array();

	 	$status  = $delivery[0]['status'];
	 	$note    = $delivery[0]['note'];
	

        $deliver_massage = $this->db->select('massage')->get('kf_order_massage')->result_array(); 	

        $randnum  = rand(1111111111,9999999999);
        
        $sql      = "select max(order_id) from kf_order";

        $order_id = $this->db->query($sql)->result_array();

        $genrate_id = 100 + $order_id[0]['max(order_id)'];
		$insert_data['order_code']                  = 'KF'.$genrate_id;
		$insert_data['user_id']                     = $data['user_id'];
		$insert_data['cupon_id']                    = $data['cupon_id'];
		$insert_data['discount_amount']             = $data['discount_amount'];
		$insert_data['total_amount']                = $data['total_amount'];
		$insert_data['note']                        = $data['note'];
		$insert_data['shipping_first_name']         = $data['shipping_first_name'];
		$insert_data['shipping_last_name']          = $data['shipping_last_name'];
		$insert_data['shipping_phone_number']       = $data['shipping_phone_number'];
		$insert_data['shipping_zipcode']            = $data['shipping_zipcode'];
		$insert_data['shipping_address']            = $data['shipping_address'];
		$insert_data['payment_status']  = '0';
		$insert_data['status']          = '0';
		$insert_data['order_date']      = date("Y-m-d H:i:s");

		$order_date                     = date("D, j, M, Y");

		if($status != '0')
		 {
			$this->db->insert('kf_order',$insert_data);
			$insert_id = $this->db->insert_id();
		 }

		

		$order_item_id                  = $data['item_id'];
		$quantity                       = $data['quantity'];
		$unit_price_id                  = $data['unit_price_id'];
		
		$order_item_id                  = base64_decode($order_item_id);
		$quantity                       = base64_decode($quantity);
		$unit_price_id                  = base64_decode($unit_price_id);
			
		$order_item_id                  = str_replace('[', "", $order_item_id);
		$order_item_id                  = str_replace(']', '', $order_item_id);	
		
		$quantity                       = str_replace('[', "", $quantity);
		$quantity                       = str_replace(']', '', $quantity);	
		
		$unit_price_id                  = str_replace('[', "", $unit_price_id);
		$unit_price_id                  = str_replace(']', '', $unit_price_id);	

        $item_id_values_array           = explode(',', $order_item_id);
        $quantity_values_array          = explode(',', $quantity);
        $unit_price_id_values_array     = explode(',', $unit_price_id);
     

        $count =  count($item_id_values_array); 

        /**check mail**/

        $user_details = $this->db->select('name, email, phone, pin_code')->where('user_id', $data['user_id'])->get('kf_user')->result_array(); 

        $shipping_details = $this->db->select('cupon_id, shipping_first_name, shipping_last_name, shipping_address, shipping_zipcode, shipping_phone_number')->where('order_code', 'KF'.$genrate_id)->get('kf_order')->result_array();

        $delivery_note = $this->db->select('massage')->get('kf_order_massage')->result_array();

        $closeNote   =  $this->db->select('note')->get('kf_delivery')->result_array();

        $email_value =  $this->db->select('email')->get('kf_globalsetting')->result_array();

        $coupn_id    = $shipping_details[0]['cupon_id'];

        $discount    = $this->db->select('discount_amount')->where('cupon_id', $data['cupon_id'])->get('kf_cupon')->result_array();

        if(!empty($discount))
		{
			$discount_amount = $discount[0]['discount_amount'];
		}else
		{
			$discount_amount = '00.0';
		}

        $mail = $email_value[0]['email'];



		 $mailbody1 = '<div style="width:650px; margin:50px auto; background:#ddd; padding:20px 20px;" >
<div style=" background:#fff;">
    
      <div style="text-align:center; padding:15px 0 10px 15px; border-top:6px solid #D73232; border-bottom:6px solid #ddd;"><img src="http://' . $_SERVER['HTTP_HOST'] . '/admin/images/logotext.png" height="50" width="500"  alt="">
      </div>
    
    
    
      
      <div>';
       

        if($status!='0'){ $mailbody1.='<p style="padding:0 15px;color: #333;
    font-family: Verdana,Geneva,sans-serif;
    font-size: 13px;
    line-height: 22px;">'.$delivery_note[0]['massage'].'</p>'; } 

     if($status=='0'){ $mailbody1.='<br><span style="color:#F00;"><b>  '.$closeNote[0]['note'].' Please open the store for further orders.</b></span>'; } 
     
      $mailbody1.='</div>
   <div style="float:left; width:230px; height:133px; padding:20px; border-right:1px solid #ddd;">
   		<h4 style="margin-bottom:-8px; padding-bottom:0;">Name</h4>
        <p style="margin-bottom:0; padding-bottom:0; color:#626262;">'.$shipping_details[0]['shipping_first_name'].' '.$shipping_details[0]['shipping_last_name'].'</p>
   </div>
   <div style="float:left; width:280px; padding:20px; height:133px; margin-left:30px;">
   		<h4 style="margin-bottom:10px; padding-bottom:0;">Address</h4>
        <address style="color:#626262;">
        	'.$shipping_details[0]['shipping_address'].'
        </address>
   </div>
   <div style="float:left; width:140px; padding:20px; height:90px; border:1px solid #ddd; text-align:center; margin:16px;">
   		<h4 style="margin-bottom:-7px; padding-bottom:0;">Email</h4>
       	<p style="color:#626262;">'.$user_details[0]['email'].'</p>
   </div>
    <div style="float:left; width:140px; padding:20px; height:90px; border:1px solid #ddd; text-align:center; margin:15px;">
   		<h4 style="margin-bottom:-8px; padding-bottom:0;">Phone</h4>
        <p style="margin-bottom:0; padding-bottom:0; color:#626262;">'.$shipping_details[0]['shipping_phone_number'].'</p>
   </div>
   <div style="float:left; width:140px; padding:20px; height:90px; border:1px solid #ddd; text-align:center; margin:15px;">
   		<h4 style="margin-bottom:10px; padding-bottom:0;">Pin Code</h4>
      	<p style="color:#626262;">'.$shipping_details[0]['shipping_zipcode'].'</p>
   </div>
      <div style="clear:both;"></div>

   <table  bordercolor="#ddd" width="100%" style="padding:0 15px; border:none;">
    <tr>
      <td style="border-bottom:1px solid #ddd; border-top:1px solid #ddd;"><p style="padding:0 0px; float:left; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Order Id: <span style="color:#F00;">KF'.$genrate_id.'</span></p></td>
      <td style="border-bottom:1px solid #ddd; border-top:1px solid #ddd;"><p style="padding:0 15px; float:right; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Placed on: <strong>'.$order_date.'</strong></p></td>
    </tr>
    </table>
   
   <p style="text-align:center; font-size:20px; color:#072A60; text-transform:uppercase;">Order Details</p>
   <table border="1"  bordercolor="#ddd" width="100%" style="padding:0 15px; border:none; margin-bottom:16px;">
    <thead>
    <tr>
      <th style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Item</th>
      <th style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Item Name</th>
      <th style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Quantity</th>
      <th style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Amount</th>

    </tr>
    </thead>';

        
        $total_amount = 0;

       for ($i=0; $i <$count ; $i++) 
       { 
        
        $item_details  = $this->db->select('item_name, img_name')->where('item_id', $item_id_values_array[$i])->get('kf_item')->result_array();

        $price_details = $this->db->select('price, unit_id')->where('id', $unit_price_id_values_array[$i])->get('kf_item_price_unit')->result_array();

        $unit          = $this->db->select('unit_name')->where('unit_id', $unit_price_id_values_array[$i])->get('kf_unit_master')->result_array();

        $unit_type     = $unit[0]['unit_name'];
     
        $item_price    = $price_details[0]['price'] * $quantity_values_array[$i];
        
        $unit_name_type = $this->db->select('unit_name')->where('unit_id', $price_details[0]['unit_id'])->get('kf_unit_master')->result_array();
     
       	$mailbody1.='<tr>

       	 <td style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;"><img src="http://' . $_SERVER['HTTP_HOST'] . '/admin/uploads/items/'.$item_details[0]['img_name'].'" width="65" height="65"></td>
       	 <td style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">'.$item_details[0]['item_name'].'</td>
       	 <td style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">'.$quantity_values_array[$i].' '.$unit_name_type[0]['unit_name'].'</td>
       	 <td style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">'.$item_price.'</td>
      
       </tr>' ;

       $total_amount = $total_amount + $item_price ; 

   }

       $amount = $total_amount - $discount_amount;

        $mailbody1.='<tr><td style="border:1px solid #ddd; text-align:right; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;" colspan="3"><strong>Discount: </strong></td><td><span>'.$discount_amount.'</span></td></tr>';

       	$mailbody1.='<tr><td style="border:1px solid #ddd; text-align:right; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;" colspan="3"><strong>Total Amount: </strong></td><td><span>'.$amount.'</span></td></tr>';

    
    $mailbody1.='</table>
   
     <div style="background:#D73232; padding:2px 0;">
       <p style="color:#fff; font-family:Verdana, Geneva, sans-serif; text-align:center; font-size:12px;">Copyright © 2018 All Rights Reserved</p>
     </div>
   
</div>
</div>';


		
	

            $this->email->from('Aalexjhones@gmail.com', 'Kochen Fresh');
            $this->email->to($mail);
            $this->email->set_mailtype('html');

            $this->email->subject('Order Place From KochenFresh On -'.$order_date);
            $this->email->message($mailbody1);
            $send = $this->email->send();
		// 	/** check mail*/

       for ($i=0; $i <$count ; $i++) 
       { 
        
        $insert_order_data['order_id']           =  $insert_id;
        $insert_order_data['item_id']            =  $item_id_values_array[$i];
        $insert_order_data['unit_price_id']      =  $unit_price_id_values_array[$i];
        $insert_order_data['quantity']           =  $quantity_values_array[$i];
     
      if($status!= '0') {

      	$this->db->insert('kf_order_items',$insert_order_data);

      }  

        }

        if($status== '0')
        {

        $response['response'] = 'False' ;
		$response['message']  =  $note;

		echo json_encode($response);

        }else{

        $response['KForder']          = 'KF'.$randnum.$order_id[0]['max(order_id)'];
	    $response['response']         = 'true' ;
		$response['message']          = 'order submited successfully' ;
		$response['deliver_message']  = $deliver_massage[0]['massage'];

		echo json_encode($response);

        }


	   }

	  		/**
    * user Submit Order list and item
    * 
    * @param1       order_code, user_id,cupon_id,discount_amount,total_amount,payment_status,status,order_date,order_item_id,quantity,unit_price_id
    * @return       cod is available  / not
    * @access       public
    * @author       D.K
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        26.12.2017
    * @deprecated   N/A
    **/
    
		public function cart_orderlist()
	  {
	  	date_default_timezone_set('Asia/Kolkata');
		
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);

		$delivery = $this->db->select('status, note')->where('delivery_id', '1')->get('kf_delivery')->result_array();

	 	$status  = $delivery[0]['status'];
	 	$note    = $delivery[0]['note'];
	
        $deliver_massage = $this->db->select('massage')->get('kf_order_massage')->result_array();	

		$randnum  = rand(1111111111,9999999999);
        $sql      = "select max(order_id) from kf_order";
        $order_id = $this->db->query($sql)->result_array();

      	$genrate_id = 100 + $order_id[0]['max(order_id)'];
		$insert_data['order_code']                  = 'KF'.$genrate_id;
		$insert_data['user_id']                     = $data['user_id'];
		$insert_data['cupon_id']                    = $data['cupon_id'];
		$insert_data['discount_amount']             = $data['discount_amount'];
		$insert_data['total_amount']                = $data['total_amount'];
		$insert_data['note']                        = $data['note'];
		$insert_data['order_date']                  = date("Y-m-d H:i:s");
		$order_date                                 = date("D, j, M, Y");
		$insert_data['shipping_first_name']         = $data['shipping_first_name'];
		$insert_data['shipping_last_name']          = $data['shipping_last_name'];
		$insert_data['shipping_phone_number']       = $data['shipping_phone_number'];
		$insert_data['shipping_zipcode']            = $data['shipping_zipcode'];
		$insert_data['shipping_address']            = $data['shipping_address'];

		$this->db->insert('kf_order',$insert_data);

		$insert_id = $this->db->insert_id();

        // $order_item_id                  =  "WzEsMiwzLDRd";
        // $quantity                       =  "WzEsMiwzLDRd";
        // $unit_price_id                  =  "WzEsMiwzLDRd";

		$order_item_id                  = $data['item_id'];
		$quantity                       = $data['quantity'];
		$unit_price_id                  = $data['unit_price_id'];
		$price                          = $data['price'];
		
		$order_item_id                  = base64_decode($order_item_id);
		$quantity                       = base64_decode($quantity);
		$unit_price_id                  = base64_decode($unit_price_id);
		$price                          = base64_decode($price);
			
		$order_item_id                  = str_replace('[', "", $order_item_id);
		$order_item_id                  = str_replace(']', '', $order_item_id);	
		$quantity                       = str_replace('[', "", $quantity);
		$quantity                       = str_replace(']', '', $quantity);	
		$unit_price_id                  = str_replace('[', "", $unit_price_id);
		$unit_price_id                  = str_replace(']', '', $unit_price_id);	
		$price                          = str_replace('[', "", $price);
		$price                          = str_replace(']', '', $price);	

        $item_id_values_array           = explode(',', $order_item_id);
        $quantity_values_array          = explode(',', $quantity);
        $unit_price_id_values_array     = explode(',', $unit_price_id);
        $price_array                    = explode(',', $price);
     

        $count =  count($item_id_values_array); 

              /**check mail**/

        $user_details = $this->db->select('name, email, phone, pin_code')->where('user_id', $data['user_id'])->get('kf_user')->result_array(); 

        $shipping_details = $this->db->select('cupon_id, shipping_first_name, shipping_last_name, shipping_address, shipping_zipcode, shipping_phone_number')->where('order_code', 'KF'.$genrate_id)->get('kf_order')->result_array();

        $delivery_note = $this->db->select('massage')->get('kf_order_massage')->result_array();

        $closeNote   =  $this->db->select('note')->get('kf_delivery')->result_array();

        $email_value =  $this->db->select('email')->get('kf_globalsetting')->result_array();

        $mail = $email_value[0]['email'];

        $coupn_id    = $shipping_details[0]['cupon_id'];

       // $discount    = $this->db->select('discount_amount')->where('cupon_id', $data['cupon_id'])->get('kf_cupon')->result_array();

        if($data['discount_amount']!='')
		{
			$discount_amount = $data['discount_amount'];
		}else
		{
			$discount_amount = '00.0';
		}



		 $mailbody1 = '<div style="width:650px; margin:50px auto; background:#ddd; padding:20px 20px;" >
<div style=" background:#fff;">
    
      <div style="text-align:center; padding:15px 0 10px 15px; border-top:6px solid #D73232; border-bottom:6px solid #ddd;"><img src="http://' . $_SERVER['HTTP_HOST'] . '/admin/images/logotext.png" height="50" width="500"  alt="">
      </div>
    
    
    
      
      <div>';
       

        if($status!='0'){ $mailbody1.='<p style="padding:0 15px;color: #333;
    font-family: Verdana,Geneva,sans-serif;
    font-size: 13px;
    line-height: 22px;">'.$delivery_note[0]['massage'].'</p>'; } 

     if($status=='0'){ $mailbody1.='<br><span style="color:#F00;"><b>  '.$closeNote[0]['note'].' Please open the store for further orders.</b></span>'; } 
     
      $mailbody1.='</div>
   <div style="float:left; width:230px; height:133px; padding:20px; border-right:1px solid #ddd;">
   		<h4 style="margin-bottom:-8px; padding-bottom:0;">Name</h4>
        <p style="margin-bottom:0; padding-bottom:0; color:#626262;">'.$shipping_details[0]['shipping_first_name'].' '.$shipping_details[0]['shipping_last_name'].'</p>
   </div>
   <div style="float:left; width:280px; padding:20px; height:133px; margin-left:30px;">
   		<h4 style="margin-bottom:10px; padding-bottom:0;">Address</h4>
        <address style="color:#626262;">
        	'.$shipping_details[0]['shipping_address'].'
        </address>
   </div>
   <div style="float:left; width:140px; padding:20px; height:90px; border:1px solid #ddd; text-align:center; margin:16px;">
   		<h4 style="margin-bottom:-7px; padding-bottom:0;">Email</h4>
       	<p style="color:#626262;">'.$user_details[0]['email'].'</p>
   </div>
    <div style="float:left; width:140px; padding:20px; height:90px; border:1px solid #ddd; text-align:center; margin:15px;">
   		<h4 style="margin-bottom:-8px; padding-bottom:0;">Phone</h4>
        <p style="margin-bottom:0; padding-bottom:0; color:#626262;">'.$shipping_details[0]['shipping_phone_number'].'</p>
   </div>
   <div style="float:left; width:140px; padding:20px; height:90px; border:1px solid #ddd; text-align:center; margin:15px;">
   		<h4 style="margin-bottom:10px; padding-bottom:0;">Pin Code</h4>
      	<p style="color:#626262;">'.$shipping_details[0]['shipping_zipcode'].'</p>
   </div>
      <div style="clear:both;"></div>

   <table  bordercolor="#ddd" width="100%" style="padding:0 15px; border:none;">
    <tr>
      <td style="border-bottom:1px solid #ddd; border-top:1px solid #ddd;"><p style="padding:0 0px; float:left; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Order Id: <span style="color:#F00;">KF'.$genrate_id.'</span></p></td>
      <td style="border-bottom:1px solid #ddd; border-top:1px solid #ddd;"><p style="padding:0 15px; float:right; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Placed on: <strong>'.$order_date.'</strong></p></td> 
    </tr>
    </table>
   
   <p style="text-align:center; font-size:20px; color:#072A60; text-transform:uppercase;">Order Details</p>
   <table border="1"  bordercolor="#ddd" width="100%" style="padding:0 15px; border:none; margin-bottom:16px;">
    <thead>
    <tr>
      <th style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Item</th>
      <th style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Item Name</th>
      <th style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Quantity</th>
      <th style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">Amount (Rs)t</th>

    </tr>
    </thead>';

        
        $total_amount = 0;

       for ($i=0; $i <$count ; $i++) 
       { 
        
        $item_details  = $this->db->select('item_name, img_name')->where('item_id', $item_id_values_array[$i])->get('kf_item')->result_array();

        $price_details = $this->db->select('price, unit_id')->where('id', $unit_price_id_values_array[$i])->get('kf_item_price_unit')->result_array();

        $unit          = $this->db->select('unit_name')->where('unit_id', $unit_price_id_values_array[$i])->get('kf_unit_master')->result_array();

        $unit_type     = $unit[0]['unit_name'];
     
        $item_price    = $price_details[0]['price'] * $quantity_values_array[$i];

        $unit_name_type = $this->db->select('unit_name')->where('unit_id', $price_details[0]['unit_id'])->get('kf_unit_master')->result_array();
     

     
       	$mailbody1.='<tr>

       	 <td style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;"><img src="http://' . $_SERVER['HTTP_HOST'] . '/admin/uploads/items/'.$item_details[0]['img_name'].'" width="65" height="65"></td>
       	 <td style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">'.$item_details[0]['item_name'].'</td>
       	 <td style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">'.$quantity_values_array[$i].' '.$unit_name_type[0]['unit_name'].'</td>
       	 <td style="border:1px solid #ddd; text-align:left; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;">'.$item_price.'</td>
      
       </tr>' ;

       $total_amount = $total_amount + $item_price; 
   }

        $amount = $total_amount - $discount_amount;

        $mailbody1.='<tr><td style="border:1px solid #ddd; text-align:right; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;" colspan="3"><strong>Discount: </strong></td><td><span>'.$discount_amount.'</span></td></tr>';
       	
       	$mailbody1.='<tr><td style="border:1px solid #ddd; text-align:right; padding:5px 15px;  color:#626262; font-family: Verdana,Geneva,sans-serif; font-size:14px;" colspan="3"><strong>Total Amount: </strong></td><td><span>'.$amount.'</span></td></tr>';

    
    $mailbody1.='</table>
   
     <div style="background:#D73232; padding:2px 0;">
       <p style="color:#fff; font-family:Verdana, Geneva, sans-serif; text-align:center; font-size:12px;">Copyright © 2018 All Rights Reserved</p>
     </div>
   
</div>
</div>';
		
	

            $this->email->from('Aalexjhones@gmail.com', 'Kochen Fresh');
            $this->email->to($mail);
            $this->email->set_mailtype('html');

            $this->email->subject('Order Place From KochenFresh On -'.$order_date);
            $this->email->message($mailbody1);
            $send = $this->email->send();
		// 	/** check mail*/

       for ($i=0; $i <$count ; $i++) 
       { 

       	$item_details  = $this->db->select('item_name, img_name')->where('item_id', $item_id_values_array[$i])->get('kf_item')->result_array();

        $price_details = $this->db->select('price, unit_id')->where('id', $unit_price_id_values_array[$i])->get('kf_item_price_unit')->result_array();

        $unit          = $this->db->select('unit_name')->where('unit_id', $unit_price_id_values_array[$i])->get('kf_unit_master')->result_array();

        $unit_type     = $unit[0]['unit_name'];
     
        $item_price    = $price_details[0]['price'];

        $unit_name_type = $this->db->select('unit_name')->where('unit_id', $price_details[0]['unit_id'])->get('kf_unit_master')->result_array();
        
        $insert_order_data['order_id']           =  $insert_id;
        $insert_order_data['item_id']            =  $item_id_values_array[$i];
        $insert_order_data['unit_price_id']      =  $unit_price_id_values_array[$i];
        $insert_order_data['quantity']           =  $quantity_values_array[$i];
        $insert_order_data['price']              =  $price_array[$i];
        $insert_order_data['unit_type']          =  $quantity_values_array[$i].' '.$unit_name_type[0]['unit_name'];
        $insert_order_data['unit_price']         =  $item_price;
     
        $this->db->insert('kf_order_items',$insert_order_data);

        }

        $this->db->where('user_id', $insert_data['user_id'])->delete('kf_add_to_cart');

        // echo $this->db->last_query();
      

        if($status== '0')
        {

        $response['response'] = 'False' ;
		$response['message']  =  $note;

		echo json_encode($response);

        }else{
        $genrate_id                   = 100 + $order_id[0]['max(order_id)'];
        $response['KForder']          = 'KF'.$genrate_id;
	    $response['response']         = 'true' ;
		$response['message']          = 'order submited successfully' ;
		$response['deliver_message']  = $deliver_massage[0]['massage'];

		echo json_encode($response);

        }
	}

	  	
	  public function order_cupon()
	  {
	  	date_default_timezone_set('Asia/Kolkata');

	  	$user_id      = $this->input->get('user_id');
		$total_amount = $this->input->get('total_amount'); 
		$cupon_id     = $this->input->get('cupon_id'); 

	  		/** cupon section **/
		$coupon_details=$this->db->where('cupon_id',$cupon_id)->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->get('kf_cupon')->result_array();
       

		$have_user_order = $this->db->where('user_id',$user_id)->get('kf_order')->result_array();
		$have_cuppon     = $this->db->where('user_id',$user_id)->where('cupon_id', $cupon_id)->get('kf_order')->result_array();
		
	
		if(!empty($coupon_details)  && ((empty($have_user_order)&& $coupon_details[0]['user']=="New User")|| ($coupon_details[0]['user']=="All User")) &&$coupon_details[0]['purchase_price']<=$total_amount && empty($have_cuppon))
		{
			
			if($coupon_details[0]['discount_price_type'] == 'lumpsum')
			{
				$discount_amount    =  $coupon_details[0]['discount_amount'];
				$total_price_amount = $total_amount - $coupon_details[0]['discount_amount'];
			}
			else
			{
				
				$total_amount_percentage = $total_amount * ($coupon_details[0]['discount_amount']/100);
				$discount_amount         = $total_amount_percentage;
			    $total_price_amount      = $total_amount - $total_amount_percentage;

			}
			$response['cupon_discount']="$discount_amount";
			
		}
		else{
			
			$response['cupon_discount']="0.00";
		}
		/** cupon section **/
		 $response['cupon_id']="$cupon_id";
		 $response['response']='true';
		 echo json_encode($response);
	}

		/**
    * web api for add to history
    * 
    * @param1       date and time,Order Code,produt name,image,size,price,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	

	public function order_history()
	{
		date_default_timezone_set('Asia/Kolkata');

		
	    $user_id  = $this->input->get('user_id');

	    $order_id = $this->input->get('order_id');

		$sql      = "SELECT * FROM kf_order a inner join kf_order_items b on a.order_id = b.order_id  and a.user_id = '".$user_id."' and b.order_id ='".$order_id."'  ORDER BY a.order_date ASC";

		$result   = $this->db->query($sql)->result_array();

		$shipping = $this->db->select('*')->where('user_id', $user_id)->get('kf_shipping')->result_array();
        
  //       echo "<pre>";
		// print_r($shipping);
		// exit;

		$delivery_details = $this->db->select('delivery_date, cupon_id')->where('user_id', $user_id)->where('order_id', $order_id)->get('kf_order')->result_array();

        if($delivery_details[0]['cupon_id']!='0'){
        	$coupne_details  = $this->db->select('discount_amount')->where('cupon_id', $delivery_details[0]['cupon_id'])->get('kf_cupon')->result_array();

        }
		

		if(!empty($coupne_details))
		{
			$discount_amount = $coupne_details[0]['discount_amount'];
		}else
		{
			$discount_amount = '00.0';
		}
        
        if($delivery_details[0]['delivery_date']=='0000-00-00')
        {
        	$delivery_date = 'N/A';
        }else
        {
        	$delivery_date =  date("d-m-Y", strtotime($delivery_details[0]['delivery_date'])); ;
        }



		if(!empty($result))
		{
			foreach($result as $k=>$val)
		{
			 
			
			 $product_name = $this->db->select('item_name, img_name')->where('item_id', $result[$k]['item_id'])->get('kf_item')->result_array();

			 //$unit = $this->db->select('unit_id, unit_value, price')->where('id', $result[$k]['unit_price_id'])->get('kf_item_price_unit')->result_array();

			 $type = $this->db->select('unit_name')->where('unit_id', $unit[0]['unit_id'])->get('kf_unit_master')->result_array();

             $result[$k]['unit_price_value'] = $val['unit_type'];
             
			 $result[$k]['Product_name']     = $product_name[0]['item_name'];

			 $result[$k]['price']            = $val['price'];

			 $result[$k]['order_date']       = date("d-m-Y", strtotime($result[$k]['order_date']));

			 $result[$k]['order_time']       = date("h:i A", strtotime($result[$k]['order_date']));

			 $result[$k]['img_name']         = base_url().'uploads/items/'.$product_name[0]['img_name'];
			 
		}	
			$response['response']            ='true';
			$response['message']             ='Order History List.';
			$response['item_details']        = $result;
			$response['shipping_name']       = $shipping[0]['shipping_fname'].' '.$shipping[0]['shipping_lname'];
			$response['shipping_phone']      = $shipping[0]['shipping_phone'];
			$response['shipping_code']       = $shipping[0]['shipping_code'];
			$response['Shipping_add']        = $shipping[0]['Shipping_add'];
			$response['date_of_delivery']    = $delivery_date;
			$response['discount_amount']     = $discount_amount;
			

			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='no order found';
			echo json_encode($response);
		}
	}

			/**
    * web api for Offer Heading
    * 
    * @param1       Offer Heading
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	

	public function offer_heading()
	{
		date_default_timezone_set('Asia/Kolkata');
		
       $sql = "SELECT offer_heading FROM kf_offer LIMIT 0,1";

       $result = $this->db->query($sql)->result_array();

		if(!empty($result))
		{
		
			$response['response']='true';
			$response['offer_massage']= $result[0]['offer_heading'];
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='no order found';
			echo json_encode($response);
		}
	}

			/**
    * web api for add to User Notw
    * 
    * @param1       user_id
    * @return       note will be added / not
    * @access       public
    * @author       Deepak
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	

	public function user_note()
	{
		date_default_timezone_set('Asia/Kolkata');

	    $user_id = $this->input->get('user_id');
	    $data    = $this->input->get(); 

	    $insert_data['user_id']       = $user_id;
	    $insert_data['note']          = $data['note'];
	    $insert_data['status']        = '1';
		$insert_data['add_date']      = date("Y-m-d");

		$this->db->insert('kf_user_note',$insert_data);

	    if($user_id!='' )
		{
			$response['response']='true';
			$response['message']='successfully added note';
			echo json_encode($response);
		}

		else{
			
			$response['response']='false';
			$response['message']='something worng,try after some time';
			echo json_encode($response);
		}
		

	}


	/**
    * web api for add to Contact Massage
    * 
    * @param1       
    * @return       Contact note will be added
    * @access       public
    * @author       Deepak
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	

	public function contact_massage()
	{
		date_default_timezone_set('Asia/Kolkata');

	    $data    = $this->input->get(); 

	    $insert_data['name']           = $data['name'];
	    $insert_data['phone']          = $data['phone'];
	    $insert_data['email']          = $data['email'];
		$insert_data['address']        = $data['address'];
		$insert_data['purpose']        = $data['purpose'];
		$insert_data['add_date']       = date("Y-m-d H:i:s");
		$insert_data['status']         = '1';

		$this->db->insert('kf_contact_msg',$insert_data);

		$response['response']='true';
		$response['message']='successfully added purpose';
		echo json_encode($response);

	}

			/**
    * web api for history list
    * 
    * @param1       date and time,Order Code,produt name,image,size,price,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	

	public function history()
	{
		date_default_timezone_set('Asia/Kolkata');

		
	    $user_id = $this->input->get('user_id');
		
		$sql     = "SELECT * FROM kf_order where user_id = '".$user_id."' ORDER BY order_id DESC";

		$result = $this->db->query($sql)->result_array();

		if(!empty($result))
		{

		  	$response['response']='true';
			$response['message']='Order History List.';
			
			$response['history_details']= $result;
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='no order found';
			echo json_encode($response);
		}
	}

	/**
    * web api for min amount
    * 
    * 
    * @return       min price
    * @access       public
    * @author       D.K
    * @copyright    N/A
    * @link         WebServices/min_price
    * @since        24/01/18
    * @deprecated   N/A
    */
	

	public function min_price()
	{
		date_default_timezone_set('Asia/Kolkata');

		$result  = $this->db->select('min_price')->get('kf_min_price')->result_array();

		if(!empty($result))
		{

		  	$response['response']='true';
			$response['min_price']= $result;
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='no record found';
			echo json_encode($response);
		}
	}

	/**
    * web api for min amount
    * 
    * 
    * @return       min price
    * @access       public
    * @author       D.K
    * @copyright    N/A
    * @link         WebServices/FAQ
    * @since        24/01/18
    * @deprecated   N/A
    */
	

	public function Faq()
	{
		date_default_timezone_set('Asia/Kolkata');

		$result  = $this->db->select('note')->get('kf_faq')->result_array();
               
		if(!empty($result))
		{
			      $note = $result['0']['note'];               
                  $info = html_entity_decode($note); 
                  $info = str_replace('\r\n' , '', $info);
                  $info = str_replace('\n' , '', $info);
                  $info = str_replace('\r' , '', $info);
                  $res  = stripslashes($info);

		  	$response['response']='true';
			$response['faq_details']= $res;
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='no record found';
			echo json_encode($response);
		}
	}

}
