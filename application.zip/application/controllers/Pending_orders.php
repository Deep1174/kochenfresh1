<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'/third_party/mpdf/mpdf.php';
class Pending_orders extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
        $this->load->model('OrderPendingModel');
        $this->load->library('excel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         EmployeePayroll/Company
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{
		if(check_login())
		{
			$param = $this->input->get();
			
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
            if(isset($param['shipping_code']))
            {
                $shipping_code  = $param['shipping_code'];
            }
            else
            {
                $shipping_code = '';
            }
            if(isset($param['to_date']))
            {
                $to_date  = $param['to_date'];
            }
            else
            {
                $to_date = '';
            }
            if(isset($param['from_date']))
            {
                $from_date  = $param['from_date'];
            }
            else
            {
                $from_date = '';
            }
            $config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'Pending_orders?shipping_code='.$shipping_code.'&from_date='.$from_date.'&to_date='.$to_date;
            $config["total_rows"] = $this->OrderPendingModel->record_count($param);
            $config["per_page"] = 5;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['order_list'] = $this->OrderPendingModel->all_data_list($config["per_page"],$page,$param);

            $data['param'] = $param;
            $data['page'] = $page;

            /** listing section **/		
			//$data['order_list']= $this->db->where('status',1)->get('kf_category')->result_array();
			//echo"<pre>";print_r($data['order_list']);		exit;	
            $data['content']="Pending_orders/order_list";
            $this->load->view('layout_home',$data);
        }
    }


    public function print_order_list()
    {
      if(check_login())
      {
		//pdf settings
          $pdf = new mPDF('utf-8', array(290,295));
          $pdf->AddPage(P, // L - landscape, P - portrait 
            'A5', '12', '', '',
            25, // margin_left
            25, // margin right
            5, // margin top
            5, // margin bottom
            5, // margin header
            5); // margin footer
	//pdf settings
        $data = $this->input->get('search_data');
        $param = json_decode($data);
		//echo"<pre>";print_r($param);
        $date= date('Y-m-d');
        $where=" ";
        $date_range = " (";
        if(isset($param->from_date) && $param->from_date!='')
        {

           $where.=" and DATE(orders.order_date) >='". date('Y-m-d',strtotime($param->from_date))."'";
           $from_date = $param->from_date;
           $date_range .= $from_date . "- ";
        }
       if(isset($param->to_date) && $param->to_date!='')
       {

           $where.=" and DATE(orders.order_date) <='". date('Y-m-d',strtotime($param->to_date))."'";
           $to_date = $param->to_date;
           $date_range .= $to_date;
       }
       else
       {
           $date_range .= date('d-m-Y');
       }
       $date_range .= " ) ";
       /** search section**/
       if(!isset($param->from_date) && !isset($param->to_date) or( $param->from_date=='' && $param->to_date==''))
       {
            $where.=" and DATE(orders.order_date) = '$date'";
       }

    if(isset($param->shipping_code) && $param->shipping_code!='')
    {

        $where .= " AND ship.shipping_code like '%".$param->shipping_code."%' ";
    }

    $sql="SELECT * FROM  kf_order orders inner join kf_user user on user.user_id=orders.user_id inner JOIN kf_shipping ship ON ship.user_id = user.user_id  AND orders.status ='0'  WHERE 1    $where  ORDER BY  orders.order_id DESC" ;   

    $recordSet = $this->db->query($sql);

    $result = $recordSet->result_array();
		//echo"<pre>";print_r($result);
    $html='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Order List</title>

    <style type="text/css">
    body { margin:0; padding:0; font-family:Verdana, Geneva, sans-serif; font-size:14px;}
    table td,  table  { border-collapse:collapse;}
    table td { padding:5px; border:1px solid #000; padding:8px;}

    @media print{ body { font-family:Verdana, Geneva, sans-serif; font-size:14px;}  table td { border:1px solid #000; border-collapse:collapse;} table { border-collapse:collapse; padding:8px;}}
    </style>
    </head>

    <body>
    <div style="width:960px; margin:0 auto 15px auto;">
    <div style="padding:15px 0; text-align:right;"></div>
    <p style="text-align:center;" ><img src="'.base_url().'images/log02.png" width="200" height="50"></p>

    <P style="text-align:center; ">Order List For Delivery Boy'.$date_range.' </P>

    <table class="table table-bordered table-striped "  width="100%"   >
    <tr>
    <td><strong>Order ID</strong></td>
    <td><strong>Customer Name</strong></td>
    <td><strong>Email / Phone</strong></td>
    <td><strong>Shipping Name</strong></td>
    <td><strong>Shipping Phone</strong></td>
    <td><strong>Shipping Address</strong></td>
    <td><strong>Shipping Code</strong></td>
    <td><strong>Total Amount</strong></td>
    <td><strong>Payment Status</strong></td>
    <td><strong>Order Placed</strong></td>
     <td><strong>Signature</strong></td>

    </tr>';
    foreach($result as $k=>$val){


     if($val['status'] == 0)
     {
        $status ="pending";
    }	

    elseif($val['status'] == 1){
       $status ="Out For Delevery";
   }
   elseif($val['status'] == 2){
       $status ="canceled";
   }
   elseif($val['status'] == 3){
       $status ="Delivered";
   }
   elseif($val['status'] == 4){
       $status ="Return";
   }		

   if($val['payment_status'] == 1)
   {
      $payment_status = "Paid";
  }
  else{
      $payment_status = "Pending";
  }


  $item_details = get_total_item_count_price($val['order_id']);
  $total_amount = isset($item_details['total_amount'])?$item_details['total_amount']:'0';
  $total_item = isset($item_details['total_item'])?$item_details['total_item']:'0';
  $order_details = $this->db->select('*')->where('order_id',$val['order_id'])->get('kf_order_items')->result_array();
  if($val['note']==''){
    $val['note'] = 'N/A';
  }else{
    $val['note'];
  }
  $html.='<tr>
  <td rowspan="2">'.$val['order_code'].'</td>
  <td>'.$val['shipping_fname'] ." ". $val['shipping_lname'].'</td>
  <td>'.$val['email'].'<br>'.$val['phone'].'</td>
  <td>'.$val['shipping_first_name'] ." ". $val['shipping_last_name'].'</td>
  <td>'.$val['shipping_phone_number'].'</td>
  <td>'.$val['shipping_address'].'</td>
  <td>'.$val['shipping_zipcode'].'</td>
  <td>'.number_format($total_amount,2).'</td>
  <td>'.$payment_status.'</td>
  <td>'.date('d-m-Y h:i A', strtotime($val['order_date'])).'</td>
  <td ></td>
  </tr>
  <tr>
    <td colspan="10">Note : '.$val['note'].'</td>
   
    
  </tr>

  ';

}



$html.='</table></div>
</body>
</html>
';
//echo $html;exit;
$pdfname = "sales-voucher-print-copy";
							 //echo $html;exit;
$pdf->WriteHTML($html);
$pdfFilePath = "pendinglist".".pdf";
$pdf->Output($pdfFilePath,'I');
}
}



}
