<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GlobalSetting extends CI_Controller {

	function __construct() {
        error_reporting(0);
        parent::__construct();
        $this->load->model('CommonModel');
       
    }
    
    public function index($page=0)
	{   
        if(check_login())
        {
            $data['details'] = $this->db->select('*')->where('setting_id',1)->get('kf_globalsetting')->result_array();

            $data['content']  ="GlobalSetting/add";
        
            $this->load->view('layout_home',$data);
        }
	}

    function save_data()
    {
        if(check_login())
        {
            $data = $this->input->post();
            $data = $this->security->xss_clean($data);
           
         
            $update['phone']            = $data['phone'];
            $update['email']            = $data['email'];
            $update['add_date']         = date('y-m-d h:i:s');

            $this->CommonModel->edit_data('setting_id','1','kf_globalsetting',$update);

            $this->session->set_flashdata('success','Setting has been updated successfully');
            redirect(base_url('GlobalSetting'));
        }

    }


}
?>
