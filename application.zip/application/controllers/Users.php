<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	function __construct() {
		error_reporting(0);
    parent::__construct();
		$this->load->model('UsersModel');
    }

	

	/**
    * check  Users field value exsist(use in ajax call)
    * 
    * @param1       
    * @return       jason data
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         UsersPayroll/Users/save
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function check_mail()
	{
		if(check_login())
		{
		$data = $this->input->post();
		
		$have_data = $this->db->where($data['field'],$data['email'])->get('ep_Users')->result_array();
		if(empty($have_data))
		{
			echo json_encode("no data");
		}
		else
		{
			echo json_encode($have_data);
		}
		}
	}

	/**
    * load UsersList page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         UsersPayroll/UsersList
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{

		if(check_login())
		{
			
            /**listing section**/
			$param = $this->input->get();
			//echo"<pre>";print_r($param);exit;
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			if(isset($param['name'])&&$param['name']!='')
            {
                $name=$param['name'];
            }
			else{
				 $name='';
			}
      if(isset($param['lastname'])&&$param['lastname']!='')
            {
                $lastname=$param['lastname'];
            }
      else{
         $lastname='';
      }
            if(isset($param['email']))
            {
                $email  = $param['email'];
            }
            else
            {
                $email = '';
            }
			if(isset($param['status']))
            {
                $status = $param['status'];
            }
            else
            {
                $status = '';
            }
            
			
			      $config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'Users?name='.$name.'&lastname='.$lastname.'&email='.$email.'&status='.$status;
            $config["total_rows"] = $this->UsersModel->record_count($param);
            $config["per_page"] = 25;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['all_Users'] = $this->UsersModel->all_data_list($config["per_page"],$page,$param);

            $data['param'] = $param;
            $data['page'] = $page;
            //echo"<pre>";print_r($data);			
			/** listing section **/	
			
			$data['content']="user/Users_list";
			$this->load->view('layout_home',$data);
		}
	}

	public function delete($id)
	{
		if(check_login())
		{
	  $user = $this->db->select('*')->where('user_id',$id)->get('kf_user')->result_array();
    $ip = $user[0]['ip_address'];   
    
	  $status = $this->input->get('status');
		if($status == 0)
		{
			$delete_status['status'] = 1;
			$update_ip_status['status'] = '1';
			
		}
		else{
			$update_ip_status['status'] = '0';
			$delete_status['status'] = 0;
		}


		$this->db->where('user_id',$id)->update('kf_user',$delete_status);
        $this->db->where('ip_address',$ip)->update('kf_ip_address',$update_ip_status); 


		$this->session->set_flashdata('success', 'Users  deleted successfully');
		redirect(base_url('Users'));
		}
	}
	public function edit($id)
	{
		if(check_login())
		{
		$data['emp_details'] = $this->db->where('emp_id',$id)->get('ep_Users')->result_array();
		//echo"<pre>";print_r($data['emp_details']);exit;
		$data['content']="edit_Users";
		$this->load->view('layout_home',$data);
		}
	}


	 /**
    * load view pop up 
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C
    * @copyright    N/A
    * @link         
    * @since        22.10.2017
    * @deprecated   N/A
    */
   public function details_by_id()
  {
    check_login();
    $user_id= $this->input->get('user_id');
    $Users = $this->db->select('*')->where('user_id',$user_id)->get('kf_user')->result_array();
    

    $html='
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                      <h4 class="modal-title view-name">'.$Users[0]['name'].' '.$Users[0]['lastname'].' </h4>
                                                    </div>';
    
                     
            foreach($Users as $val){
                   
                    $html.='
                                                    <div class="modal-body">
                                              <div class="col-md-12"><h2 class="form-head view-information"> Personal Information</h2> 
                                                </div>      
                                                 <div class="view-details">       
                                                  <div class="col-md-12">

                                                  <div class="col-md-6">
                                                                    <div class="row mgbt-xs-0">
                                                                        <label class="col-md-5 col-xs-5 control-label name-label">Email:</label>
                                                                        <div class="col-md-7 col-xs-7">'.$Users[0]['email'].'</div>
                                                                    </div>
                                                                 </div>
                                                  
                                                  
                                                  <div class="col-md-6">
                                                                    <div class="row mgbt-xs-0">
                                                                        <label class="col-md-5 col-xs-5 control-label name-label">Phone :</label>
                                                                        <div class="col-md-7 col-xs-7">'.$Users[0]['phone'].'</div>
                                                                    </div>
                                                                 </div>
														  <div class="col-md-6">
															<div class="row mgbt-xs-0">
																<label class="col-md-5 col-xs-6 control-label name-label">Pin Code :</label>
																<div class="col-md-7 col-xs-7">'.$Users[0]['pin_code'].'</div>
															</div>
														 </div>
                                                       <div class="col-md-6">
                                                                    <div class="row mgbt-xs-0">
                                                                        <label class="col-md-5 col-xs-6 control-label name-label">Addess :</label>
                                                                        <div class="col-md-7 col-xs-7">'.$Users[0]['address'].'</div>
                                                                    </div>
                                                                 </div>            
                                                                 
                                                  <div class="col-md-6">
                                                                    <div class="row mgbt-xs-0">
                                                                     
                                                                        
                                                                 </div>
                                                                 </div>
                                                   </div>
                                                   <div class="clearfix"></div>
                                                   <div class="modal-body">
                                              <div class="clearfix"></div>
                                                    <div class="modal-footer">
                                                      <button type="button" class="btn btn-default yellow yellow-btn" data-dismiss="modal">Close</button>
                                                    </div>
                                                  
                                              
     <!---////////////// mod of payment pop up ////////---> 
     
';
    }                  
          
         
         echo $html;
  }
   public function get_dept_desig_by_comp_id()
  {
	  if(check_login())
		{
	  $data = $this->input->post();
	  $result['dept'] = $this->db->where('status',1)->where('comp_id',$data['comp_id'])->get('ep_department')->result_array();
	  $result['desig'] = $this->db->where('status',1)->where('comp_id',$data['comp_id'])->get('ep_designation')->result_array();
	  echo json_encode($result);
		}
  }
}
