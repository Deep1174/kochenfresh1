<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FAQ extends CI_Controller {

	function __construct() {
        error_reporting(0);
        parent::__construct();
        $this->load->model('CommonModel');
       
    }
    
    public function index($page=0)
	{   
        if(check_login())
        {

            $data=array();

                $fckeditorConfig = array(
                'instanceName' => 'content',
                'BasePath' => base_url('fckeditor/'),
                'ToolbarSet' => 'Default',
                'Width' => '805',
                'Height' => '300',
                'Value' => ''
            );


            $this->load->library('fckeditor', $fckeditorConfig);

            $data['result'] = $this->db->select('*')->where('id',1)->get('kf_faq')->result_array();

            $data['content']  ="FAQ/add";
        
            $this->load->view('layout_home',$data);
        }
	}

    function save_data()
    {
        if(check_login())
        {
            $data = $this->input->post();
            $data = $this->security->xss_clean($data);
           
         
            $update['note']                 = $data['content'];
            $update['add_date']             = date('Y-m-d');

            $this->CommonModel->edit_data('id','1','kf_faq',$update);

           // echo  $this->db->last_query();
           //  exit;

            $this->session->set_flashdata('success','FAQ updated successfully');
            redirect(base_url('FAQ'));
        }

    }


}
?>
