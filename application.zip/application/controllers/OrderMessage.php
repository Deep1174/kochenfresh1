<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class OrderMessage extends CI_Controller {

	function __construct() {
        error_reporting(0);
        parent::__construct();
        $this->load->model('CommonModel');
       
    }
    
    public function index($page=0)
	{   
        if(check_login())
        {
            $data['details'] = $this->db->select('*')->where('message_id',1)->get('kf_order_message')->result_array();

            $data['content']  ="Order_message/add";
        
            $this->load->view('layout_home',$data);
        }
	}

    function save_data()
    {
        if(check_login())
        {
            $data = $this->input->post();
            $data = $this->security->xss_clean($data);
           
         
            $update['massage']              = $data['message'];
            $update['add_date']             = date('Y-m-d');

            $this->CommonModel->edit_data('message_id','1','kf_order_message',$update);

            $this->session->set_flashdata('success','Message has been updated successfully');
            redirect(base_url('OrderMessage'));
        }

    }


}
?>
