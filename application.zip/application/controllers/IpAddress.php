<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class IpAddress extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
        $this->load->model('IpAddressModel');
    }

    /**
	* load UsersList page
	* 
	* @param1       
	* @return       view page
	* @access       public
	* @author       M.K.Sah
	* @copyright    N/A
	* @link         UsersPayroll/UsersList
	* @since        20.11.2016
	* @deprecated   N/A
	**/

    public function index($page=0) {
    	if(check_login())
		{
			$searchStatus = $this->input->GET('search','');
			$statusSearch = $this->input->GET('status','');
			//print_r($searchStatus);
			if(isset($searchStatus)?$searchStatus:'');
			if(isset($statusSearch)?$statusSearch:'');

			$config['use_page_numbers'] = TRUE;
			$config["base_url"] 		= base_url().'IpAddress/index';
			$config["total_rows"] 		= $this->IpAddressModel->record_count();
			$config["per_page"] 		= 25;
			$config['next_link'] 		= 'Next';
			$config['prev_link'] 		= 'Previous';

			$this->pagination->initialize($config);
			if($page!=0) {
				$page = ($page*$config["per_page"])-$config["per_page"];
			}

			$data['link']	=  $this->pagination->create_links();
			$data['result'] = $this->IpAddressModel->all_data_list($config["per_page"],$page,$searchStatus,$statusSearch);
			//echo"<pre>";print_r($data['result']);exit();
			$data['page']	= $page;
	    	$data['content']="IpAddress/index";
			$this->load->view('layout_home',$data);
		}
    }

	/**
	* load UsersList page
	* 
	* @param1       
	* @return       view page
	* @access       public
	* @author       M.K.Sah
	* @copyright    N/A
	* @link         UsersPayroll/UsersList
	* @since        20.11.2016
	* @deprecated   N/A
	**/

    public function Status($id,$statusVal){
		if(check_login()) {
	    	/*echo $id;echo "<br/>";
	    	echo $statusVal;exit();*/
			if($statusVal == 1)
				{
					$changeStatus['status'] = 0;
					$msg = "This IP address has been inactivated successfully.";
				} else {
					$changeStatus['status'] = 1;
					$msg = "This IP address has been activated successfully.";
				}
			$this->db->where('id',$id)->update('kf_ip_address',$changeStatus);
			$this->session->set_flashdata('success', $msg);
			redirect(base_url('IpAddress'));
		}
	}
}
