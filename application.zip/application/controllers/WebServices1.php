<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class WebServices1 extends CI_Controller {

	function __construct() {
	//	error_reporting(0);
        parent::__construct();
		$this->load->model('UsersModel');
    }

	 /**
    * web api for login check with user email and password also check ip address is blocked or active
    * 
    * @param1       @email,@password,@ip addess
    * @return       user id if matched / message of invalid credetial if not matched
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         
    * @since        22.11.2017
    * @deprecated   N/A
    */
  public function check_login_details()
  {
	 
	 $email = $this->input->get('email');
	 $password = $this->input->get('password');
     $ip_address = $this->input->get('ip_address');
	 
	 $md5_convert_data 	= md5(trim($password));
	 $salt_key 			= get_encript_id(trim($password));
	 $password 			= $md5_convert_data.$salt_key;
	 //** **//
	 $user_details = $this->db->where('email',$email)->where('password',$password)->where('status',1)->get('kf_user')->result_array();
	 
	 $is_active_ip = $this->db->where('status',1)->where('ip_Address',$ip_address)->get('kf_ip_address')->result_array();
	 if(!empty($user_details) && !empty($is_active_ip))
	 {
		 $data['result']['user_id'] = $user_details[0]['user_id'];
		 echo json_encode($data);
	 }
	 else
	 {
		 $data['result'] = "invalid credential";
		 echo json_encode($data);
	 }
  }
  
	/**
    * web api for login check with user email and password also check ip address is blocked or active
    * 
    * @param1       @email,@password,@ip addess
    * @return       user id if matched / message of invalid credetial if not matched
    * @access       public
    * @author       S.C
    * @copyright    N/A
    * @link         
    * @since        24.11.2017
    * @deprecated   N/A
    */

	public function get_wish_list()
	{
		$user_id = $this->input->get('user_id');

		

		$wishlist = $this->db->select('t1.quantity,t2.item_name,t3.price, t4.name,t5.unit_name')->from('kf_wish_list as t1')->where('t1.id', $user_id)->join('kf_item as t2', 't1.item_id = t2.item_id', 'LEFT')->join('kf_item_price_unit as t3', 't1.item_id = t3.item_id', 'LEFT')->join('kf_user as t4', 't1.user_id = t4.user_id', 'LEFT')->join('kf_unit_master as t5', 't3.unit_id  = t5.unit_id', 'LEFT')->get()->result_array();



		if(!empty($wishlist))
		{
			$response_wish['reponse'] = 'True';
			$response_wish['message'] = '';
			$response_wish['wish_list'] = $wishlist;
		    echo json_encode($response_wish);
		}
		else
		{
			$response_wish['response'] = 'False';
			$response_wish['message'] = 'No Data Found';
			$response_wish['wish_list'] = '';
			echo json_encode($response_wish);
		}
		
		
	}





	public function itemlist_by_cat_id()
  	{
	 
	$category = $this->input->get('cat_id');
	

	$item_list = $this->db->select('*')->from('kf_item')->where('cat_id',$category)->where('status',1)->get()->result_array();
	

	if(!empty($item_list))
	{
		$response['response']=true;
		$response['message']=' ';
		$response['item_list']= $item_list ;
		echo json_encode($response);
		
	}
	else
	{
		$response['response']=False;
		$response['message']='No Data Found ';
		$response['item_list']= ' ' ;
		echo json_encode($response);
		 
	}
	
	
	 }


	 /**
    * web api for login check with user email and password also check ip address is blocked or active
    * 
    * @param1       @email,@password,@ip addess
    * @return       user id if matched / message of invalid credetial if not matched
    * @access       public
    * @author       S.C
    * @copyright    N/A
    * @link         
    * @since        24.11.2017
    * @deprecated   N/A
    */
	
	
	public function OrderList()
	{
		
		$user_id = $this->input->get('user_id');
		
		$OrderList= $this->db->select('t1.*,t2.name')->from('kf_order as t1')->where('t1.user_id ', $user_id)->join('kf_user as t2', 't1.user_id = t2.user_id', 'LEFT')->where('t2.status',1)->get()->result_array();
		


		if(!empty($OrderList))
		{
			$response_order['reponse'] = 'True';
			$response_order['message'] = '';
			$response_order['order_list'] = $OrderList;
		    echo json_encode($response_order);
		}
		else
		{
			$response_order['response'] = 'False';
			$response_order['message'] = 'No Data Found';
			$response_order['order_list'] = '';
			echo json_encode($response_order);
		}

       
	}

	public function OrderDetails()
	{
		$user_id = $this->input->get('user_id');
		
		$orderdetails = $this->db->select('t1.order_code, t3.item_name, t4.unit_value,t5.unit_name,t4.price,t2.quantity as order_quantity')->from('kf_order as t1')->join('kf_order_items as t2', 't1.order_id = t2.order_id', 'LEFT')->join('kf_item as t3', 't2.item_id = t3.item_id', 'LEFT')->join('kf_item_price_unit as t4', 't4.id = t2.unit_price_id ', 'LEFT')->join('kf_unit_master as t5', 't4.unit_id = t5.unit_id', 'LEFT')->where('t1.user_id', $user_id)->get()->result_array();

		

		if(!empty($orderdetails))
		{
			$response_orderdetails['reponse'] = 'True';
			$response_orderdetails['message'] = '';
			$response_orderdetails['order_details'] = $orderdetails;
			echo json_encode($response_orderdetails);
		}
		else
		{
			$response_orderdetails['reponse'] = 'False';
			$response_orderdetails['message'] = 'No Data Found';
			$response_orderdetails['order_details'] = '';
			echo json_encode($response_orderdetails);
		}

		
	}

	public function allusercoupon()
	{
		$allusercoupon=$this->db->select('*')->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->where('status',1)->get('kf_cupon')->result_array();
		
		
		if(!empty($allusercoupon))
		{
			$response_allusercoupon['reponse'] = 'True';
			$response_allusercoupon['message'] = '';
			$response_allusercoupon['order_details'] = $allusercoupon;
			echo json_encode($response_allusercoupon);
		}
		else
		{
			$response_allusercoupon['reponse'] = 'False';
			$response_allusercoupon['message'] = 'No Data Found';
			$response_allusercoupon['order_details'] = '';
			echo json_encode($response_allusercoupon);
		}

	}

	public function allnewusercoupon()
	{
		$allnewusercoupon=$this->db->select('*')->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->where('user','New User')->where('status',1)->get('kf_cupon')->result_array();

		
		if(!empty($allnewusercoupon))
		{
			$response_allnewusercoupon['reponse'] = 'True';
			$response_allnewusercoupon['message'] = '';
			$response_allnewusercoupon['order_details'] = $allnewusercoupon;
			echo json_encode($response_allnewusercoupon);
		}
		else
		{
			$response_allnewusercoupon['reponse'] = 'False';
			$response_allnewusercoupon['message'] = 'No Data Found';
			$response_allnewusercoupon['order_details'] = '';
			echo json_encode($response_allnewusercoupon);
		}

	}

	
	public function userdetails()
	{
		$coupon=$this->input->get('cupon_id');
		
		$user=$this->input->get('user_id');

		$amount=$this->input->get('total_amount');


		$coupon_details=$this->db->where('cupon_id',$coupon)->get('kf_cupon')->result_array();
		
		
		$have_user_order=$this->db->where('user_id',$user)->get('kf_order')->result_array();
	
		if(empty($have_user_order)&& $coupon_details[0]['user']=="New User")
		{
			$this->session->set_flashdata('fail', 'Coupon is invalid');
		}
		else
		{
			if($coupon_details[0]['discount_price_type'] == 'lumpsum')
			{
				$total_amount = $amount - $coupon_details[0]['discount_amount'];
			}
			else
			{
				$total_amount_percentage = $amount * ($coupon_details[0]['discount_amount']/100);
			    $total_amount = $amount - $total_amount_percentage;

			}
		}
			if($have_user_order!= '' && $coupon_details!= '')
			{
				$userdetails['reponse'] = 'True'; 
				$userdetails['message'] = '';
				$userdetails['user_id'] = $have_user_order[0]['user_id'];
				$userdetails['total_amount'] =$total_amount;
				$userdetails['cupon_id'] = $coupon_details[0]['cupon_id'];
				if($coupon_details[0]['discount_price_type'] == 'lumpsum')
				{
					$userdetails['discount'] = "RS. " . $coupon_details[0]['discount_amount'];
				}
				if($coupon_details[0]['discount_price_type'] == 'percentage')
				{
					$userdetails['discount'] = $coupon_details[0]['discount_amount'] . "%";
				}
				echo json_encode($userdetails);
			}
			else
			{
				$userdetails['reponse'] = 'False';
				$userdetails['message'] = 'No Data Found';
				$userdetails['user_id'] = '';
				$userdetails['total_amount'] = '';
				$userdetails['cupon_id'] = '';
				$userdetails['discount'] = '';
				echo json_encode($userdetails);
			}
	}

	public function checkout_user()
	  {
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);
		
		$have_email = $this->db->where('email',$data['email'])->get('kf_user')->result_array();
		
		if(!empty($have_email))
		{
			$response['response'] = 'false' ;
			$response['message']  = 'email alreay exsist' ;
			echo json_encode($response);
		}
		else{

			$insert_data['name']       = $data['name'];
			$insert_data['email']      = $data['email'];
			$insert_data['address']    = $data['address'];
			$insert_data['phone']      = $data['phone'];
			$insert_data['pin_code']   = $data['pin'];
			$insert_data['state']      = $data['state'];
			$insert_data['country']    = $data['country'];
			$insert_data['ip_address'] = $data['mac_address'];
			$insert_data['status']     = 1;
			
			$this->db->insert('kf_user',$insert_data);
			
			$insert_id = $this->db->insert_id();
			
			if($insert_id!='')
			{
				$have_id = $this->db->where('ip_Address',$data['mac_address'])->get('kf_ip_address')->result_array();
				if(empty($have_id))
				{
				$insert_ip['ip_Address'] = $data['mac_address'];
				$insert_ip['status'] = 1;
				$this->db->insert('kf_ip_address',$insert_ip);
				}

				$response['response'] = 'true' ;
				$response['message'] = 'successfully registered' ;
				echo json_encode($response);
			}
			else{
				$response['response'] = 'false' ;
				$response['message'] = 'something wrong,try after sometime' ;
				echo json_encode($response);
			}
		}
	  }
	





}
