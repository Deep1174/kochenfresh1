<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class WebServices extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('UsersModel');
		 $this->load->library('email');
    }

	 /**
    * web api for login check with user email and password also check ip address is blocked or active
    * 
    * @param1       @email,@password,@ip addess
    * @return       user id if matched / message of invalid credetial if not matched
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         
    * @since        22.11.2017
    * @deprecated   N/A
    */
  public function check_login_details()
  {
	 
	 $email = $this->input->get('email');
	 $password = $this->input->get('password');
     $ip_address = $this->input->get('ip_address');
	 
	 $md5_convert_data 	= md5(trim($password));
	 $salt_key 			= get_encript_id(trim($password));
	 $password 			= $md5_convert_data.$salt_key;
	 //** **//
	 $user_details = $this->db->where('email',$email)->where('password',$password)->where('status',1)->get('kf_user')->result_array();
	 //echo $this->db->last_query();
	 $is_active_ip = $this->db->where('status',1)->where('ip_Address',$ip_address)->get('kf_ip_address')->result_array();
	 if(!empty($user_details) && !empty($is_active_ip))
	 {
		 
		 $response['response'] = 'true' ;
		 $response['message'] = 'successfully logedin' ;
		 $response['user_details'] = $user_details;
		 echo json_encode($response);
	 }
	 else
	 {
		 $response['response'] = 'false' ;
		 $response['message'] = 'Invalid credential' ;
		 $response['user_id'] = 'null' ;
		 echo json_encode($response);
	 }
  }
  
	

	public function save_registerd_data()
	  {
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);
		
		$have_email = $this->db->where('email',$data['email'])->get('kf_user')->result_array();
		
		if(!empty($have_email))
		{
			$response['response'] = 'false' ;
			$response['message'] = 'email alreay exsist' ;
			echo json_encode($response);
		}
		else{
			$md5_convert_data 	= md5(trim($data['pwd']));
			$salt_key 			= get_encript_id(trim($data['pwd']));
			$password 			= $md5_convert_data.$salt_key;
			
			$insert_data['name'] = $data['name'];
			$insert_data['email'] = $data['email'];
			$insert_data['address'] = $data['address'];
			$insert_data['phone'] = $data['phone'];
			$insert_data['pin_code'] = $data['pin'];
			$insert_data['ip_address'] = $data['mac_address'];
			$insert_data['password'] = $password;
			$insert_data['status'] = 1;
			
			$this->db->insert('kf_user',$insert_data);
			$insert_id = $this->db->insert_id();
			if($insert_id!='')
			{
				$have_id = $this->db->where('ip_Address',$data['mac_address'])->get('kf_ip_address')->result_array();
				if(empty($have_id)){
				$insert_ip['ip_Address'] = $data['mac_address'];
				$insert_ip['status'] = 1;
				$this->db->insert('kf_ip_address',$insert_ip);
				}
				/**check mail**/
				$mailbody1 = '<div style="width:650px; margin:0px auto;  padding:0px 0px;" >
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff" style="border:20px solid #29387b" >
                <tr>
                  <td width="100%" colspan="10" style="flot:left; background:#fff; padding:15px 0 10px 15px; text-align:center;"><img src="http://' . $_SERVER['HTTP_HOST'] . '/KochenFresh/images/logotext.png"  alt=""></td>
                </tr>
                <tr>
                     <td style="padding:0px 15px; background:#29387b;"><p style="text-align:center; color:#fff; text-transform:uppercase; font-size:22px; margin:0; padding:10px 0; font-family:Verdana, Geneva, sans-serif; ">
                  Successfully registerd</p></td>
                </tr>
                            <tr>
                              <td style="padding:20px 15px;">
                                 <p>Hello '.$data['name'].'</p>
                                <p> Thank you for Registration .</p>
                                  
                                
                                <p>&nbsp;</p>
                    <p style="font-family:Verdana, Geneva, sans-serif; font-size:14px;">Regards,</p>
                    <p style="font-family:Verdana, Geneva, sans-serif; font-size:14px;">Kochen Fresh Team</p>
                  </td>
                </tr>
               <tr>
                 
               </tr>
               <tr>
                 <td style="background:#e32124; padding:6px 0;">
                <p style="color:#fff; font-family:Verdana, Geneva, sans-serif; text-align:center; font-size:12px;"> ©' . date('Y') . ' All Rights Reserved</p>
                </td>
               </tr>
            </table>
            </div>';
			//echo $mailbody1;

           
            
            $this->email->from('Aalexjhones@gmail.com', 'Kochen Fresh');
            $this->email->to($data['email']);
            $this->email->set_mailtype('html');

            $this->email->subject('Successfull registration');
            $this->email->message($mailbody1);
            $send = $this->email->send();
			/** check mail*/
				$response['response'] = 'true' ;
				$response['message'] = 'successfully registered' ;
				echo json_encode($response);
			}
			else{
				$response['response'] = 'false' ;
				$response['message'] = 'something wrong,try after sometime' ;
				echo json_encode($response);
			}
		}
	  }
	
	public function itemlist_by_cat_id()
  	{
	 
	$category = $this->input->get('cat_id');
	$user_id = $this->input->get('user_id');
	
	$item_list = $this->db->select('*')->from('kf_item')->where('cat_id',$category)->where('status',1)->get()->result_array();
	$cat_name = $this->db->where('cat_id',$category)->where('status',1)->get('kf_category')->result_array();
	
	foreach($item_list as $k=>$val)
	{
		$is_wislist_item ='0';
		if($user_id !=''){
		 $wishlist_item_details = $this->db->where('user_id',$user_id)->where('item_id',$val['item_id'])->get('kf_wish_list')->result_array();
			if(!empty($wishlist_item_details))
			{
				$is_wislist_item ='1';
			}
		}
		$item_list[$k]['is_wishlist'] = $is_wislist_item;
		$item_list[$k]['img_name'] = base_url().'uploads/items/'.$val['img_name'];
		$item_price =  $this->db->select('concat(price.unit_value, "", unit.unit_name) as unit,price.*,unit.unit_name,item.item_name')->from('kf_item_price_unit price')->join('kf_item item','price.item_id=item.item_id','left')->join('kf_unit_master unit','unit.unit_id=price.unit_id')->where('price.item_id',$val['item_id'])->get()->result_array();
		$item_price_arr ='';
		
		if(!empty($item_price))
		{
			foreach($item_price as $ky=>$item_price_val)
		{
			$item_price_arr .= $item_price_val['unit'] .'-Rs:'. $item_price_val['price']." ";
			
		}
			 $item_list[$k]['item_price'] = $item_price_arr ;
			 
		}
		else{
			 $item_list[$k]['item_price'] = "No Data Found" ; 
		}
	     $total_cart_item = $this->db->select('count(id) as total_cart_item')->where('user_id',$user_id)->get('kf_add_to_cart')->result_array();
		 $item_list[$k]['total_cart_item'] = isset($total_cart_item[0]['total_cart_item'])?$total_cart_item[0]['total_cart_item']:0;
	}
	$response['cat_name']=isset($cat_name[0]['cat_name'])?$cat_name[0]['cat_name']:'N/A';
	             // echo"<pre>";print_r($item_list);
	if(!empty($item_list))
	{
		$response['response']='true';
		$response['message']=' ';
		$response['item_list']= $item_list ;
		echo json_encode($response);
		
	}
	else
	{
		$response['response']='False';
		$response['message']='No Data Found ';
		$response['item_list']= ' ' ;
		echo json_encode($response);
		 
	}
	
	
	}
	public function category_list()
  	{
	 
	
	
	$cat_list = $this->db->select('*')->from('kf_category')->where('parent_id',0)->where('status',1)->get()->result_array();
	
	foreach($cat_list as $k=>$val)
	{
			if($val['image']!='')
			{
				$cat_list[$k]['image'] = base_url().'uploads/category/'.$val['image'];
			}
			else{
				$cat_list[$k]['image'] = base_url().'images/no-image.jpeg';
			}
			
	}
	//echo"<pre>";print_r($cat_list);exit;
		if(!empty($cat_list))
		{
			$response['response']='true';
			$response['message']=' ';
			$response['category_list']= $cat_list ;
			echo json_encode($response);
			
		}
		else
		{
			$response['response']='False';
			$response['message']='No Data Found ';
			$response['category_list']= ' ' ;
			echo json_encode($response);
			 
		}
	
	
	}
	
	public function offer_images()
	{
		$offer_image = $this->db->where('status',1)->get('kf_offer')->result_array();
		
		foreach($offer_image as $k=>$val)
		{
			$offer_image[$k]['offer_image'] = base_url().'uploads/offer_banner/'.$val['offer_image'];
		}
		if(!empty($offer_image))
		{
			$response['response']='true';
			$response['message']=' ';
			$response['offer_details']= $offer_image ;
			echo json_encode($response);
			
		}
		else
		{
			$response['response']='False';
			$response['message']='No Data Found ';
			$response['offer_details']= ' ' ;
			echo json_encode($response);
			 
		}
	}
	public function get_item_price_by_id()
	{
		$item_id = $this->input->get('item_id');
		
		$item_details = $this->db->select('*')->from('kf_item')->where('item_id',$item_id)->where('status',1)->get()->result_array();
		$item_price =  $this->db->select('concat(price.unit_value, "", unit.unit_name) as unit,price.*,unit.unit_name,item.item_name')->from('kf_item_price_unit price')->join('kf_item item','price.item_id=item.item_id','left')->join('kf_unit_master unit','unit.unit_id=price.unit_id')->where('price.item_id',$item_id)->get()->result_array();
		//echo"<pre>";print_r($item_price);
		if(!empty($item_price))
		{
			$response['response']='true';
			$response['message']=' ';
			$response['item_name']=isset($item_details[0]['item_name'])?$item_details[0]['item_name']:'N/A';
			$response['item_image']=isset($item_details[0]['img_name'])&&$item_details[0]['img_name']!=''?base_url().'uploads/items/'.$item_details[0]['img_name']:'N/A';
			$response['item_price']= $item_price ;
			echo json_encode($response);
			
		}
		else
		{
			$response['response']='False';
			$response['message']='No Data Found ';
			$response['item_price']= ' ' ;
			echo json_encode($response);
			 
		}
	}
	/**
    * web api check pin codes that are available and active
    * 
    * @param1       @email,@password,@ip addess
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function available_code()
	{
		$code = $this->input->get('pin_code');
		$result = $this->db->where('status',1)->where('pin_code',$code)->get('kf_cod_pin')->result_array();
		if(!empty($result))
		{
			$response['response']='true';
			$response['message']='available';
			
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='unavailable';
			
			echo json_encode($response);
		}
	}
	/**
    * web api for add to cart
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function add_to_cart()
	{
		$user_id = $this->input->get('user_id');
		$item_id = $this->input->get('item_id');
		$unit_price_id = $this->input->get('unit_price_id');
		$quantity = $this->input->get('quantity');
		$total_amount = $this->input->get('total_amount');
		if($user_id!='')
		{
		$insert_data['user_id'] = $user_id;
		$insert_data['item_id'] = isset($item_id)&& $item_id!=''?$item_id:'';
		$insert_data['unit_price_id'] = isset($unit_price_id)&& $unit_price_id!=''?$unit_price_id:'';
		$insert_data['quantity'] = isset($quantity)&& $quantity!=''?$quantity:'';
		$insert_data['total_price'] = isset($total_amount)&& $total_amount!=''?$total_amount:'';
		$insert_data['cart_date'] = date('Y-m-d h:i:s');
		$this->db->insert('kf_add_to_cart',$insert_data);
		}
		$insert_id = $this->db->insert_id();
		if($insert_id!='')
		{
			$response['response']='true';
			$response['message']='successfully add to cart';
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='something worng,try after some time';
			echo json_encode($response);
		}
	}
	/**
    * web api for add to cart
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function cart_item_list()
	{
		$user_id = $this->input->get('user_id');
		
		
		$result = $this->db->select('price.id as unit_price_id,concat(price.unit_value, "", unit.unit_name) as unit,price.price as unit_price,cart.*,cart.id as cart_id,item.item_name,item.img_name')->from('kf_add_to_cart cart')->join('kf_item item','cart.item_id=item.item_id','left')->join('kf_item_price_unit price','price.id=cart.unit_price_id','left')->join('kf_unit_master unit','unit.unit_id=price.unit_id','left')->where('cart.user_id',$user_id)->get()->result_array();
		
		$total_cart_price = 0;
		$total_cart_item = 0;
		if(!empty($result))
		{
			foreach($result as $k=>$val)
		{
			$total_cart_item = $total_cart_item + 1;
			$result[$k]['img_name'] = base_url().'uploads/items/'.$val['img_name'];
			$total_cart_price = $total_cart_price + $val['total_price'];
		}	//echo $this->db->last_query();
		//echo"<pre>";print_r($result);
		
			$response['response']='true';
			$response['message']='cart item list';
			$response['total_cart_price']=$total_cart_price;
			$response['total_cart_item']=$total_cart_item;
			$response['item_details']= $result;
			echo json_encode($response);
		}
		else{
			$response['response']='false';
			$response['message']='no cart item found';
			echo json_encode($response);
		}
	}
	/**
    * web api for delete cart id
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/delete_cart_item
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function delete_cart_item()
	{
		$cart_id = $this->input->get('cart_id');
		if($this->db->where('id',$cart_id)->delete('kf_add_to_cart'))
		{
			$response['response']='true';
			$response['message']='cart item deleted';
			echo json_encode($response);
			
		}
		else{
			$response['response']='false';
			$response['message']='something wrong,try after some time';
			echo json_encode($response);
		}
	}
	
	/**
    * web api for add to wishlist
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function add_to_wishlist()
	{
		$user_id = $this->input->get('user_id');
		$item_id = $this->input->get('item_id');
		
		
		$have_wish_list = $this->db->where('user_id',$user_id)->where('item_id',$item_id )->get('kf_wish_list')->result_array();
		if(empty($have_wish_list))
		{
			if($user_id!='')
			{
			$insert_data['user_id'] = $user_id;
			$insert_data['item_id'] = isset($item_id)&& $item_id!=''?$item_id:'';
			
			$this->db->insert('kf_wish_list',$insert_data);
			}
			$insert_id = $this->db->insert_id();
			if($insert_id!='')
			{
				
				
				
				$response['response']='true';
				$response['message']=' added to wish list';
				echo json_encode($response);
			}
			else{
				$response['response']='false';
				$response['message']='something worng,try after some time';
				echo json_encode($response);
			}
		}
		else{
			     $response['response']='false';
				$response['message']='Already added';
				echo json_encode($response);
		}
	}
	/**
    * web api for login check with user email and password also check ip address is blocked or active
    * 
    * @param1       @email,@password,@ip addess
    * @return       user id if matched / message of invalid credetial if not matched
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         
    * @since        22.11.2017
    * @deprecated   N/A
    */
	public function get_wish_list()
	{
		$user_id = $this->input->get('user_id');

		

		$wishlist = $this->db->select('wish_list.id as wishlist_id,item.*')->from('kf_wish_list as wish_list')->join('kf_item as item', 'wish_list.item_id = item.item_id', 'LEFT')->where('wish_list.user_id', $user_id)->get()->result_array();
		 $total_item = '0';

		if(!empty($wishlist))
		{
			foreach($wishlist as $k=>$val)
			{
				$total_item = $total_item +1;
				$wishlist[$k]['img_name'] = base_url().'uploads/items/'.$val['img_name'];
			}
			$response_wish['response'] = 'True';
			$response_wish['total_item'] = "$total_item";
			$response_wish['message'] = '';
			$response_wish['wish_list'] = $wishlist;
		    echo json_encode($response_wish);
		}
		else
		{
			$response_wish['response'] = 'False';
			$response_wish['total_item'] = '0';
			$response_wish['message'] = 'No Data Found';
			$response_wish['wish_list'] = '';
			echo json_encode($response_wish);
		}
		
		
	}
	/**
    * web api for add to wishlist from cart
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function wishlist_from_cart()
	{
		$user_id = $this->input->get('user_id');
		$cart_id = $this->input->get('cart_id');
		$item_details = $this->db->where('id',$cart_id)->get('kf_add_to_cart')->result_array();
		$item_id = isset($item_details[0]['item_id'])?$item_details[0]['item_id']:0;
		
		$have_wish_list = $this->db->where('user_id',$user_id)->where('item_id',$item_id )->get('kf_wish_list')->result_array();
		$this->db->where('id',$cart_id )->delete('kf_add_to_cart');
		if(empty($have_wish_list))
		{
			if($user_id!='')
			{
			$insert_data['user_id'] = $user_id;
			$insert_data['item_id'] = isset($item_id)&& $item_id!=''?$item_id:'';
			
			$this->db->insert('kf_wish_list',$insert_data);
			}
			$insert_id = $this->db->insert_id();
			if($insert_id!='')
			{
				
				
				
				$response['response']='true';
				$response['message']=' added to wish list';
				echo json_encode($response);
			}
			else{
				$response['response']='false';
				$response['message']='something worng,try after some time';
				echo json_encode($response);
			}
		}
		else{
			     $response['response']='false';
				$response['message']='Already added';
				echo json_encode($response);
		}
	}
	/**
    * web api remove from wishlist
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function remove_from_wishlist()
	{
		$user_id = $this->input->get('user_id');
		$item_id = $this->input->get('item_id');
		if($user_id!='' && $item_id!='')
		{
			$this->db->where('item_id',$item_id)->where('user_id',$user_id)->delete('kf_wish_list');
			    $response['response']='true';
				$response['message']='removed';
				echo json_encode($response);
		}
		else{
			    $response['response']='false';
				$response['message']='something wrong,try after sometime';
				echo json_encode($response);
		}
	}
	/**
    * web api remove all item wishlist
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function clear_wishlist()
	{
		$user_id = $this->input->get('user_id');
		
		if($user_id!='')
		{
			$this->db->where('user_id',$user_id)->delete('kf_wish_list');
			    $response['response']='true';
				$response['message']='removed';
				echo json_encode($response);
		}
		else{
			    $response['response']='false';
				$response['message']='something wrong,try after sometime';
				echo json_encode($response);
		}
	}
	/**
    * order details page before check out with cupon code checking
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function order_details()
	{
		$user_id= $this->input->get('user_id');
		$item_price_id= $this->input->get('item_price_id');
		$iyem_id = $this->input->get('item_id');
		$quantity = $this->input->get('quantity');
		$cupon_id = $this->input->get('cupon_id'); 
		
		$user_details = $this->db->where('user_id',$user_id)->get('kf_user')->result_array();
		if(!empty($user_details))
		{
			$user_details = $user_details;
		}
		else{
			$user_details = "no data found";
		}
		$item_details = $this->db->select('*,concat(price.unit_value, "", unit.unit_name) as unit,price.price as unit_price,item.item_name')->from('kf_item_price_unit price')->join('kf_item item','item.item_id=price.item_id','left')->join('kf_unit_master unit','unit.unit_id=price.unit_id')->where('price.id',$item_price_id)->get()->result_array();
		
		
		
		$count =0;
		if(!empty($item_details)){
			foreach($item_details as $k=>$val)
			{
				$total_amount = round(($val['unit_price']*$quantity) ,2);
				$count = $count +1;
				$item_details[$k]['total_amount'] = "$total_amount";
				$item_details[$k]['img_name'] = base_url().'uploads/items/'.$val['img_name'];
				$item_details[$k]['quantity'] = "$quantity";
			}
		}
		else{
			$item_details = "no data found";
		}
		
		/** cupon section **/
		$coupon_details=$this->db->where('cupon_id',$cupon_id)->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->get('kf_cupon')->result_array();
		$have_user_order=$this->db->where('user_id',$user_id)->get('kf_order')->result_array();
		if(!empty($coupon_details)  && ((empty($have_user_order)&& $coupon_details[0]['user']=="New User")|| ($coupon_details[0]['user']=="All User")) &&$coupon_details[0]['purchase_price']<=$total_amount)
		{
			
			if($coupon_details[0]['discount_price_type'] == 'lumpsum')
			{
				$discount_amount =  $coupon_details[0]['discount_amount'];
				$total_price_amount = $total_amount - $coupon_details[0]['discount_amount'];
			}
			else
			{
				
				$total_amount_percentage = $total_amount * ($coupon_details[0]['discount_amount']/100);
				$discount_amount =  $total_amount_percentage;
			    $total_price_amount = $total_amount - $total_amount_percentage;

			}
			$response['cupon_discount']="$discount_amount";
			
		}
		else{
			
			$response['cupon_discount']="0.00";
		}
		/** cupon section **/
		 $response['cupon_id']="$cupon_id";
		 $response['response']='true';
		 $response['total_item']="$count";
		 $response['user_details']=$user_details;
		 $response['item_details']=$item_details;
		 echo json_encode($response);
		
	}
	/**
    * user details y user id
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function user_details()
	{
		$user_id= $this->input->get('user_id');
		$user_details = $this->db->where('user_id',$user_id)->get('kf_user')->result_array();
		if(!empty($user_details))
		{
			$response['response']='true';
			$response['user_details']=$user_details;
		}
		else{
			$response['response']='false';
			$response['user_details']= "no data found";
		}
		echo json_encode($response);
	}
	/**
    * update user y user id
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function update_user()
	{
		$user_id 	  = $this->input->get('user_id');
		$name 	  = $this->input->get('name');
		$mobile   = $this->input->get('mobile');
		$pin_code = $this->input->get('pin_code');
		$address  = $this->input->get('address');
		if($name!='')
		{
			$update_data['name'] = $name;
		}
		if($mobile!='')
		{
			$update_data['phone'] = $mobile; 
		}
		if($pin_code!='')
		{
			$update_data['pin_code'] = $pin_code;
		}
		if($address!='')
		{
			$update_data['address'] = $address;
		}
		
		if($this->db->where('user_id',$user_id)->update('kf_user',$update_data))
		{
			$response['response']='true';
			$response['msg']= "user information successfully updated";
		}
		else{
			$response['response']='false';
			$response['msg']= "try after some time";
		}
		echo json_encode($response);
	}
	/**
    * all cupon code list active and valid for current date
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function allusercoupon()
	{
		$allusercoupon=$this->db->select('*')->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->where('status',1)->get('kf_cupon')->result_array();
		
		
		if(!empty($allusercoupon))
		{
			$response_allusercoupon['reponse'] = 'True';
			$response_allusercoupon['message'] = '';
			$response_allusercoupon['order_details'] = $allusercoupon;
			echo json_encode($response_allusercoupon);
		}
		else
		{
			$response_allusercoupon['reponse'] = 'False';
			$response_allusercoupon['message'] = 'No Data Found';
			$response_allusercoupon['order_details'] = '';
			echo json_encode($response_allusercoupon);
		}

	}
	/**
    * applied cupon code
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	
	public function applied_cupon()
	{
		$user_id 	  = $this->input->get('user_id');
		$cupon_id = $this->input->get('cupon_id'); 
		/** cupon section **/
		$coupon_details=$this->db->where('cupon_id',$cupon_id)->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->get('kf_cupon')->result_array();
		$have_user_order=$this->db->where('user_id',$user_id)->get('kf_order')->result_array();
		if(!empty($coupon_details) && (empty($have_user_order)&& $coupon_details[0]['user']=="New User")|| $coupon_details[0]['user']=="All User") 
		{
			if(!empty($have_user_order) && $have_user_order[0]['cupon_id']==$cupon_id)
			{
				$response_allusercoupon['reponse'] = 'false';
				$response_allusercoupon['message'] = 'not a valid cupon';
				echo json_encode($response_allusercoupon);
			}
			else{
				$response_allusercoupon['reponse'] = 'true';
				$response_allusercoupon['message'] = 'applied';
				echo json_encode($response_allusercoupon);
			}
			
		}
		else{
			
			$response_allusercoupon['reponse'] = 'false';
			$response_allusercoupon['message'] = 'not a valid cupon';
			echo json_encode($response_allusercoupon);
		}
	}
	/**
    * place single order by user id
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function place_single_order()
	{
		$this->db->trans_start();
		$user_id= $this->input->get('user_id');
		$order_id= $this->input->get('order_id');
		$item_price_id= $this->input->get('item_price_id');
		$item_id = $this->input->get('item_id');
		$quantity = $this->input->get('quantity');
		$cupon_id = $this->input->get('cupon_id');
		$discount_amount = $this->input->get('discount_amount');
		$total_amount = $this->input->get('total_amount');
		
		$have_order_id = $this->db->where('order_code',$order_id)->get('kf_order')->result_array();
		if(empty($have_order_id)){
			/** order insert**/
			$insert_data['order_code'] = $order_id;
			$insert_data['user_id'] = $user_id;
			$insert_data['cupon_id'] = $cupon_id;
			$insert_data['discount_amount'] = $discount_amount;
			$insert_data['total_amount'] = $total_amount;
			$insert_data['payment_status'] = 0;
			$insert_data['status'] = 0;
			$insert_data['order_date'] = date('Y-m-d');
			$this->db->insert('kf_order',$insert_data);
			/**order  item insert**/
			$insert_id = $this->db->insert_id();
			$insert_item['order_id']= $insert_id;
			$insert_item['item_id']= $item_id;
			$insert_item['unit_price_id']= $item_price_id;
			$insert_item['quantity']= $quantity;
			$this->db->insert('kf_order_items',$insert_item);
			$insert_item_id = $this->db->insert_id();
		
		$this->db->trans_complete();
		if($insert_id !='' && $insert_item_id!='')
		{
			$response['reponse'] = 'true';
			$response['message'] = 'order placed';
			echo json_encode($response);
		}
		else{
			$response['reponse'] = 'false';
			$response['message'] = 'try after some time';
			echo json_encode($response);
		}
		}
		else{
			$response['reponse'] = 'false';
			$response['message'] = 'try after some time';
			echo json_encode($response);
		}
	}
	/**
    * user order details with cupon details and item
    * 
    * @param1       item id, unit price id,total amount,user id,quantity
    * @return       cod is available  / not
    * @access       public
    * @author       D.M
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        27.11.2017
    * @deprecated   N/A
    */
	public function UserOrderDetails()
	{
		$user_id = $this->input->get('user_id');
		$user_orders =  $this->db->select('order.*,cupon.cupon_id,cupon.cupon_name')->from('kf_order order')->join('kf_cupon cupon','order.cupon_id=cupon.cupon_id','left')->get()->result_array();
		
		
		foreach($user_orders as $k=>$val)
		{
			$user_orders[$k]['item_details'] = $this->db->select('*')->from('kf_order_items order_item')->join('kf_item item','order_item.item_id=item.item_id','left')->join('kf_item_price_unit as price', 'price.id = order_item.unit_price_id ', 'LEFT')->join('kf_unit_master as unit', 'price.unit_id = unit.unit_id', 'LEFT')->where('order_item.order_id', $val['order_id'])->get()->result_array();
		}
		
		if(!empty($user_orders))
		{
			$response_orderdetails['reponse'] = 'True';
			$response_orderdetails['message'] = '';
			$response_orderdetails['order_details'] = $user_orders;
			echo json_encode($response_orderdetails);
		}
		else
		{
			$response_orderdetails['reponse'] = 'False';
			$response_orderdetails['message'] = 'No Data Found';
			$response_orderdetails['order_details'] = '';
			echo json_encode($response_orderdetails);
		}

		
	}

		public function checkout_user()
	  {
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);
		
		// $have_email = $this->db->where('email',$data['email'])->get('kf_user')->result_array();
		
		if(!empty($have_email))
		{
			$response['response'] = 'false' ;
			$response['message']  = 'email alreay exsist' ;
			echo json_encode($response);
		}
		else{

			$insert_data['name']       = $data['name'];
			$insert_data['lastname']   = $data['lastname'];
			$insert_data['email']      = $data['email'];
			$insert_data['address']    = $data['address'];
			$insert_data['phone']      = $data['phone'];
			$insert_data['pin_code']   = $data['pin'];
			$insert_data['state']      = $data['state'];
			$insert_data['country']    = $data['country'];
			$insert_data['ip_address'] = $data['mac_address'];
			$insert_data['status']     = 1;
			
			$this->db->insert('kf_user',$insert_data);



			
			
			$insert_id = $this->db->insert_id();

			if($data['shipping_fname']!='' && $data['shipping_lname']!='' && $data['shipping_phone']!='' && $data['shipping_code']!='')
			{
				$insert_ship['user_id']              = $insert_id;
				$insert_ship['shipping_fname']       = $data['shipping_fname'];
				$insert_ship['shipping_lname']       = $data['shipping_lname'];
				$insert_ship['shipping_phone']       = $data['shipping_phone'];
				$insert_ship['shipping_code']        = $data['shipping_code'];
				$insert_ship['Shipping_add']         = $data['Shipping_add'];

				$this->db->insert('kf_shipping',$insert_ship);

			}
			
			if($insert_id!='')
			{
				$have_id = $this->db->where('ip_Address',$data['mac_address'])->get('kf_ip_address')->result_array();
				if(empty($have_id))
				{
				$insert_ip['ip_Address'] = $data['mac_address'];
				$insert_ip['status'] = 1;
				$this->db->insert('kf_ip_address',$insert_ip);
				}

				$response['response'] = 'true' ;
				$response['message'] = 'successfully registered' ;
				$response['user_id'] = "$insert_id" ;

				echo json_encode($response);
			}
			else{
				$response['response'] = 'false' ;
				$response['message'] = 'something wrong,try after sometime' ;
				echo json_encode($response);
			}
		}
	  }

	  public function checkout_userdetails()
	{
		$user_id      = $this->input->get('user_id');
		$user_details =  $this->db->select('*')->from('kf_user')->where('user_id', $user_id)->get()->result_array();
		$ship_details =  $this->db->select('*')->from('kf_shipping')->where('user_id', $user_id)->get()->result_array();
		
		
		if(!empty($user_details))
		{
			$response_orderdetails['reponse'] = 'True';
			$response_orderdetails['message'] = '';
			$response_orderdetails['user_details'] = $user_details;
			$response_orderdetails['ship_details'] = $ship_details;
			echo json_encode($response_orderdetails);
		}
		else
		{
			$response_orderdetails['reponse'] = 'False';
			$response_orderdetails['message'] = 'No Data Found';
			$response_orderdetails['user_details'] = '';
			$response_orderdetails['ship_details'] = '';
			echo json_encode($response_orderdetails);
		}

		
	}

		/**
    * user Submit Order list and item
    * 
    * @param1       order_code, user_id,cupon_id,discount_amount,total_amount,payment_status,status,order_date,order_item_id,quantity,unit_price_id
    * @return       cod is available  / not
    * @access       public
    * @author       D.K
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        26.12.2017
    * @deprecated   N/A
    **/
    
		public function orderlist()
	  {
		
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);
	
		$insert_data['order_id']        = 'KF'.rand();
		$insert_data['order_code']      = $data['order_code'];
		$insert_data['user_id']         = $data['user_id'];
		$insert_data['cupon_id']        = $data['cupon_id'];
		$insert_data['discount_amount'] = $data['discount_amount'];
		$insert_data['total_amount']    = $data['total_amount'];
		$insert_data['payment_status']  = $data['payment_status'];
		$insert_data['status']          = $data['status'];
		$insert_data['order_date']      = date("Y-m-d h:i:s");

		$this->db->insert('kf_order',$insert_data);

		$insert_id = $this->db->insert_id();

        // $order_item_id                  =  "WzEsMiwzLDRd";
        // $quantity                       =  "WzEsMiwzLDRd";
        // $unit_price_id                  =  "WzEsMiwzLDRd";

		$order_item_id                  = $data['item_id'];
		$quantity                       = $data['quantity'];
		$unit_price_id                  = $data['unit_price_id'];
		
		$order_item_id                  = base64_decode($order_item_id);
		$quantity                       = base64_decode($quantity);
		$unit_price_id                  = base64_decode($unit_price_id);
			
		$order_item_id                  = str_replace('[', "", $order_item_id);
		$order_item_id                  = str_replace(']', '', $order_item_id);	
		$quantity                       = str_replace('[', "", $quantity);
		$quantity                       = str_replace(']', '', $quantity);	
		$unit_price_id                  = str_replace('[', "", $unit_price_id);
		$unit_price_id                  = str_replace(']', '', $unit_price_id);	

        $item_id_values_array           = explode(',', $order_item_id);
        $quantity_values_array          = explode(',', $quantity);
        $unit_price_id_values_array     = explode(',', $unit_price_id);
     

        $count =  count($item_id_values_array); 

       for ($i=0; $i <$count ; $i++) 
       { 
        
        $insert_order_data['order_id']           =  $insert_id;
        $insert_order_data['item_id']            =  $item_id_values_array[$i];
        $insert_order_data['unit_price_id']      =  $quantity_values_array[$i];
        $insert_order_data['quantity']           =  $unit_price_id_values_array[$i];
     
        $this->db->insert('kf_order_items',$insert_order_data);

        }
	   
	    $response['response'] = 'true' ;
		$response['message']  = 'order submited successfully' ;

		echo json_encode($response);
	 
	  }

	  		/**
    * user Submit Order list and item
    * 
    * @param1       order_code, user_id,cupon_id,discount_amount,total_amount,payment_status,status,order_date,order_item_id,quantity,unit_price_id
    * @return       cod is available  / not
    * @access       public
    * @author       D.K
    * @copyright    N/A
    * @link         WebServices/available_code
    * @since        26.12.2017
    * @deprecated   N/A
    **/
    
		public function cart_orderlist()
	  {
		
		$data = $this->input->get(); 
		$data = $this->security->xss_clean($data);
	
		$insert_data['order_id']        = 'KF'.rand();
		$insert_data['user_id']         = $data['user_id'];
		$insert_data['total_amount']    = $data['total_amount'];
		$insert_data['order_date']      = date("Y-m-d h:i:s");

		$this->db->insert('kf_order',$insert_data);

		$insert_id = $this->db->insert_id();

        // $order_item_id                  =  "WzEsMiwzLDRd";
        // $quantity                       =  "WzEsMiwzLDRd";
        // $unit_price_id                  =  "WzEsMiwzLDRd";

		$order_item_id                  = $data['item_id'];
		$quantity                       = $data['quantity'];
		$unit_price_id                  = $data['unit_price_id'];
		
		$order_item_id                  = base64_decode($order_item_id);
		$quantity                       = base64_decode($quantity);
		$unit_price_id                  = base64_decode($unit_price_id);
			
		$order_item_id                  = str_replace('[', "", $order_item_id);
		$order_item_id                  = str_replace(']', '', $order_item_id);	
		$quantity                       = str_replace('[', "", $quantity);
		$quantity                       = str_replace(']', '', $quantity);	
		$unit_price_id                  = str_replace('[', "", $unit_price_id);
		$unit_price_id                  = str_replace(']', '', $unit_price_id);	

        $item_id_values_array           = explode(',', $order_item_id);
        $quantity_values_array          = explode(',', $quantity);
        $unit_price_id_values_array     = explode(',', $unit_price_id);
     

        $count =  count($item_id_values_array); 

       for ($i=0; $i <$count ; $i++) 
       { 
        
        $insert_order_data['order_id']           =  $insert_id;
        $insert_order_data['item_id']            =  $item_id_values_array[$i];
        $insert_order_data['unit_price_id']      =  $quantity_values_array[$i];
        $insert_order_data['quantity']           =  $unit_price_id_values_array[$i];
     
        $this->db->insert('kf_order_items',$insert_order_data);

        }
	   
	    $response['response'] = 'true' ;
		$response['message']  = 'order submited successfully' ;

		echo json_encode($response);
	 
	  }

	  	
	  public function order_cupon()
	  {

	  	$user_id      = $this->input->get('user_id');
		$total_amount = $this->input->get('total_amount'); 
		$cupon_id     = $this->input->get('cupon_id'); 

	  		/** cupon section **/
		$coupon_details=$this->db->where('cupon_id',$cupon_id)->where('valid_from<=',date('Y-m-d'))->where('valid_to>=',date('Y-m-d'))->get('kf_cupon')->result_array();
       

		$have_user_order=$this->db->where('user_id',$user_id)->get('kf_order')->result_array();
		
	
		if(!empty($coupon_details)  && ((empty($have_user_order)&& $coupon_details[0]['user']=="New User")|| ($coupon_details[0]['user']=="All User")) &&$coupon_details[0]['purchase_price']<=$total_amount)
		{
			
			if($coupon_details[0]['discount_price_type'] == 'lumpsum')
			{
				$discount_amount =  $coupon_details[0]['discount_amount'];
				$total_price_amount = $total_amount - $coupon_details[0]['discount_amount'];
			}
			else
			{
				
				$total_amount_percentage = $total_amount * ($coupon_details[0]['discount_amount']/100);
				$discount_amount =  $total_amount_percentage;
			    $total_price_amount = $total_amount - $total_amount_percentage;

			}
			$response['cupon_discount']="$discount_amount";
			
		}
		else{
			
			$response['cupon_discount']="0.00";
		}
		/** cupon section **/
		 $response['cupon_id']="$cupon_id";
		 $response['response']='true';
		 echo json_encode($response);
	}
	  
}
