<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AssignOffer extends CI_Controller {

	function __construct() {
    error_reporting(0);
    parent::__construct();
    $this->load->model('CommonModel');
  }

	/**
  * load AssignOffer page
  * 
  * @param1       
  * @return       view page
  * @access       public
  * @author       P.C 
  * @copyright    N/A
  * @link         
  * @since        4.11.2016
  * @deprecated   N/A
  **/

  public function index($page=0)
  {

    if(check_login())
    {
      /**Listing section**/
            // $param = $this->input->get();
            // $param = $this->security->xss_clean($param);
            // if(isset($param['page'])&&$param['page']!='')
            // {
            //     $page=$param['page'];
            // }
            // $config = array();
            // $config['page_query_string'] = TRUE;
            // $config['query_string_segment'] = 'page';
            // $config['use_page_numbers'] = TRUE;
            // $config["base_url"] =base_url().'AssignOffer';
            // $config["total_rows"] = $this->CommonModel->record_count($param,'kf_item','item_name');
            // $config["per_page"] = 25;
            // $config['next_link'] = 'Next';
            // $config['prev_link'] = 'Previous';
            // $this->pagination->initialize($config);
            // if($page!=0)
            // {
            //     $page = ($page*$config["per_page"])-$config["per_page"];
            // }
            // $data['link'] =  $this->pagination->create_links();
            // $data['all_item'] = $this->CommonModel->all_data_list($config["per_page"],$page,$param,'kf_item','item_name');

            // $data['param'] = $param;
            // $data['page'] = $page;
            //echo"<pre>";print_r($data);     
      /** listing section **/ 
      $data['offer'] =$this->db->where('status',1)->get('kf_offer')->result_array(); 
      $data['category'] =$this->db->where('status',1)->get('kf_category')->result_array();   
      $data['content']="Assign_offer/index";
      $this->load->view('layout_home',$data);
    }
  }

  public function get_item()
  {
    if(check_login())
    {
    $data = $this->input->POST();
    $item_list = $this->db->where('status',1)->where('cat_id',$data['cat_id'])->get('kf_item')->result_array();

    
   $html= ' <table class="table table-bordered table-striped">
            <thead class="thead-inverse">
              <tr>
                <th><div class="headname"> </div></th>
                <th><div class="headname">Item Name </div></th>
                
              </tr>
            </thead>
            <tbody>';
            if(!empty($item_list)){
             foreach($item_list as $k=>$val){ 
            
           $html.= '<tr>
              <td>
              <input type="checkbox" name="item" value="" ></td><td>'.$val['item_name'].'</td></tr>';
             } 
            }
            else{
              $html.='<tr><td colspan="2" align="center">No data found</td></tr>';
            } 
           $html.= ' </tbody>
          </table>';
   echo $html;
    }
  }
	
  
}
