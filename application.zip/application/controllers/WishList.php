<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class WishList extends CI_Controller {

	function __construct() {
	    error_reporting(0);
        parent::__construct();
		$this->load->model('WishModel');
    }

	



	/**
    * load WishList page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         WishList
    * @since        4.11.2016
    * @deprecated   N/A
    */

	public function index($page=0)
	
  {

		if(check_login())
		{
			
            /**listing section**/
			$param = $this->input->get();
			//echo"<pre>";print_r($param);exit;
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			if(isset($param['name'])&&$param['name']!='')
            {
                $name=$param['name'];
            }
			else{
				 $name='';
			}
            if(isset($param['item']))
            {
                $item  = $param['item'];
            }
            else
            {
                $item = '';
            }
			
			      $config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
           $config["base_url"] =base_url().'WishList/lists?name='.$name.'&item='.$item;
            $config["total_rows"] = $this->WishModel->record_count($param);
            $config["per_page"] = 25;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['all_wish'] = $this->WishModel->all_data_list($config["per_page"],$page,$param);

            $data['param'] = $param;
            $data['page'] = $page;
            //echo"<pre>";print_r($data);	exit();		
			/** listing section **/	
			
			$data['content']="wish/wish_list";
			$this->load->view('layout_home',$data);
		}
	}

	




  

}