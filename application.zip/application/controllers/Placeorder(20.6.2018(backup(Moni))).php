<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'/third_party/mpdf/mpdf.php';
class Placeorder extends CI_Controller {

	function __construct() {
		 error_reporting(0);
        parent::__construct();
		$this->load->model('OrderModel');
		$this->load->library('excel');
		$this->load->library('email');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         EmployeePayroll/Company
    * @since        4.11.2016
    * @deprecated   N/A
    */

    public function index(){
    	$data['content']="Placeorder/Placeorder_list";
			$this->load->view('layout_home',$data);
    }
	public function order_insert()
	{
		if(check_login()){
            date_default_timezone_set('Asia/Kolkata');
			$param = $this->input->post();
            $param = $this->security->xss_clean($param);
            //print_r($param); exit;
            $date_value  =  explode('-', $param['order_date']);
            $result_date = $date_value[2].'-'.$date_value[1].'-'.$date_value[0];

            /*$mail_chk   = $this->db->escape_like_str($param['email']);
            $number_chk = $this->db->escape_like_str($param['phone']);
            $checking   = "select * from `kf_user` where `email` = '".$mail_chk."' OR `phone` = '".$number_chk."'";
            $user_chk   = $this->db->query($checking)->result_array();*/

            if (!empty($param['user_type']) && ($param['user_type']) == 2){

                $id = $param['user_name'];

                $insert_user_data['name']              = $this->db->escape_like_str($param['fname']);
                $insert_user_data['lastname']          = $this->db->escape_like_str($param['lname']);
                $insert_user_data['email']             = $this->db->escape_like_str($param['email']);
                $insert_user_data['address']           = $this->db->escape_like_str($param['address']);
                $insert_user_data['pin_code']          = $this->db->escape_like_str($param['pincode']);
                $insert_user_data['phone']             = $this->db->escape_like_str($param['phone']);
                $insert_user_data['status']            = '1';
                //$insert_user_data['registration_date'] = date('Y-m-d h:i:s');

                $this->db->where('user_id', $id);
                $this->db->update('kf_user',$insert_user_data);
                $insert_id = $id;
               

            }else{

                $insert_user_data['name']              = $this->db->escape_like_str($param['fname']);
                $insert_user_data['lastname']          = $this->db->escape_like_str($param['lname']);
                $insert_user_data['email']             = $this->db->escape_like_str($param['email']);
                $insert_user_data['address']           = $this->db->escape_like_str($param['address']);
                $insert_user_data['pin_code']          = $this->db->escape_like_str($param['pincode']);
                $insert_user_data['phone']             = $this->db->escape_like_str($param['phone']);
                $insert_user_data['status']            = '1';
                $insert_user_data['registration_date'] = date('Y-m-d h:i:s');

                $this->db->insert('kf_user',$insert_user_data);
                $insert_id = $this->db->insert_id();

            }

            $shipping_dtls = $param['chk_shipping_dtls'];
            $sql             = "select max(order_id) from kf_order ";
            $order_code      = $this->db->query($sql)->result_array();
            $genrate_code    = 100 + $order_code[0]['max(order_id)'];

            $insert_order_data['order_code']            = 'KF'.$genrate_code;
            $insert_order_data['user_id']               = $insert_id;
            $insert_order_data['total_amount']          = $this->db->escape_like_str($param['grand_total']);
            $insert_order_data['payment_status']        = '0';
            $insert_order_data['status']                = '0';
            $insert_order_data['order_date']            = $result_date." ".date("h:i:s");

            if ($shipping_dtls == 1){

                    $insert_order_data['shipping_first_name']   = $this->db->escape_like_str($param['fname']);
                    $insert_order_data['shipping_last_name']    = $this->db->escape_like_str($param['lname']);
                    $insert_order_data['shipping_email']        = $this->db->escape_like_str($param['email']);
                    $insert_order_data['shipping_address']      = $this->db->escape_like_str($param['address']);
                    $insert_order_data['shipping_phone_number'] = $this->db->escape_like_str($param['phone']);
                    $insert_order_data['shipping_zipcode']      = $this->db->escape_like_str($param['pincode']);
                    $insert_order_data['order_status']          = '1';

            }else{
                

                    $insert_order_data['shipping_first_name']   = $this->db->escape_like_str($param['ship_fname']);
                    $insert_order_data['shipping_last_name']    = $this->db->escape_like_str($param['ship_lname']);
                    $insert_order_data['shipping_email']        = $this->db->escape_like_str($param['ship_email']);
                    $insert_order_data['shipping_address']      = $this->db->escape_like_str($param['ship_address']);
                    $insert_order_data['shipping_phone_number'] = $this->db->escape_like_str($param['ship_phone']);
                    $insert_order_data['shipping_zipcode']      = $this->db->escape_like_str($param['ship_pincode']);
                    $insert_order_data['order_status']          = '1';

            }

            $this->db->insert('kf_order',$insert_order_data);

         
           
            $order_id = $this->db->insert_id();
            $count = count($param['item_cat']);
            
            for($i = 0 ; $i < $count ; $i++)
            {
                $unit_val = $param['quantity'][$i];
                $order_item_data['order_id']         = $order_id;
                $order_item_data['item_id']          = $param['sub_cat'][$i];

                $unit_price = $this->db->select('id')->where('item_id',$param['sub_cat'][$i])->where('price',$param['price'][$i])->get('kf_item_price_unit')->result_array();

                $order_item_data['unit_price_id']    = $unit_price[0]['id'];
                
                $get_unit_name = $this->db->select('*')->where('unit_id',$unit_val)->get('kf_unit_master')->result_array();
                
                $order_item_data['quantity']         = $param['qty'][$i];
                $order_item_data['unit_type']        = $param['qty'][$i].$get_unit_name[0]['unit_name'];
                $order_item_data['unit_price']       = $param['price'][$i];
                $order_item_data['price']            = $param['item_price'][$i];
               
                $this->db->insert('kf_order_items',$order_item_data);
            }

            $this->session->set_flashdata('success', 'Order has been placed successfully.');
            redirect(base_url('Orders'));

		}
	}
	

    public function item(){

    	$data = $this->input->post();
		// echo json_encode($data);exit;
   		$id = $this->input->post('type');
        $newID= $this->input->post('id');
        
        $sub_cat = $this->db->select('*')->where('cat_id',$id)->order_by('item_name',"asc")->get('kf_item')->result_array();
        //$unit_master = $this->db->select('*')->order_by('unit_name', "asc")->get('kf_unit_master')->result_array();
        //echo $this->db->last_query();exit;

        if(count($sub_cat) != 0){
       		$html='<div class="clearfix"></div><div class="col-md-2 col-sm-2"> <div class="form-group form-left"> <label for=""> Item <span class="star">*</span></label> <select class="form-control" id="sub_cat_'.$newID.'" onchange="show_dtls(this.value,\''.$newID.'\')" name="sub_cat[]" data-validation="required" data-validation-error-msg=""> 

       							<option value="">select</option>';           
                                foreach ($sub_cat as $key => $value) {
                                    if($value['status'] == 1){  

                                        $html.='<option value="'.$value['item_id'].'">'.$value['item_name'].' </option>';
                                    }
                                }
                                $html.='</select>
                      </div>
                    </div>

                    <div class="col-md-3 col-sm-3">
                    	<div class="form-group form-left">
                                                                    
                        	<label for=""> Item Details <span class="star">*</span></label>
                        	<select class="form-control" name="item_dtls[]" id="item_dtls_'.$newID.'" onchange="show_prc(this.value,\''.$newID.'\')" data-validation="required" data-validation-error-msg="">
                        		<option value="">select</option>
                        	 	
                        
            			</div>
                    </div>

                    <div class="col-md-2 col-sm-2">
                      	<div class="form-group form-left">
                                                                    
                        	<label for=""> Price <span class="star">*</span></label>
                       		<input type="text" class="form-control" name="price[]" id="price_'.$newID.'" data-validation="required" data-validation-error-msg="" readonly>
                      	</div>
                    </div> 
                    


                    <div class="col-md-2 col-sm-2">
                        <div class="form-group form-left">
                                                                    
                            <label for=""> Quantity <span class="star">*</span></label>
                            <input type="text" class="form-control" name="qty[]" id="qty_'.$newID.'" maxlength="7" data-validation="required" data-validation-error-msg="Please Enter Quantity" onkeypress="return checkquantity(this,event)">
                        
                        </div>
                    </div>





                	<div class="col-md-2 col-sm-2">
                    	<div class="form-group form-left">
                                                                    
                        	<label for=""> Unit Value <span class="star">*</span></label>
                        	<select class="form-control" name="quantity[]" id="quantity_'.$newID.'" onchange="cal_prc(this.value,\''.$newID.'\')" data-validation="required" data-validation-error-msg="">
                                <option value="">select</option>
                        
                      	</div>
                    </div>

                    <div class="col-md-2 col-sm-2">
                      <div class="form-group form-left">
                                                                    
                        <label for="">Total Price <span class="star">*</span></label>
                       
                        <input type="text" class="form-control get-total" name="item_price[]" id="item_price'.$newID.'" readonly>
                      </div>
                    </div>
                    <div class="clearfix"></div>
                    
                </div>';
                    
      	 			echo $html;
   		}else{
     		$html='<div class="col-md-6 col-sm-6">
            			<div class="form-group form-left">
                         
                		</div>
            		</div>
					<div class="col-md-6 col-sm-6">
            			<div class="form-group form-right">
                          no data found
                		</div>
            		</div>'            ;
     				echo $html;
   		}
    }

    public function qty_change(){
        $val = $this->input->post('val');
        $newID = $this->input->post('id');
        $sub_qty = $this->db->select('*')->where('item_id',$val)->get('kf_item_price_unit')->result_array();
        if($sub_qty[0]['unit_id'] == 6 || $sub_qty[0]['unit_id'] == 8){
            $unit_master = $this->db->select('*')->order_by('unit_name', "asc")->where('unit_id',$sub_qty[0]['unit_id'])->get('kf_unit_master')->result_array();
        }else{
            $unit_master = $this->db->select('*')->order_by('unit_name', "asc")->where_not_in('unit_id',6)->where_not_in('unit_id',8)->get('kf_unit_master')->result_array();
        }

        $data_array=array();

        					$html1='<option value="">select</option>';            
                                foreach ($sub_qty as $key => $value) {
                                    $html1.='<option value="'.$value['id'].'">'.$value['short_desc'].' </option>';
                                }
                                

                            $html2='<option value="">select</option>';           
                                foreach ($unit_master as $key => $val) {  

                                    $html2.='<option value="'.$val['unit_id'].'">'.$val['unit_name'].' </option>';
                                }
                                
        //echo $html;
        $data_array[0]= $html1;
        $data_array[1]= $html2;
        echo json_encode($data_array);

    }

    public function price_change(){
    	$val = $this->input->post('val');
        $newID = $this->input->post('id');
        $sub_pri[] = $this->db->select('*')->where('id',$val)->get('kf_item_price_unit')->result_array();

        echo json_encode($sub_pri);
    }

    public function subitem(){
    	$val= $this->input->post('val');
    	$type = $this->input->post('type');
    	$result[] = $this->db->select('price')->where('unit_value',$val)->where('item_id',$type)->get('kf_item_price_unit')->result_array();
    	$result2 = $this->db->select('*')->where('unit_value',$val)->where('item_id',$type)->get('kf_item_price_unit')->result_array();

    	$result[] = $this->db->select('unit_name')->where('unit_id',$result2[0]['unit_id'])->get('kf_unit_master')->result_array();

    	echo json_encode($result);
       
	}

    public function old_user(){
        $val= $this->input->post('val');

        $old_user_member = $this->db->select('*')->where('user_id',$val)->get('kf_user')->result_array();
        //print_r($val);exit;

        echo json_encode($old_user_member);
    }
   
}
