<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Offer extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		$this->load->model('OfferModel');
    }

	/**
    * load designation page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C 
    * @copyright    N/A
    * @link         Offer
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{

		if(check_login())
		{
			/**Listing section**/
			$param = $this->input->get();
            $param = $this->security->xss_clean($param);
            if(isset($param['page'])&&$param['page']!='')
            {
                $page=$param['page'];
            }
			$config = array();
            $config['page_query_string'] = TRUE;
            $config['query_string_segment'] = 'page';
            $config['use_page_numbers'] = TRUE;
            $config["base_url"] =base_url().'Offer';
            $config["total_rows"] = $this->OfferModel->record_count($param,'kf_offer','offer_id');
            $config["per_page"] = 25;
            $config['next_link'] = 'Next';
            $config['prev_link'] = 'Previous';
            $this->pagination->initialize($config);
            if($page!=0)
            {
                $page = ($page*$config["per_page"])-$config["per_page"];
            }
            $data['link'] =  $this->pagination->create_links();
            $data['all_offer'] = $this->OfferModel->all_data_list($config["per_page"],$page,$param,'kf_offer','offer_id');

            $data['param'] = $param;
            $data['page'] = $page;
            //echo"<pre>";print_r($data);			
			/** listing section **/			
			$data['content']="offer/index";
			$this->load->view('layout_home',$data);
		}
	}
	
	/**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       P.C. 
    * @copyright    N/A
    * @link         KochenFRESH
    * @since        4.11.2016
    * @deprecated   N/A
    */
	
	public function save()
	{
		if(check_login())
		{
		$data = $this->input->post();
		//echo "<pre>"; print_r($data); exit();
		//echo "<pre>"; print_r($_FILES); exit();
		//edit section

		$insert_data['title'] = strtoupper($data['title']);
		$insert_data['offer_description'] = strtoupper($data['description']);
		$have_data = $this->db->where('title',$insert_data['title'])->get('kf_offer')->result_array();

		

        $document_name = $_FILES["offer_image"]['name'];

        $ext = pathinfo($document_name, PATHINFO_EXTENSION);
    	$check_document=array('jpg','jpeg','png','PNG','JPG','JPEG');

    	if($document_name!='' && !in_array($ext,$check_document))
    	{
        	$this->session->set_flashdata('fail', 'Invalid Document Format');
        	redirect(base_url('Offer'));
    	}

        $filename_db = rand(100, 900) . '_' . $document_name;
        $filepath1 = 'uploads/offer_banner/' . $filename_db;
        $filetmp = $_FILES['offer_image']['tmp_name'];
        $result = move_uploaded_file($filetmp, $filepath1);
      

        $logo = $filename_db;

        $insert_data['offer_image'] = $logo;
			//echo"<pre>";print_r($have_data);exit;
		if($data['offer_id']!='')
		{
			if(!empty($have_data) && $have_data[0]['offer_id']!=$data['offer_id'])
			{
				$this->session->set_flashdata('fail', 'Company already added');
				redirect(base_url('Offer'));
			}
			else{
				$this->session->set_flashdata('success', 'Company updated successfully');
				$this->db->where('offer_id',$data['offer_id'])->update('kf_offer',$insert_data);
				redirect(base_url('Offer'));
			}
			
		}
		// insert section
		else{
		
			if(!empty($have_data))
			{
				$this->session->set_flashdata('fail', 'Company already added');
				redirect(base_url('Offer'));
			}
			else
			{
				$this->OfferModel->data_insert('kf_offer',$insert_data);
				$this->session->set_flashdata('success', 'Company  added successfully');
				redirect(base_url('Offer'));
			}
		}
		}
	}
	
    public function Status($id,$statusVal){
		if(check_login()) {
	    	/*echo $id;echo "<br/>";
	    	echo $statusVal;exit();*/
			if($statusVal == 1)
				{
					$changeStatus['status'] = 0;
					$msg = "This IP address has been inactivated successfully.";
				} else {
					$changeStatus['status'] = 1;
					$msg = "This IP address has been activated successfully.";
				}
			$this->db->where('offer_id',$id)->update('kf_offer',$changeStatus);
			$this->session->set_flashdata('success', $msg);
			redirect(base_url('Offer'));
		}
	}

    
}
