<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SetItemPrice extends CI_Controller {

	function __construct() {
		error_reporting(0);
        parent::__construct();
		//$this->load->model('ItemModel');
    }

	/**
    * load department page
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         ItemPayroll/Item
    * @since        4.11.2016
    * @deprecated   N/A
    */
	public function index($page=0)
	{
		if(check_login())
		{
						
				$data['category'] =$this->db->where('status',1)->get('kf_category')->result_array();
				$data['unit_master'] =$this->db->where('status',1)->get('kf_unit_master')->result_array();				
				$data['content']="Item/set_price";
				$this->load->view('layout_home',$data);
		}
	}
	
	/**
    * check  Login credential
    * 
    * @param1       
    * @return       view page
    * @access       public
    * @author       D.M 
    * @copyright    N/A
    * @link         ItemPayroll/Item/save
    * @since        4.11.2016
    * @deprecated   N/A
    */
	
	public function save()
	{
		if(check_login())
		{
		$data = $this->input->post();
		//echo"<pre>";print_r($data);exit;
		$data = $this->security->xss_clean($data);
		//Item insert data
		$count = count($data['unit_id']);
		
		
		
		for($i=0;$i<$count; $i++)
		{
			$have_item_price = $this->db->where('item_id',$data['item_id'])->where('unit_id',$data['unit_id'][$i])->where('unit_value',$data['quantity'][$i])->get('kf_item_price_unit')->result_array();
			
			$insert_data['item_id'] =  $data['item_id'];
			$insert_data['unit_id'] =  $data['unit_id'][$i];
			$insert_data['price'] =  $data['item_price'][$i];
			$insert_data['unit_value'] =  $data['quantity'][$i];
			
			if(!empty($have_item_price))
			{
				
				 $this->db->where('id',$have_item_price[0]['id'])->update('kf_item_price_unit',$insert_data);
			}
			 else{
				 
				 $this->db->insert('kf_item_price_unit',$insert_data);
			 }
		}
		//insert into data base
		
		$this->session->set_flashdata('success', 'Price set successfully');
	    redirect(base_url('SetItemPrice'));
	}
	}

	public function get_item_by_sub_cat_id()
	{
		if(check_login())
			{
				$data = $this->input->post();
				$item = $this->db->where('cat_id',$data['cat_id'])->where('status',1)->get('kf_item')->result_array();
				if(!empty($item))
				{
					echo json_encode($item);
				}
				else
				{
					echo json_encode("no data");
				}
			}
	}
	public function get_item_price()
	{
		$data = $this->input->post();
		//echo"<pre>";print_r($data);
		$have_price = $this->db->where('unit_id',$data['unit'])->where('item_id',$data['item_id'])->where('unit_value',$data['quantity'])->get('kf_item_price_unit')->result_array();
		if(!empty($have_price))
		{
			echo json_encode($have_price[0]['price']);
		}
		else{
			echo json_encode('no data');
		}
	}

		public function listing()
	{
		 
		$data['content']="Set_Price/list";
		$this->load->view('layout_home',$data);

	}
	 
}
